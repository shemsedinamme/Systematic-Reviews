-- SQL file to create all ARMS database tables

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    user_id VARCHAR(36) PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    hashed_password VARCHAR(255) NOT NULL,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    role VARCHAR(255) DEFAULT 'reviewer'
);

-- Create roles table
CREATE TABLE IF NOT EXISTS roles (
    role_id VARCHAR(36) PRIMARY KEY,
    role_name VARCHAR(255) NOT NULL UNIQUE
);

-- Create password_reset_tokens table
CREATE TABLE IF NOT EXISTS password_reset_tokens (
    token VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    expiration_timestamp TIMESTAMP NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Create blacklisted_tokens table
CREATE TABLE IF NOT EXISTS blacklisted_tokens (
    token VARCHAR(255) PRIMARY KEY,
    expiration_timestamp TIMESTAMP NOT NULL
);

-- Create projects table
CREATE TABLE IF NOT EXISTS projects (
    project_id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    start_date DATE,
    end_date DATE,
    creation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(255) DEFAULT 'active'
);

-- Create metadata_fields table
CREATE TABLE IF NOT EXISTS metadata_fields (
    field_id VARCHAR(36) PRIMARY KEY,
    field_name VARCHAR(255) NOT NULL UNIQUE
);

-- Create project_metadata table
CREATE TABLE IF NOT EXISTS project_metadata (
    meta_id VARCHAR(36) PRIMARY KEY,
    project_id VARCHAR(36) NOT NULL,
    field_id VARCHAR(36) NOT NULL,
    value TEXT,
    FOREIGN KEY (project_id) REFERENCES projects(project_id),
    FOREIGN KEY (field_id) REFERENCES metadata_fields(field_id)
);

-- Create project_workflows table
CREATE TABLE IF NOT EXISTS project_workflows (
    workflow_id VARCHAR(36) PRIMARY KEY,
    project_id VARCHAR(36) NOT NULL,
    workflow_name VARCHAR(255) DEFAULT 'default',
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);

-- Create workflow_stages table
CREATE TABLE IF NOT EXISTS workflow_stages (
    stage_id VARCHAR(36) PRIMARY KEY,
    workflow_id VARCHAR(36) NOT NULL,
    stage_name VARCHAR(255) NOT NULL,
    FOREIGN KEY (workflow_id) REFERENCES project_workflows(workflow_id)
);

-- Create tasks table
CREATE TABLE IF NOT EXISTS tasks (
    task_id VARCHAR(36) PRIMARY KEY,
    stage_id VARCHAR(36) NOT NULL,
    task_name VARCHAR(255) NOT NULL,
    assigned_user_id VARCHAR(36),
    due_date DATE,
    FOREIGN KEY (stage_id) REFERENCES workflow_stages(stage_id),
    FOREIGN KEY (assigned_user_id) REFERENCES users(user_id)
);

-- Create task_dependencies table
CREATE TABLE IF NOT EXISTS task_dependencies(
    dependency_id VARCHAR(36) PRIMARY KEY,
    task_id VARCHAR(36) NOT NULL,
    FOREIGN KEY (task_id) REFERENCES tasks(task_id)
);

-- Create documents table
CREATE TABLE IF NOT EXISTS documents (
    document_id VARCHAR(36) PRIMARY KEY,
    project_id VARCHAR(36) NOT NULL,
    content TEXT,
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);

-- Create document_versions table
CREATE TABLE IF NOT EXISTS document_versions (
    version_id VARCHAR(36) PRIMARY KEY,
    document_id VARCHAR(36) NOT NULL,
    content TEXT,
    version_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (document_id) REFERENCES documents(document_id)
);

-- Create comments table
CREATE TABLE IF NOT EXISTS comments (
    comment_id VARCHAR(36) PRIMARY KEY,
    project_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(project_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Create files table
CREATE TABLE IF NOT EXISTS files (
    file_id VARCHAR(36) PRIMARY KEY,
    project_id VARCHAR(36) NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);

-- Create user_project_relations table
CREATE TABLE IF NOT EXISTS user_project_relations (
    user_id VARCHAR(36) NOT NULL,
    project_id VARCHAR(36) NOT NULL,
    role VARCHAR(255),
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (project_id) REFERENCES projects(project_id),
    PRIMARY KEY (user_id, project_id)
);

-- Create project_access table
CREATE TABLE IF NOT EXISTS project_access (
    access_id VARCHAR(36) PRIMARY KEY,
    project_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    access_type VARCHAR(255) DEFAULT 'read-only',
    FOREIGN KEY (project_id) REFERENCES projects(project_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Create templates table
CREATE TABLE IF NOT EXISTS templates (
    template_id VARCHAR(36) PRIMARY KEY,
    template_name VARCHAR(255) NOT NULL,
    template_description TEXT
);

-- Create template_sections table
CREATE TABLE IF NOT EXISTS template_sections (
    section_id VARCHAR(36) PRIMARY KEY,
    template_id VARCHAR(36) NOT NULL,
    section_name VARCHAR(255) NOT NULL,
    FOREIGN KEY (template_id) REFERENCES templates(template_id)
);

-- Create template_data_fields table
CREATE TABLE IF NOT EXISTS template_data_fields (
    field_id VARCHAR(36) PRIMARY KEY,
    section_id VARCHAR(36) NOT NULL,
    field_name VARCHAR(255) NOT NULL,
    FOREIGN KEY (section_id) REFERENCES template_sections(section_id)
);

-- Create protocols table
CREATE TABLE IF NOT EXISTS protocols (
    protocol_id VARCHAR(36) PRIMARY KEY,
    template_id VARCHAR(36) NOT NULL,
    project_id VARCHAR(36) NOT NULL,
    title VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (template_id) REFERENCES templates(template_id),
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);

-- Create protocol_sections table
CREATE TABLE IF NOT EXISTS protocol_sections (
    section_id VARCHAR(36) PRIMARY KEY,
    protocol_id VARCHAR(36) NOT NULL,
    section_name VARCHAR(255) NOT NULL,
    content TEXT,
    FOREIGN KEY (protocol_id) REFERENCES protocols(protocol_id)
);

-- Create protocol_reviews table
CREATE TABLE IF NOT EXISTS protocol_reviews (
    review_id VARCHAR(36) PRIMARY KEY,
    protocol_id VARCHAR(36) NOT NULL,
    section_id VARCHAR(36) NOT NULL,
    reviewer_id VARCHAR(36) NOT NULL,
    comment TEXT,
    FOREIGN KEY (protocol_id) REFERENCES protocols(protocol_id),
    FOREIGN KEY (section_id) REFERENCES protocol_sections(section_id),
    FOREIGN KEY (reviewer_id) REFERENCES users(user_id)
);

-- Create protocol_approvals table
CREATE TABLE IF NOT EXISTS protocol_approvals (
    approval_id VARCHAR(36) PRIMARY KEY,
    protocol_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    approval_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (protocol_id) REFERENCES protocols(protocol_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Create articles table
CREATE TABLE IF NOT EXISTS articles (
    article_id VARCHAR(36) PRIMARY KEY,
    database_id VARCHAR(255) NOT NULL,
    title TEXT,
    authors TEXT,
    abstract TEXT,
    publication_date DATE,
    doi VARCHAR(255),
    pmid VARCHAR(255),
    pmcid VARCHAR(255),
    additional_fields JSON
);
-- Create search_queries table
CREATE TABLE IF NOT EXISTS search_queries (
    query_id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    database_id VARCHAR(255),
    full_query TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Create data_quality_issues table
CREATE TABLE IF NOT EXISTS data_quality_issues (
  issue_id VARCHAR(36) PRIMARY KEY,
    article_id VARCHAR(36) NOT NULL,
    issue_type VARCHAR(255) NOT NULL,
    issue_description TEXT,
  FOREIGN KEY (article_id) REFERENCES articles(article_id)
);

-- Create search_term_mappings table
CREATE TABLE IF NOT EXISTS search_term_mappings (
  mapping_id VARCHAR(36) PRIMARY KEY,
  user_term VARCHAR(255) NOT NULL,
  standard_term VARCHAR(255) NOT NULL,
  database_id VARCHAR(255)
);

-- Create share_links table
CREATE TABLE IF NOT EXISTS share_links (
    share_link_id VARCHAR(36) PRIMARY KEY,
    project_id VARCHAR(36) NOT NULL,
    password VARCHAR(255),
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);
-- Create screening_decisions table
CREATE TABLE IF NOT EXISTS screening_decisions (
    decision_id VARCHAR(36) PRIMARY KEY,
    article_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    decision ENUM('include', 'exclude', 'postpone') NOT NULL,
    reason_for_exclusion TEXT,
    screening_stage ENUM('title/abstract', 'full-text') NOT NULL,
    decision_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (article_id) REFERENCES articles(article_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Create screening_workflow table
CREATE TABLE IF NOT EXISTS screening_workflow (
    workflow_id VARCHAR(36) PRIMARY KEY,
    project_id VARCHAR(36) NOT NULL,
    stage_name VARCHAR(255) NOT NULL,
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);

-- Create screening_assignments table
CREATE TABLE IF NOT EXISTS screening_assignments (
    assignment_id VARCHAR(36) PRIMARY KEY,
    workflow_id VARCHAR(36) NOT NULL,
    reviewer_id VARCHAR(36) NOT NULL,
     task_id VARCHAR(36) NOT NULL,
    FOREIGN KEY (workflow_id) REFERENCES screening_workflow(workflow_id),
    FOREIGN KEY (reviewer_id) REFERENCES users(user_id),
     FOREIGN KEY (task_id) REFERENCES tasks(task_id)
);

-- Create inclusion_criteria table
CREATE TABLE IF NOT EXISTS inclusion_criteria (
    criterion_id VARCHAR(36) PRIMARY KEY,
    project_id VARCHAR(36) NOT NULL,
    criterion TEXT NOT NULL,
     type ENUM('inclusion', 'exclusion'),
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);
-- Create exclusion_criteria table
CREATE TABLE IF NOT EXISTS exclusion_criteria (
    criterion_id VARCHAR(36) PRIMARY KEY,
    project_id VARCHAR(36) NOT NULL,
    criterion TEXT NOT NULL,
    type ENUM('inclusion', 'exclusion'),
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);

-- Create inter_rater_reliability table
CREATE TABLE IF NOT EXISTS inter_rater_reliability (
    inter_rater_id VARCHAR(36) PRIMARY KEY,
    project_id VARCHAR(36) NOT NULL,
    cohens_kappa DECIMAL(10, 2),
     fleiss_kappa DECIMAL(10, 2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);

-- Create extraction_forms table
CREATE TABLE IF NOT EXISTS extraction_forms (
    form_id VARCHAR(36) PRIMARY KEY,
    project_id VARCHAR(36) NOT NULL,
    form_name VARCHAR(255) NOT NULL,
    form_description TEXT,
    form_fields JSON,
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);

-- Create form_fields table
CREATE TABLE IF NOT EXISTS form_fields (
  field_id VARCHAR(36) PRIMARY KEY,
   form_id VARCHAR(36) NOT NULL,
   field_type VARCHAR(255) NOT NULL,
    field_label VARCHAR(255) NOT NULL,
  field_options JSON,
  conditional_logic TEXT,
   field_order INT,
  FOREIGN KEY (form_id) REFERENCES extraction_forms(form_id)
);
-- Create form_templates table
CREATE TABLE IF NOT EXISTS form_templates (
    template_id VARCHAR(36) PRIMARY KEY,
    template_name VARCHAR(255) NOT NULL,
    template_description TEXT,
    template_fields JSON
);

-- Create quality_assessment_criteria table
CREATE TABLE IF NOT EXISTS quality_assessment_criteria (
    criterion_id VARCHAR(36) PRIMARY KEY,
    project_id VARCHAR(36) NOT NULL,
    criterion_name VARCHAR(255) NOT NULL,
    criterion_description TEXT,
    criterion_type ENUM('bias', 'quality') NOT NULL,
    criteria_options JSON,
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);
-- Create quality_assessment_ratings table
CREATE TABLE IF NOT EXISTS quality_assessment_ratings (
    rating_id VARCHAR(36) PRIMARY KEY,
    article_id VARCHAR(36) NOT NULL,
    criterion_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    rating VARCHAR(255),
    rationale TEXT,
    rating_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (article_id) REFERENCES articles(article_id),
    FOREIGN KEY (criterion_id) REFERENCES quality_assessment_criteria(criterion_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Create bias_summary_scores table
CREATE TABLE IF NOT EXISTS bias_summary_scores (
    score_id VARCHAR(36) PRIMARY KEY,
    article_id VARCHAR(36) NOT NULL,
    overall_risk ENUM('Low','High','Unclear'),
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
     FOREIGN KEY (article_id) REFERENCES articles(article_id)
);

-- Create data_synthesis_results table
CREATE TABLE IF NOT EXISTS data_synthesis_results (
    synthesis_id VARCHAR(36) PRIMARY KEY,
    project_id VARCHAR(36) NOT NULL,
    synthesis_type ENUM('meta-analysis', 'narrative', 'qualitative', 'network-meta-analysis') NOT NULL,
    synthesis_description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);

-- Create meta_analysis_results table
CREATE TABLE IF NOT EXISTS meta_analysis_results (
    meta_id VARCHAR(36) PRIMARY KEY,
    synthesis_id VARCHAR(36) NOT NULL,
    outcome VARCHAR(255) NOT NULL,
    model_type ENUM('fixed-effect', 'random-effects') NOT NULL,
    pooled_estimate DECIMAL(10, 4),
    heterogeneity_i2 DECIMAL(5, 2),
    forest_plot_data JSON,
    subgroup_analysis_data JSON,
    FOREIGN KEY (synthesis_id) REFERENCES data_synthesis_results(synthesis_id)
);

-- Create qualitative_synthesis_results table
CREATE TABLE IF NOT EXISTS qualitative_synthesis_results (
    qualitative_id VARCHAR(36) PRIMARY KEY,
    synthesis_id VARCHAR(36) NOT NULL,
    coding_scheme JSON,
    meta_aggregation_results JSON,
    thematic_analysis_results JSON,
    FOREIGN KEY (synthesis_id) REFERENCES data_synthesis_results(synthesis_id)
);

-- Create narrative_synthesis_results table
CREATE TABLE IF NOT EXISTS narrative_synthesis_results (
    narrative_id VARCHAR(36) PRIMARY KEY,
    synthesis_id VARCHAR(36) NOT NULL,
    narrative_summary TEXT,
    FOREIGN KEY (synthesis_id) REFERENCES data_synthesis_results(synthesis_id)
);

-- Create network_meta_analysis_results table
CREATE TABLE IF NOT EXISTS network_meta_analysis_results (
    network_id VARCHAR(36) PRIMARY KEY,
    synthesis_id VARCHAR(36) NOT NULL,
    comparison_matrix JSON,
    network_plot_data JSON,
    FOREIGN KEY (synthesis_id) REFERENCES data_synthesis_results(synthesis_id)
);

-- Create publication_bias_assessment table
CREATE TABLE IF NOT EXISTS publication_bias_assessment (
    bias_id VARCHAR(36) PRIMARY KEY,
    synthesis_id VARCHAR(36) NOT NULL,
    funnel_plot_data JSON,
    eggers_test_p DECIMAL(5,4),
    trim_and_fill_data JSON,
    FOREIGN KEY (synthesis_id) REFERENCES data_synthesis_results(synthesis_id)
);

-- Create sensitivity_analysis_results table
CREATE TABLE IF NOT EXISTS sensitivity_analysis_results (
    sensitivity_id VARCHAR(36) PRIMARY KEY,
    synthesis_id VARCHAR(36) NOT NULL,
     analysis_type VARCHAR(255),
    analysis_description TEXT,
    analysis_results JSON,
    FOREIGN KEY (synthesis_id) REFERENCES data_synthesis_results(synthesis_id)
);

-- Create report_templates table
CREATE TABLE IF NOT EXISTS report_templates (
    template_id VARCHAR(36) PRIMARY KEY,
    template_name VARCHAR(255) NOT NULL,
    template_type VARCHAR(50),
    template_structure JSON NOT NULL
);

-- Create report_metadata table
CREATE TABLE IF NOT EXISTS report_metadata (
    report_id VARCHAR(36) PRIMARY KEY,
    project_id VARCHAR(36) NOT NULL,
    template_id VARCHAR(36) NOT NULL,
    metadata JSON NOT NULL,
    FOREIGN KEY (template_id) REFERENCES report_templates(template_id)
);

-- Create manuscript_templates table
CREATE TABLE IF NOT EXISTS manuscript_templates (
    template_id VARCHAR(36) PRIMARY KEY,
    template_name VARCHAR(255) NOT NULL,
    template_structure JSON NOT NULL
);

-- Create manuscripts table
CREATE TABLE IF NOT EXISTS manuscripts (
    manuscript_id VARCHAR(36) PRIMARY KEY,
    project_id VARCHAR(36) NOT NULL,
    template_id VARCHAR(36) NOT NULL,
    content TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (template_id) REFERENCES manuscript_templates(template_id)
);
-- Create messages table
CREATE TABLE IF NOT EXISTS messages (
    message_id VARCHAR(36) PRIMARY KEY,
    sender_id VARCHAR(36),
    receiver_id VARCHAR(36),
    message_type VARCHAR(255),
    message_text TEXT,
    time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create conversations table
CREATE TABLE IF NOT EXISTS conversations (
    conversation_id VARCHAR(36) PRIMARY KEY,
    conversation_type VARCHAR(255),
    participants JSON
);

-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
    notification_id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36),
    message TEXT,
    notification_type VARCHAR(50),
    time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(10) DEFAULT 'unread'
);

-- Create meetings table
CREATE TABLE IF NOT EXISTS meetings (
    meeting_id VARCHAR(36) PRIMARY KEY,
    organizer_id VARCHAR(36),
    meeting_title VARCHAR(255),
    start_time TIMESTAMP,
    end_time TIMESTAMP,
    attendees JSON
);

-- Create audit_logs table
CREATE TABLE IF NOT EXISTS audit_logs (
    log_id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36),
    action TEXT,
    target_type VARCHAR(255),
    target_id VARCHAR(36),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    details TEXT
);