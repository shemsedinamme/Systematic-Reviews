**Notes**

**Explanation notes code snippets within your script files are provided below, while also outlining the sequential order or stages at which these scripts are typically used.**

**Explanation of Installer Scripts and Usage** **Stages:**

**Here's a breakdown of each script, including its purpose, importance, and the typical stage in the development or deployment process where it would be used:**

**Setup & Dependency Installation:**

npm install -g pm2

****Purpose: Installs PM2 globally.**

**Importance: PM2 is used for process management.**

**Stage: This is a one-time setup step, usually performed on the server when setting up the deployment environment.**

npm install express-fileupload

**Purpose: Installs the express-fileupload middleware, which enables your backend to handle file uploads.**

**Importance: Essential for handling file uploads in your API**

**Stage: This is a dependency installation step, usually performed in the development environment when setting up the backend app.**

npm install @xenova/transformers

**Purpose: Installs the @xenova/transformers library, used for machine learning tasks.**

**Importance: Required if you are using machine learning models.**

**Stage: This is a dependency installation step, performed in the development environment.**

npm install html-to-docx pdfkit puppeteer exceljs json2csv compromise @stdlib/stats simple-statistics

**Purpose: Installs multiple libraries needed for report generation.**

**Importance: These are essential for generating various report formats.**

**Stage: Dependency installation step, performed in the development environment.**

npm install axios

**Purpose: Installs the axios library used for making HTTP requests from your application.**

**Importance: Essential for interacting with third-party APIs.**

**Stage: Dependency installation, performed in the development environment.**

npm install citeproc-js

**Purpose: Installs the citeproc-js library used for citation processing.**

**Importance: Essential for handling and formatting citations in the system.**

**Stage: Dependency installation, performed in the development environment.**

npm install jest supertest dotenv mysql2 --save-dev

**Purpose: Installs development dependencies required for testing in Node.js backend.**

**Importance: These are tools needed for the backend's testing infrastructure.**

**Stage: Development setup - performed in the development environment.**

yarn add jest supertest dotenv mysql2 --de

**Purpose: Similar to the previous command but used with yarn package manager.**

**Importance: Installs testing packages in the development environment using yarn.**

**Stage: Development setup - performed in the development environment.**

npm install --save-dev @babel/core @babel/preset-env @babel/preset-react babel-loader style-loader css-loader

**Purpose: Installs Babel and its related packages and css and style loader for Webpack bundler.**

**Importance: Needed for bundling frontend app, transpiling JSX syntax, and handling CSS.**

**Stage: Development setup for the frontend project.**

**Build and Testing:**

npx webpack --config webpack.config.js

**Purpose: Runs Webpack to bundle your React frontend code using your configuration.**

**Importance: Combines your application code and assets into optimized bundles ready for deployment.**

**Stage: Build phase - performed after the source code development. This script should run after installing the libraries related to bundling.**

npm test or test.bash:

**Purpose: Executes the Jest test suites, providing reports on the tests and test coverage.**

**Importance: To run unit tests.**

**Stage: Testing stage - performed during the development process, or before deployment.**

**Configuration Files:**

jest.config.js

**Purpose: Configuration file for running and managing jest tests.**

**Importance: Used to ensure that the tests are executed according to project settings.**

**Stage: Development environment setup.**

***Sequential Order/Stages of Usage:**

**Environment Setup (One-Time Setup):**

pm2.bash: Install PM2 on the server.

**Development Setup:**

express.bash: To install express when setting up backend project.

express-fileupload.bash: Install file upload library in backend.

axios.bash: To install axios library for fetching data from external APIs or for internal communication.

cite-proc.bash : Install citeproc-js for citation processing.

simple-statistics.bash: Set up statistical analysis library.

xenova.bash: Install Machine Learning library.

npm install ..., or yarn add ...: Install development dependencies required for testing.

**Build and Bundling (Frontend):**

babel.bash : Install Babel for transpiling the code for frontend.

buildbundle.bash: To generate the bundled javascript and css for frontend.

jest.config.js: Configuration of the jest framework for running the tests.

**Testing:**

jest.bash or test.bash: Run test suites for the backend and frontend if needed.

**Summary:**

**The note includes explanations for all the script files, including sequential order/stages of usage.**


**here is code snippets inside these script files:** 

// **install PM2**
npm install -g pm2

// **Add express-fileupload to index.js to allow multipart form data requests.**
npm install express-fileupload

npm install @xenova/transformers

npm install html-to-docx pdfkit puppeteer exceljs json2csv  compromise @stdlib/stats simple-statistics 

npm test

npm install jest supertest dotenv mysql2 --save-dev

yarn add jest supertest dotenv mysql2 --de

// **Jest.config.js**
module.exports = {
  testEnvironment: 'node',
  testMatch: ['**/__tests__/**/*.test.js'],
  verbose: true,
  forceExit: true, // To ensure test finishes
};

npx webpack --config webpack.config.js

npm install --save-dev @babel/core @babel/preset-env @babel/preset-react babel-loader style-loader css-loader



// **Install axios for Third Party API requests: Install axios to make HTTP requests to third party APIs.** **Unpaywall API:** **Implement a call to the Unpaywall API or a similar service to get a full-text link for a given DOI or PMID. This will use Unpaywall API for demonstration.**

// **Install the axios package to help us make HTTP requests:**

npm install axios

// **installing citeproc-js**

npm install citeproc-js

// **Install the express-fileupload:**

npm install express-fileupload
