// backend/index.js
const express = require('express');
const dataExtractionRoutes = require('./routes/dataExtraction/dataExtractionRoutes');
const userRoutes = require('./routes/user/userRoutes');
const projectRoutes = require('./routes/project/projectRoutes');
const protocolRoutes = require('./routes/protocol/protocolRoutes');
const searchRoutes = require('./routes/search/searchRoutes');
const screeningRoutes = require('./routes/screening/sreeningRoutes');
const qualityAssessmentRoutes = require('./routes/qualityAssessment/qualityAssessmentRoutes');
const dataSynthesisRoutes = require('./routes/dataSynthesis/dataSynthesisRoutes');
const reportingRoutes = require('./routes/reporting/reportContentRoutes');

// other imports...

const app = express();
app.use(express.json());

// Define routes
app.use('/api/data-extraction', dataExtractionRoutes);
app.use('/api/users', userRoutes);
app.use('/api/projects', projectRoutes); // Added project routes
app.use('/api/protocols', protocolRoutes); // Added protocol routes
app.use('/api/search', searchRoutes); // Added search routes
app.use('/api/screening', screeningRoutes); // Added screening routes
app.use('/api/quality-assessment', qualityAssessmentRoutes); // Added quality assessment routes
app.use('/api/data-synthesis', dataSynthesisRoutes); // Added data synthesis routes
app.use('/api/reporting', reportingRoutes); // Added reporting routes

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
