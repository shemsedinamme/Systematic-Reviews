//Add express-fileupload to index.js to allow multipart form data requests.


npm install express-fileupload