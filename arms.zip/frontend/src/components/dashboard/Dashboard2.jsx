//Dashboard.js
import React from 'react';
import styles from './Dashboard.module.css';

const Dashboard = () => {
  return (
    <div className={styles.dashboardContainer}>
       <header className={styles.dashboardHeader}>
            <h1>Arguments Review Management System (ARMS)</h1>
            <p>Streamlined management for systematic reviews and meta-analyses</p>
        </header>

        <nav className={styles.adminTaskbar}>
             <h2>System Admin</h2>
            <ul>
                <li><a href="settings.html">Settings</a></li>
                <li><a href="user_management.html">User Management</a></li>
                <li><a href="registration.html">User Registration</a></li>
                <li><a href="manage_roles.html">Role Management</a></li>
       
            </ul>
        </nav>
        <main className={styles.dashboardGrid}>
              <section className={styles.dashboardSection} style={{backgroundColor: 'lemonchiffon'}}>
                <h2>Create Project</h2>
                <ul>
                    <li><a href="dashboard.html">Project Dashboard</a></li>
                    <li><a href="create_project.html">Create Project</a></li>
                    <li><a href="invite_collaborators.html">Invite Collaborators</a></li>
                </ul>
                                <h3>Collaboration</h3>
                <ul>
                    <li><a href="project_collaboration.html">Project Collaboration</a></li>
                    <li><a href="assign_task.html">Assign Task</a></li>
                    <li><a href="task_list.html">Task List</a></li>
                    <li><a href="notifications.html">Notifications</a></li>
                    <li><a href="version_control.html">Version Control</a></li>
                </ul>
              </section>
              <section className={styles.dashboardSection} style={{backgroundColor: 'lightgray'}}>
                <h2>Planning Review</h2>
                <h3>Protocol Management</h3>
                <ul>
                    <li><a href="create_protocol.html">Create Protocol</a></li>
                    <li><a href="edit_protocol.html">Edit Protocol</a></li>
                    <li><a href="view_versions.html">View Versions</a></li>
                    <li><a href="generate_protocol.html">Generate Protocol</a></li>
                </ul>
                <h3>Design Search Query</h3>
                <ul>
                	<li><a href="select_databases.html">Select Databases</a></li>
                     <li><a href="create_query_form.html">Create Query Form</a></li>
                    <li><a href="create_query.html">Create Query</a></li>        
                    
                    <li><a href="translations.html">Translate Databases</a></li>
                    <li><a href="query_dashboard.html">Query Dashboard</a></li>
                    </ul>
                    <h3>Create Data Forms</h3>
                <ul>
                    <li><a href="create_form.html">Create Data Form</a></li>
                    <li><a href="test_data_form.html">Test Data Form</a></li>

                    <li>
                    	</ul>
                    <h3>Design Quality Assessment</h3>
                <ul>
                	
<a href="create_quality_assessment_form.html">Create Quality Assessment Form</a></li>
                   
                </ul>
            </section>
            <section className={styles.dashboardSection}style={{backgroundColor: 'lemonchiffon'}}>
                <h2>Perform Review</h2>
                <h3>Title-Abstract Screening</h3>
                <ul>
                    <li><a href="upload_studies.html">Upload Studies</a></li>
                     <li><a href="deduplicate_studies.html">De-deuplicate Studies</a></li>
                    <li><a href="screen_studies.html">Screen Studies</a></li>
                    <li><a href="resolve_conflicts.html">Resolve Conflicts</a></li>
                    </ul>
                    <h3>Full-Text Screening</h3>
                <ul>
                    <li><a href="full_text_screening.html">Full-Text Screening</a></li>
                </ul>
                <h3>Data Extraction</h3>
                <ul>
                    <li><a href="create_form.html">Create Extraction Form</a></li>
                    <li><a href="manage_studies.html">Manage Studies</a></li>
                    <li><a href="data_extraction.html">Data Extraction</a></li>
                    <li><a href="review_extracted_data.html">Review Extracted Data</a></li>
                </ul>
                <h3>Quality Assessment</h3>
                <ul>
                    <li><a href="create_quality_assessment.html">Create Quality Assessment</a></li>
                    <li><a href="quality_assessment.html">Quality Assessment</a></li>
                    <li><a href="review_quality_assessment.html">Review Quality Assessment</a></li>
                </ul>
            </section>
            <section className={styles.dashboardSection} style={{backgroundColor: 'lightorange'}}>
            <h2>Data Synthesis</h2>
            <h3>Synthesis Actions</h3>
            <ul>
                <li><a href="data_synthesis.html">Data Synthesis</a></li>
                <li><a href="data_synthesis_result.html">Synthesis Results</a></li>
                <li><a href="qualitative_synthesis.html">Qualitative Synthesis</a></li>
                <li><a href="qualitative_synthesis_result.html">Qualitative Results</a></li>
            </ul>
            <h3>Sensitivity Analysis</h3>
            <ul>
                <li><a href="sensitivity_analysis.html">Sensitivity Analysis</a></li>
                <li><a href="sensitivity_analysis_result.html">Sensitivity Results</a></li>
            </ul>
        </section>
            <section className={styles.dashboardSection}style={{backgroundColor: 'lightblue'}}>
                <h2>Reporting</h2>
                <h3>Visualize</h3>
                <ul>
                    <li><a href="view_trends.html">Visualize Data</a></li>
                    <li><a href="view_charts.html">Figure Charts</a></li>
                        <li><a href="data_tables.html">Data Tables</a></li>
                         </ul>               
                 <h3>Export</h3>
                <ul>                   
                    <li><a href="prisma_diagram.html">PRISMA Diagram</a></li>
                    <li><a href="generate_prisma.html">Generate PRISMA</a></li>
                    <li><a href="generate_manuscript.html">Generate Manuscript</a></li>
                </ul>

            </section>
              <section className={styles.icon} style={{ backgroundImage: `url("Logo_of_the_Congregation.png")`}} >
                  </section>
       </main>
        <footer className={styles.dashboardFooter}>
            <p>© 2024 ARMS. All Rights Reserved.</p>
        </footer>
      </div>
   );
};

export default Dashboard;