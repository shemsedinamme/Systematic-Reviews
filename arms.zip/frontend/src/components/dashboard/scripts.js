document.addEventListener('DOMContentLoaded', () => {
    const collapsibleHeaders = document.querySelectorAll('.dashboard-section h3');

    collapsibleHeaders.forEach(header => {
        header.style.cursor = 'pointer'; // Make headers look clickable
        const sectionContent = header.nextElementSibling; // Next sibling after header

        // Initially collapse all sections
        sectionContent.style.display = 'none';

        // Add click event listener
        header.addEventListener('click', () => {
            if (sectionContent.style.display === 'none') {
                sectionContent.style.display = 'block';
                header.style.color = '#005fa3'; // Highlight when expanded
            } else {
                sectionContent.style.display = 'none';
                header.style.color = '#007acc'; // Reset color when collapsed
            }
            
        });
    });
    document.addEventListener("DOMContentLoaded", function () {
    // Form Validation
    const forms = document.querySelectorAll("form");
    
    forms.forEach(form => {
        form.addEventListener("submit", function (event) {
            const inputs = form.querySelectorAll("input[required], select[required], textarea[required]");
            let valid = true;
            
            inputs.forEach(input => {
                if (!input.value) {
                    input.style.border = "1px solid red";
                    valid = false;
                } else {
                    input.style.border = "";
                }
            });
            
            if (!valid) {
                event.preventDefault();
                alert("Please fill out all required fields.");
            }
        });
    });

    // Print Results
    const printButtons = document.querySelectorAll('button[onclick="window.print()"]');
    
    printButtons.forEach(button => {
        button.addEventListener("click", function () {
            window.print();
        });
    });

});

