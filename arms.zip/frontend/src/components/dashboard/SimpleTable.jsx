//SimpleTable.jsx
import React from 'react';
import PropTypes from 'prop-types';
import {
  withStyles,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Paper
} from '@material-ui/core';

var styles = {
  root: {
    width: '100%',
    overflowX: 'auto',
  },
  table: {
    minWidth: 700,
  },
};


function SimpleTable({ classes, data, columns }) {
  return (
    <Paper className={classes.root}>
            <Table className={classes.table}>
                <TableHead>
                    <TableRow>
                        {columns.map((column) => (
                            <TableCell key={column}>{column}</TableCell>
                         ))}
                    </TableRow>
                </TableHead>
             <TableBody>
                    {data.map((row, index) => (
                        <TableRow key={index}>
                         {columns.map((column) => (
                                 <TableCell key={column}>{row[column]}</TableCell>
                            ))}
                       </TableRow>
                  ))}
                </TableBody>
            </Table>
        </Paper>
  );
}

SimpleTable.propTypes = {
  classes: PropTypes.object.isRequired,
  columns: PropTypes.arrayOf(PropTypes.string).isRequired,
  data: PropTypes.arrayOf(PropTypes.object).isRequired,
};

export default withStyles(styles)(SimpleTable);