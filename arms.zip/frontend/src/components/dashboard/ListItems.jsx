// ListItems.jsx
import React from 'react';

export const getMenuItems = (role) => {
  if (role === 'admin') {
    return [
      {
        title: 'System Admin',
        items: [
          { path: "/system-settings", label: 'Settings' },
          { path: "/user-management", label: 'User Management' },
          { path: "/register", label: 'User Registration' },
          { path: "/manage-roles", label: 'Role Management' }
            ]
         },
       ]
  } else {
    return [
      {
        title: 'Create Project',
        items: [
          { path: '/dashboard', label: 'Project Dashboard' },
          { path: '/create-project', label: 'Create Project' },
          { path: '/invite-collaborators', label: 'Invite Collaborators' },
            ],
        subMenus: [{
          title: 'Collaboration',
          items: [
            { path: '/project-collaboration', label: 'Project Collaboration' },
            { path: '/assign-task', label: 'Assign Task' },
            { path: '/task-list', label: 'Task List' },
            { path: '/notifications', label: 'Notifications' },
            { path: '/version-control', label: 'Version Control' }
                    ]
              }]
         },
      {
        title: 'Planning Review',
        subMenus: [{
            title: 'Protocol Management',
            items: [
              { path: '/create-protocol', label: 'Create Protocol' },
              { path: '/edit-protocol', label: 'Edit Protocol' },
              { path: '/view-versions', label: 'View Versions' },
              { path: '/generate-protocol', label: 'Generate Protocol' },
                  ]
                 },
          {
            title: 'Design Search Query',
            items: [
              { path: '/select-databases', label: 'Select Databases' },
              { path: '/create-query-form', label: 'Create Query Form' },
              { path: '/create-query', label: 'Create Query' },
              { path: '/translations', label: 'Translate Databases' },
              { path: '/query-dashboard', label: 'Query Dashboard' },
                    ]
                },
          {
            title: 'Create Data Forms',
            items: [
              { path: '/create_form', label: 'Create Data Form' },
              { path: '/test_data_form', label: 'Test Data Form' },
                     ]
                },
          {
            title: 'Design Quality Assessment',
            items: [
              { path: '/create_quality_assessment_form', label: 'Create Quality Assessment Form' }
                    ]
              }]
         },
      {
        title: 'Perform Review',
        subMenus: [{
            title: 'Title-Abstract Screening',
            items: [
              { path: '/upload_studies', label: 'Upload Studies' },
              { path: '/deduplicate_studies', label: 'De-deuplicate Studies' },
              { path: '/screen_studies', label: 'Screen Studies' },
              { path: '/resolve_conflicts', label: 'Resolve Conflicts' },
                 ]
               },
          {
            title: 'Full-Text Screening',
            items: [
              { path: '/full_text_screening', label: 'Full-Text Screening' }
                     ]
               },
          {
            title: 'Quality Assessment',
            items: [
              { path: '/create_quality_assessment', label: 'Create Quality Assessment' },
              { path: '/quality_assessment', label: 'Quality Assessment' },
              { path: '/review_quality_assessment', label: 'Review Quality Assessment' },
                       ]
                   },
          {
            title: 'Data Extraction',
            items: [
              { path: '/create_form', label: 'Create Extraction Form' },
              { path: '/manage_studies', label: 'Manage Studies' },
              { path: '/data_extraction', label: 'Data Extraction' },
              { path: '/review_extracted_data', label: 'Review Extracted Data' },
                     ]
               }]
           },
      {
        title: 'Data Synthesis',
        subMenus: [{
          title: 'Synthesis Actions',
          items: [
            { path: '/data_synthesis', label: 'Data Synthesis' },
            { path: '/data_synthesis_result', label: 'Synthesis Results' },
            { path: '/qualitative_synthesis', label: 'Qualitative Synthesis' },
            { path: '/qualitative_synthesis_result', label: 'Qualitative Results' },
                 ]
               }, {
          title: 'Sensitivity Analysis',
          items: [
            { path: '/sensitivity_analysis', label: 'Sensitivity Analysis' },
            { path: '/sensitivity_analysis_result', label: 'Sensitivity Results' },
                     ]
               }]
           },
      {
        title: 'Reporting',
        subMenus: [
          {
            title: 'Visualize',
            items: [
              { path: '/view_trends', label: 'Visualize Data' },
              { path: '/view_charts', label: 'Figure Charts' },
              { path: '/data_tables', label: 'Data Tables' },
                 ]
                },
          {
            title: 'Export',
            items: [
              { path: '/prisma_diagram', label: 'PRISMA Diagram' },
              { path: '/generate_prisma', label: 'Generate PRISMA' },
              { path: '/generate_manuscript', label: 'Generate Manuscript' }
                  ]
                }
               ]
           }
         ]
  }
};