import React, { useState } from 'react';
import styles from './Login.module.css' // Import styles for login

const Login = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [usernameEmail, setUsernameEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleTogglePassword = () => {
    setShowPassword(!showPassword);
  };

  const handleLogin = async () => {
    // Validate input
    if (!usernameEmail || !password) {
       alert('Please fill in all required fields.');
       return;
     }

    try {
     // Send login data to the database (example using fetch)
     const response = await fetch('http://10.180.50.140:3306/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
         body: JSON.stringify({ usernameEmail, password }),
       });

      if (response.ok) {
         alert('Login successful!');
         // Redirect to the user dashboard or desired page
         window.location.href = '/dashboard.html';
       } else {
        alert('Invalid login credentials. Please try again.');
       }
     } catch (error) {
       console.error('Error:', error);
       alert('An error occurred. Please try again later.');
     }
   };

  const handleForgotPassword = async () => {
     if (!usernameEmail) {
        alert('Please enter your email to reset your password.');
        return;
      }

    try {
        // Send a password reset request
        const response = await fetch('http://10.180.50.140:3306/forgot-password', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
           body: JSON.stringify({ email: usernameEmail }),
          });

      if (response.ok) {
         alert('Password reset email sent successfully. Please check your inbox.');
      } else {
         alert('Unable to send password reset email. Please try again later.');
       }
    } catch (error) {
      console.error('Error:', error);
        alert('An error occurred. Please try again later.');
      }
    };


  return (
      <div className={styles.loginContainer}>
        <h1 style={{textAlign: 'right', color:'white'}}>Sign In</h1>
      
        <div className={styles.inputGroup}>
            <input
                type="text"
                id="usernameEmail"
                name="usernameEmail"
                placeholder="Username or Email..."
                required
                onChange={(e) => setUsernameEmail(e.target.value)}
            />
        </div>
        <div style={{ position: 'relative' }}>
          <input
            type={showPassword ? 'text' : 'password'}
            id="loginPassword"
            name="password"
            placeholder="Enter password..."
            required
            onChange={(e) => setPassword(e.target.value)}
            />
             <button
              type="button"
               id="togglePassword"
               onClick={handleTogglePassword}
               className={styles.togglePassword}
               >
                {showPassword ? 'Hide' : 'Show'}
              </button>
        </div>
      
        <div style={{ textAlign: 'right', margin: '10px 0' }}>
             <a href="#" id="forgotPassword" style={{color: '#35424a', fontSize: '14px'}} onClick={handleForgotPassword}>Forgot Password?</a>
        </div>
      
         <button type="button" id="loginButton" className={styles.button1} onClick={handleLogin}>Login</button>
       <div style={{textAlign:'center', marginTop:'15px'}}>
          <button type="button" className={styles.button1}>
                <a href="registration.html" style={{color:'white', textDecoration: 'none'}}>Create Account</a>
                </button>
           </div>
      </div>
  );
};

export default Login;