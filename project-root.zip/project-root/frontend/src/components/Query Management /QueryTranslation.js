// QueryTranslation.js
import React, { useState } from 'react';
import styles from './QueryTranslation.module.css';

const QueryTranslation = ({selectedDatabases}) => {
  const [queryToTranslate, setQueryToTranslate] = useState('');
  const [translatedQueries, setTranslatedQueries] = useState({});
    const token = localStorage.getItem('token');


    const handleQueryChange = (e) => {
        setQueryToTranslate(e.target.value);
    };

  const handleTranslateQuery = async () => {
      if (!selectedDatabases || selectedDatabases.length === 0) {
        alert('Please select databases before translating query.');
           return;
       }
    try {
          const response = await fetch('http://10.180.50.140:3306/search/translate-query', {
              method: 'POST',
             headers: {
                'Content-Type': 'application/json',
                  'Authorization': `Bearer ${token}`,
              },
             body: JSON.stringify({ query: queryToTranslate, databases: selectedDatabases }),
           });

           if (response.ok) {
              const data = await response.json();
                setTranslatedQueries(data);
            } else {
               const errorData = await response.json();
                console.error('Failed to translate query:', errorData);
                 alert('Failed to translate query');
            }
        } catch (error) {
            console.error('Error translating query:', error);
             alert('An error occurred during query translation.')
        }
  };


  return (
    <div className={styles.translationContainer}>
      <h1>Query Translation</h1>
        {selectedDatabases && selectedDatabases.length > 0 ? (
            <>
      <textarea
          placeholder="Enter Query to Translate"
         value={queryToTranslate}
          onChange={handleQueryChange}
           className={styles.translationInput}
        />
      <button onClick={handleTranslateQuery} className={styles.translateButton}>Translate</button>
      <div className={styles.translatedQueries}>
      {Object.keys(translatedQueries).map(database => (
          <div key={database} className={styles.translatedQuery}>
              <h2>{database}</h2>
              <p>{translatedQueries[database]}</p>
           </div>
      ))}
      </div>
            </>
         ) : (
             <p>Select Databases in order to Translate.</p>
         )}
    </div>
  );
};

export default QueryTranslation;