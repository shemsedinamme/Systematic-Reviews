// SearchQueryBuilder.js
import React, { useState, useEffect } from 'react';
import styles from './SearchQueryBuilder.module.css';

const SearchQueryBuilder = ({selectedDatabases}) => {
    const [searchFields, setSearchFields] = useState([
        {id: 1, label: 'Title', code: 'title'},
        {id: 2, label: 'Abstract', code: 'abstract'},
        {id: 3, label: 'Author', code: 'author'},
         {id: 4, label: 'Journal', code: 'journal'},
          {id: 5, label: 'MESH Terms', code: 'mesh'}
    ]);
  const [query, setQuery] = useState('');
    const [field, setField] = useState('title');
    const [searchTerm, setSearchTerm] = useState('');
    const [savedQueries, setSavedQueries] = useState([]);
    const token = localStorage.getItem('token');


  useEffect(() => {
        const fetchSavedQueries = async () => {
             try {
                 const response = await fetch('http://10.180.50.140:3306/search/query-builder', {
                     method: 'GET',
                      headers: {
                          'Content-Type': 'application/json',
                          'Authorization': `Bearer ${token}`,
                     },
                 });
                 if (response.ok) {
                      const data = await response.json();
                      setSavedQueries(data);
                  } else {
                     console.error('Failed to fetch saved queries');
                    alert('Failed to fetch saved queries')
                }
            } catch (error) {
              console.error('Error fetching saved queries:', error);
              alert('Error fetching saved queries')
            }
       };
       fetchSavedQueries();
    }, []);

    const handleAddField = () => {
      if(!searchTerm) return;
      setQuery(prevQuery =>
          prevQuery ? `${prevQuery} ${field}:(${searchTerm})` : `${field}:(${searchTerm})`
      );
        setSearchTerm('')
    };

  const handleAddBoolean = (operator) => {
     setQuery(prevQuery => `${prevQuery} ${operator}`);
  };
  const handleSaveQuery = async () => {
     try {
         const response = await fetch('http://10.180.50.140:3306/search/query-builder', {
           method: 'POST',
             headers: {
                 'Content-Type': 'application/json',
                  'Authorization': `Bearer ${token}`,
             },
             body: JSON.stringify({search_query: query, databases: selectedDatabases}),
         });
          if (response.ok) {
                const data = await response.json();
              setSavedQueries([...savedQueries, data])
                alert('Query saved successfully')
           } else {
               console.error('Failed to save query');
              alert('Failed to save query')
           }
       } catch (error) {
           console.error('Error saving query:', error);
          alert('Error saving query')
       }

  };

 const handleSearch = async () => {
      //TODO: Implement search functionality with the generated query
       try {
         const response = await fetch(`http://10.180.50.140:3306/articles?query=${query}`, {
             method: 'GET',
            headers: {
                 'Content-Type': 'application/json',
                 'Authorization': `Bearer ${token}`,
            },
         });

            if (response.ok) {
               const data = await response.json();
                console.log("Search Result", data);
               alert('Search Successful, results in console log');
           } else {
               console.error('Search failed:', response);
                alert('Search Failed')
           }
      } catch (error) {
         console.error('Error searching:', error);
         alert('An error occurred while searching.')
     }

 };


  return (
    <div className={styles.queryBuilderContainer}>
      <h1>Search Query Builder</h1>
      <div className={styles.queryForm}>
         <select
             value={field}
            onChange={(e) => setField(e.target.value)}
           className={styles.selectInput}
             >
               {searchFields.map(searchField=>(
                <option key={searchField.id} value={searchField.code}>{searchField.label}</option>
              ))}
          </select>
            <input
               type="text"
                placeholder="Search term"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className={styles.queryInput}
             />
            <button onClick={handleAddField} className={styles.addButton}>Add field</button>
        </div>
        <div className={styles.queryActions}>
            <button onClick={() => handleAddBoolean('AND')} className={styles.booleanButton}>AND</button>
            <button onClick={() => handleAddBoolean('OR')} className={styles.booleanButton}>OR</button>
            <button onClick={() => handleAddBoolean('NOT')} className={styles.booleanButton}>NOT</button>
        </div>
      <div className={styles.queryDisplay}>
       <textarea
             value={query}
          placeholder="Generated Query"
             readOnly
             className={styles.queryTextarea}
           />
           </div>
        <div className={styles.saveAndSearch}>
        <button onClick={handleSaveQuery} className={styles.saveButton}>Save Query</button>
        <button onClick={handleSearch} className={styles.searchButton}>Search</button>
         </div>
          <div className={styles.savedQueries}>
               <h2>Saved Queries</h2>
               <ul>
                   {savedQueries.map(savedQuery => (
                     <li key={savedQuery.search_query_id}>{savedQuery.search_query}</li>
                   ))}
               </ul>
            </div>
    </div>
  );
};

export default SearchQueryBuilder;