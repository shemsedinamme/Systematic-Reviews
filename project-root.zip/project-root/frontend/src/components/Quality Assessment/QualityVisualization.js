// QualityVisualization.js
import React, { useState, useEffect } from 'react';
import styles from './QualityVisualization.module.css';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const QualityVisualization = ({ projectId }) => {
  const [visualizationData, setVisualizationData] = useState(null);
    const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchVisualizationData = async () => {
      try {
        const response = await fetch(`http://10.180.50.140:3306/quality-assessment/visualization?project_id=${projectId}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`,
          },
        });
        if (response.ok) {
          const data = await response.json();
            setVisualizationData(data);
        } else {
            console.error('Failed to fetch quality assessment visualization data');
        }
      } catch (error) {
          console.error('Error fetching quality assessment visualization data:', error);
       }
    };
      if(projectId){
         fetchVisualizationData()
      }

  }, [projectId]);

  if (!projectId) {
        return <p>Select a project to view quality assessment data.</p>
    }
    if(!visualizationData){
        return <p>Loading quality assessment data...</p>
    }

    const chartData = {
        labels: visualizationData.map(item => item.study_id),
         datasets: [{
             label: 'Risk of Bias',
           data: visualizationData.map(item => item.average_risk_rating),
           backgroundColor: 'rgba(75,192,192,0.6)',
           borderColor: 'rgba(75,192,192,1)',
            borderWidth: 1,
         }],
    };

    const chartOptions = {
         responsive: true,
         plugins: {
            legend: {
               position: 'top',
           },
          title: {
             display: true,
              text: 'Average risk of bias per study',
          },
        },
    };

  return (
    <div className={styles.visualizationContainer}>
      <h1>Quality Assessment Data Visualization</h1>
         {visualizationData && visualizationData.length > 0 ? (
            <>
               <div className={styles.chartContainer}>
                <Bar data={chartData} options={chartOptions}/>
                </div>
             <div className={styles.summaryTable}>
               <h2>Summary Table:</h2>
                <table>
                  <thead>
                   <tr>
                    <th>Study ID</th>
                   <th>Reviewer</th>
                      <th>Tool</th>
                     <th>Average Risk Rating</th>
                 </tr>
                   </thead>
                     <tbody>
                        {visualizationData.map(item => (
                       <tr key={item.study_id}>
                            <td>{item.study_id}</td>
                         <td>{item.reviewer}</td>
                         <td>{item.tool_name}</td>
                           <td>{item.average_risk_rating}</td>
                      </tr>
                       ))}
                   </tbody>
               </table>
                </div>
            </>
        ) : (
        <p>No quality assessment data available</p>
      )}

    </div>
  );
};

export default QualityVisualization;