// UserProfile.js
import React, { useState, useEffect } from 'react';
import styles from './UserProfile.module.css';

const UserProfile = () => {
  const [user, setUser] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [updatedUser, setUpdatedUser] = useState({});
    const token = localStorage.getItem('token'); //retrieve user token from localStorage

  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
          const response = await fetch('http://10.180.50.140:3306/profile', {
              method: 'GET',
            headers: {
              'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
          });

        if (response.ok) {
          const data = await response.json();
          setUser(data);
            setUpdatedUser(data)
        } else {
          console.error('Failed to fetch user profile');
        }
      } catch (error) {
        console.error('Error fetching user profile:', error);
      }
    };

    fetchUserProfile();
  }, []);

  const handleInputChange = (e) => {
    setUpdatedUser({
      ...updatedUser,
      [e.target.name]: e.target.value,
    });
  };

  const handleUpdateProfile = async () => {
    try {
        const response = await fetch('http://10.180.50.140:3306/profile', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
          body: JSON.stringify(updatedUser),
        });

      if (response.ok) {
        const updatedData = await response.json();
          setUser(updatedData);
        setEditMode(false);
      } else {
          console.error('Failed to update user profile');
          alert('Failed to update user profile')
      }
    } catch (error) {
      console.error('Error updating user profile:', error);
        alert('Error updating user profile:')
    }
  };

  const handleCancelEdit = () => {
    setUpdatedUser(user);
    setEditMode(false);
  };


    if (!user) {
        return <div>Loading user profile...</div>;
    }

  return (
    <div className={styles.profileContainer}>
      <h1>User Profile</h1>
      {!editMode ? (
        <div className={styles.profileDetails}>
          <p>
            <strong>Username:</strong> {user.username}
          </p>
          <p>
            <strong>Email:</strong> {user.email}
          </p>
            <p>
                <strong>Role:</strong> {user.role}
            </p>
             <button type="button" className={styles.editButton} onClick={() => setEditMode(true)}>
              Edit Profile
            </button>
        </div>
      ) : (
        <div className={styles.profileEditForm}>
          <input
            type="text"
            name="username"
            placeholder="Username"
            value={updatedUser.username}
            onChange={handleInputChange}
              className={styles.profileInput}
          />
          <input
            type="email"
            name="email"
            placeholder="Email"
            value={updatedUser.email}
            onChange={handleInputChange}
              className={styles.profileInput}
          />
            <button type="button" className={styles.saveButton} onClick={handleUpdateProfile}>
            Save
          </button>
             <button type="button" className={styles.cancelButton} onClick={handleCancelEdit}>
              Cancel
          </button>
        </div>
      )}

    </div>
  );
};

export default UserProfile;