// UserList.js
import React, { useState, useEffect } from 'react';
import styles from './UserList.module.css';

const UserList = () => {
  const [users, setUsers] = useState([]);
  const [editUserId, setEditUserId] = useState(null);
  const [updatedUser, setUpdatedUser] = useState({});
  const token = localStorage.getItem('token');


  useEffect(() => {
    const fetchUsers = async () => {
      try {
         const response = await fetch('http://10.180.50.140:3306/admin/users', {
           method: 'GET',
           headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`,
           },
         });

        if (response.ok) {
          const data = await response.json();
          setUsers(data);
        } else {
          console.error('Failed to fetch users');
        }
      } catch (error) {
        console.error('Error fetching users:', error);
      }
    };
    fetchUsers();
  }, []);

  const handleEdit = (user) => {
     setEditUserId(user.user_id);
    setUpdatedUser({
      username: user.username,
      email: user.email,
      role: user.role,
      user_id: user.user_id
    });
  };

   const handleInputChange = (e) => {
     setUpdatedUser({
       ...updatedUser,
        [e.target.name]: e.target.value,
     });
    };

  const handleUpdateUser = async () => {
    try {
      const response = await fetch(`http://10.180.50.140:3306/admin/users/${editUserId}`, {
        method: 'PUT',
         headers: {
             'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
           },
        body: JSON.stringify(updatedUser),
      });

      if (response.ok) {
         const updatedData = await response.json();
        setUsers(users.map(user => user.user_id === updatedData.user_id ? updatedData : user));
        setEditUserId(null);
      } else {
           console.error('Failed to update user');
          alert('Failed to update user')
       }
    } catch (error) {
         console.error('Error updating user:', error);
         alert('Error updating user')
    }
  };

   const handleDeleteUser = async (userId) => {
    try {
       const response = await fetch(`http://10.180.50.140:3306/admin/users/${userId}`, {
          method: 'DELETE',
           headers: {
              'Authorization': `Bearer ${token}`,
            },
        });

      if (response.ok) {
         setUsers(users.filter(user => user.user_id !== userId));
        } else {
         console.error('Failed to delete user');
         alert('Failed to delete user')
      }
    } catch (error) {
     console.error('Error deleting user:', error);
        alert('Error deleting user')
    }
  };


  const handleCancelEdit = () => {
     setUpdatedUser({});
      setEditUserId(null);
    };
    
  if (!users) {
    return <div>Loading users...</div>;
  }

  return (
    <div className={styles.userListContainer}>
      <h1>User List</h1>
       {users.length === 0 ? (
            <p>No users are available.</p>
        ) : (
        <table className={styles.userTable}>
          <thead>
            <tr>
              <th>Username</th>
              <th>Email</th>
              <th>Role</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
                <tr key={user.user_id}>
                  <td>
                      {editUserId === user.user_id ? (
                          <input
                              type="text"
                              name="username"
                              value={updatedUser.username}
                               onChange={handleInputChange}
                           />
                         ) : (
                                user.username
                                )}
                   </td>
                     <td>
                      {editUserId === user.user_id ? (
                         <input
                              type="email"
                             name="email"
                             value={updatedUser.email}
                           onChange={handleInputChange}
                          />
                        ) : (
                        user.email
                      )}
                   </td>
                   <td>
                     {editUserId === user.user_id ? (
                      <select name="role" value={updatedUser.role} onChange={handleInputChange}>
                            <option value="lead_author">Lead Author</option>
                            <option value="reviewer">Reviewer</option>
                            <option value="data_extractor">Data Extractor</option>
                            <option value="admin">Admin</option>
                       </select>
                    ) : (
                      user.role
                      )}
                    </td>
                    <td>
                      {editUserId === user.user_id ? (
                       <>
                          <button className={styles.updateButton} onClick={handleUpdateUser}>Save</button>
                            <button className={styles.cancelButton} onClick={handleCancelEdit}>Cancel</button>
                       </>
                    ) : (
                          <>
                         <button className={styles.editButton} onClick={() => handleEdit(user)}>Edit</button>
                            <button className={styles.deleteButton} onClick={() => handleDeleteUser(user.user_id)}>Delete</button>
                            </>
                     )}
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
         )}
    </div>
  );
};

export default UserList;