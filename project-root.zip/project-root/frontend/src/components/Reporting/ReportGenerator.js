// ReportGenerator.js
import React, { useState, useEffect } from 'react';
import styles from './ReportGenerator.module.css';

const ReportGenerator = ({ projectId }) => {
  const [templates, setTemplates] = useState([]);
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [report, setReport] = useState(null);
    const token = localStorage.getItem('token');
    const [message, setMessage] = useState('');

  useEffect(() => {
    const fetchTemplates = async () => {
      try {
          const response = await fetch('http://10.180.50.140:3306/reports/templates', {
             method: 'GET',
                headers: {
                   'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`,
                },
           });
            if (response.ok) {
                 const data = await response.json();
              setTemplates(data);
             } else {
                 console.error('Failed to fetch report templates');
            }
      } catch (error) {
        console.error('Error fetching report templates:', error);
      }
    };
        if(projectId){
          fetchTemplates()
        }
  }, [projectId]);


  const handleTemplateChange = (e) => {
      setSelectedTemplate(e.target.value);
  };

  const handleGenerateReport = async () => {
      if(!selectedTemplate){
          setMessage('Please Select a Template');
         return;
      }
    try {
      const response = await fetch(`http://10.180.50.140:3306/reports`, {
        method: 'POST',
          headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`,
         },
         body: JSON.stringify({project_id: projectId, template_id: selectedTemplate}),
      });
        if(response.ok){
           const data = await response.json()
             setReport(data);
             setMessage('Report generated, check console for report data.')
             console.log("Generated Report:", data);
        } else {
          const errorData = await response.json();
             console.error('Failed to generate report:', errorData);
            setMessage('Failed to generate report.')
       }
    } catch (error) {
      console.error('Error generating report:', error);
       setMessage('Error generating report.')
    }
  };


  const handleExportReport = async (format) => {
        if(!report) {
            setMessage('Generate report first before exporting')
            return;
        }
       try {
         const response = await fetch(`http://10.180.50.140:3306/reports/${report.report_id}/export/${format}`, {
             method: 'GET',
              headers: {
                  'Authorization': `Bearer ${token}`,
               },
         });
           if (response.ok) {
                const blob = await response.blob();
               const url = window.URL.createObjectURL(blob);
                 const a = document.createElement('a');
              a.href = url;
                a.download = `report.${format}`;
                 document.body.appendChild(a);
                 a.click();
                window.URL.revokeObjectURL(url);
                 document.body.removeChild(a);
          } else {
            console.error(`Failed to export report as ${format}`);
               alert(`Failed to export report as ${format}`);
          }
      } catch (error) {
        console.error(`Error exporting report as ${format}:`, error);
        alert(`An error occurred while exporting the report as ${format}`)
      }
    };


  if (!projectId) {
    return <p>Select a project to generate reports.</p>;
  }

  return (
    <div className={styles.reportContainer}>
      <h1>Report Generation</h1>
          <select
              value={selectedTemplate}
             onChange={handleTemplateChange}
             className={styles.templateSelect}
           >
              <option value="" disabled selected>Select a Report Template</option>
             {templates.map((template) => (
               <option key={template.template_id} value={template.template_id}>
                 {template.template_name}
               </option>
             ))}
        </select>
      <button onClick={handleGenerateReport} className={styles.generateButton}>Generate Report</button>
      {report && (
       <div className={styles.exportOptions}>
             <button onClick={() => handleExportReport('pdf')}  className={styles.exportButton}>Export PDF</button>
            <button onClick={() => handleExportReport('word')}  className={styles.exportButton}>Export Word</button>
            <button onClick={() => handleExportReport('excel')} className={styles.exportButton}>Export Excel</button>
            <button onClick={() => handleExportReport('csv')} className={styles.exportButton}>Export CSV</button>
        </div>
         )}
      {message && <p className={styles.message}>{message}</p>}
    </div>
  );
};

export default ReportGenerator;