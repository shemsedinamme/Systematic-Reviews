// ProtocolTemplate.js
import React, { useState, useEffect } from 'react';
import styles from './ProtocolTemplate.module.css';
import { v4 as uuidv4 } from 'uuid';

const ProtocolTemplate = () => {
    const [templates, setTemplates] = useState([]);
    const [newTemplate, setNewTemplate] = useState({
        template_name: '',
        template_description: '',
        sections: [],
    });
    const [newSection, setNewSection] = useState('');
    const [selectedTemplate, setSelectedTemplate] = useState('');
    const token = localStorage.getItem('token');

    useEffect(() => {
        const fetchTemplates = async () => {
            try {
                const response = await fetch('http://10.180.50.140:3306/templates', {
                   method: 'GET',
                   headers: {
                       'Content-Type': 'application/json',
                       'Authorization': `Bearer ${token}`,
                   },
                });

                if (response.ok) {
                    const data = await response.json();
                     setTemplates(data);
                } else {
                    console.error('Failed to fetch protocol templates');
                }
            } catch (error) {
               console.error('Error fetching protocol templates:', error);
            }
        };
        fetchTemplates();
    }, []);


    const handleInputChange = (e) => {
        setNewTemplate({ ...newTemplate, [e.target.name]: e.target.value });
    };
    const handleAddSection = () => {
        if(!newSection) return;
        setNewTemplate({
           ...newTemplate,
          sections: [...newTemplate.sections, { section_id: uuidv4(), section_name: newSection, data_fields: [], }],
         });
        setNewSection('')
    };

    const handleAddDataField = (sectionId, dataField) => {
        setNewTemplate({
            ...newTemplate,
            sections: newTemplate.sections.map((section) =>
               section.section_id === sectionId ?
              {...section, data_fields: [...section.data_fields, {field_id: uuidv4(), field_name: dataField}]}
            : section
            )
          });
    }

    const handleDeleteSection = (sectionId) => {
        setNewTemplate({
           ...newTemplate,
            sections: newTemplate.sections.filter(section => section.section_id !== sectionId)
        })
    }
    const handleCreateTemplate = async () => {
        try {
            const response = await fetch('http://10.180.50.140:3306/templates', {
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`,
               },
                body: JSON.stringify(newTemplate),
            });

            if (response.ok) {
                 const updatedData = await response.json();
               setTemplates([...templates, updatedData]);
                setNewTemplate({template_name: '', template_description:'', sections: []})
            } else {
                console.error('Failed to create new template');
                  alert('Failed to create new template')
           }
        } catch (error) {
            console.error('Error creating new template:', error);
            alert('Error creating new template:')
        }
    };


  const handleShareTemplate = async (templateId) => {
      try {
        const response = await fetch(`http://10.180.50.140:3306/templates/${templateId}/share`, {
           method: 'POST',
           headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`,
            },
          body: JSON.stringify({ share: true }),
        });
            if (response.ok) {
             alert('Template shared successfully');
           } else {
               console.error('Failed to share template');
             alert('Failed to share template');
          }
       } catch (error) {
           console.error('Error sharing template:', error);
           alert('Error sharing template');
       }
    };
     const fetchTemplate = async (templateId) => {
         try {
           const response = await fetch(`http://10.180.50.140:3306/templates/${templateId}`, {
               method: 'GET',
             headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
            });
           if (response.ok) {
             const data = await response.json();
               setNewTemplate(data);
               setSelectedTemplate(templateId);
           } else {
               console.error('Failed to fetch template');
            }
        } catch (error) {
            console.error('Error fetching template:', error);
       }
    };
  return (
        <div className={styles.templateContainer}>
            <h1>Protocol Templates</h1>
           <div className={styles.templateList}>
             <h2>Existing Templates</h2>
               {templates.map(template => (
                <div key={template.template_id} className={styles.templateItem}>
                     <span>{template.template_name}</span>
                      <button onClick={()=>fetchTemplate(template.template_id)} className={styles.selectButton}>Select</button>
                      <button onClick={()=>handleShareTemplate(template.template_id)} className={styles.shareButton}>Share</button>
                 </div>
               ))}
             </div>

             <div className={styles.newTemplate}>
                <h2>Create Template</h2>
               <input
                   type="text"
                   name="template_name"
                    placeholder="Template title"
                   value={newTemplate.template_name}
                    onChange={handleInputChange}
                   className={styles.templateInput}
                />
                <textarea
                     name="template_description"
                     placeholder="Template description"
                     value={newTemplate.template_description}
                     onChange={handleInputChange}
                    className={styles.templateInput}
                />
                <div className={styles.addSection}>
                    <input
                        type="text"
                        placeholder="Add new section"
                       value={newSection}
                         onChange={(e) => setNewSection(e.target.value)}
                         className={styles.templateInput}
                    />
                  <button onClick={handleAddSection} className={styles.addButton}>Add section</button>
                 </div>
                 {newTemplate.sections.map(section => (
                   <div key={section.section_id} className={styles.sectionItem}>
                     <h3>{section.section_name}</h3>
                       <div className={styles.addDataField}>
                            <input
                            type="text"
                             placeholder="Add new data field"
                             className={styles.templateInput}
                             onKeyDown={(e) => e.key === 'Enter' && handleAddDataField(section.section_id, e.target.value)}
                            />
                         </div>
                           {section.data_fields && (
                               <ul className={styles.dataFieldList}>
                                 {section.data_fields.map(field => (
                                    <li key={field.field_id}>{field.field_name}</li>
                                 ))}
                            </ul>
                          )}
                       <button onClick={()=>handleDeleteSection(section.section_id)} className={styles.deleteButton}>Delete Section</button>

                    </div>
                 ))}

                 <button onClick={handleCreateTemplate} className={styles.createButton}>Create Template</button>
            </div>
        </div>
    );
};

export default ProtocolTemplate;