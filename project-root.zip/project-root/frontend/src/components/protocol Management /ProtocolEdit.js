// ProtocolEdit.js
import React, { useState, useEffect, useRef } from 'react';
import styles from './ProtocolEdit.module.css';
import { CKEditor } from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

const ProtocolEdit = ({ protocolId }) => {
  const [protocol, setProtocol] = useState(null);
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
    const [versionHistory, setVersionHistory] = useState([]);
  const token = localStorage.getItem('token');
     const editorRef = useRef(null);

    useEffect(() => {
        const fetchProtocol = async () => {
            try {
                const response = await fetch(`http://10.180.50.140:3306/protocols/${protocolId}`, {
                   method: 'GET',
                     headers: {
                        'Content-Type': 'application/json',
                         'Authorization': `Bearer ${token}`,
                     },
                });
                if (response.ok) {
                   const data = await response.json();
                   setProtocol(data);
               } else {
                    console.error('Failed to fetch protocol');
               }
         } catch (error) {
            console.error('Error fetching protocol:', error);
         }
        };


      const fetchComments = async () => {
         try {
           const response = await fetch(`http://10.180.50.140:3306/protocols/${protocolId}/comments`, {
              method: 'GET',
              headers: {
                 'Content-Type': 'application/json',
                  'Authorization': `Bearer ${token}`,
               },
           });
            if (response.ok) {
                  const data = await response.json();
                  setComments(data);
            } else {
                console.error('Failed to fetch comments');
            }
        } catch (error) {
          console.error('Error fetching comments:', error);
         }
     };
        const fetchVersionHistory = async () => {
          try {
            const response = await fetch(`http://10.180.50.140:3306/protocols/${protocolId}/versions`, {
                method: 'GET',
               headers: {
                    'Content-Type': 'application/json',
                     'Authorization': `Bearer ${token}`,
                },
            });
            if (response.ok) {
               const data = await response.json();
               setVersionHistory(data);
            } else {
                console.error('Failed to fetch version history');
           }
         } catch (error) {
             console.error('Error fetching version history:', error);
        }
    };


    if(protocolId){
        fetchProtocol();
         fetchComments();
        fetchVersionHistory();
    }
    }, [protocolId]);

    const handleEditorChange = (event, editor, sectionId) => {
      const data = editor.getData();
      setProtocol(prevProtocol => ({
        ...prevProtocol,
          sections: prevProtocol.sections.map(section =>
          section.section_id === sectionId ? { ...section, content: data } : section
        ),
      }));
    };

     const handleUpdateSection = async (sectionId) => {
      try {
          const response = await fetch(`http://10.180.50.140:3306/protocols/${protocolId}/sections/${sectionId}`, {
             method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
             body: JSON.stringify(protocol.sections.find(section => section.section_id === sectionId)),
          });

         if (response.ok) {
            console.log('Protocol section updated successfully.');
          } else {
            console.error('Failed to update section');
             alert('Failed to update section');
         }
      } catch (error) {
            console.error('Error updating section:', error);
        alert('Error updating section');
      }
  };
   const handleAddComment = async () => {
    if (!newComment) return;
       try {
           const response = await fetch(`http://10.180.50.140:3306/protocols/${protocolId}/comments`, {
              method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
              body: JSON.stringify({ text: newComment }),
           });
          if (response.ok) {
               const data = await response.json();
               setComments([...comments, data]);
                setNewComment('');
          } else {
              console.error('Failed to add comment');
                alert('Failed to add comment');
         }
       } catch (error) {
        console.error('Error adding comment:', error);
            alert('Error adding comment');
      }
  };
  const handleRevertVersion = async (versionId) => {
    try {
        const response = await fetch(`http://10.180.50.140:3306/protocols/${protocolId}/versions/${versionId}/revert`, {
            method: 'POST',
            headers: {
                 'Content-Type': 'application/json',
               'Authorization': `Bearer ${token}`,
          },
        });
          if (response.ok) {
               const data = await response.json();
            setProtocol(data);
              alert('Document version reverted to ' + versionId);
        } else {
           console.error('Failed to revert to a version.');
            alert('Failed to revert to a version.')
          }
    } catch (error) {
          console.error('Error reverting to version', error);
           alert('Error reverting to version')
    }
};


 if (!protocol) {
    return <p>Select a Protocol to edit.</p>;
  }
  return (
    <div className={styles.protocolEditContainer}>
      <h1>Edit Protocol: {protocol.title}</h1>
        <div className={styles.sectionList}>
          {protocol.sections.map((section) => (
              <div key={section.section_id} className={styles.sectionItem}>
              <h2>{section.section_name}</h2>
                <CKEditor
                     editor={ClassicEditor}
                     data={section.content || ''}
                    onChange={(event, editor) => handleEditorChange(event, editor, section.section_id)}
                  />
                <button  className={styles.saveButton} onClick={()=>handleUpdateSection(section.section_id)}>Save Section</button>
              </div>
           ))}
       </div>
        <div className={styles.commentsSection}>
            <h2>Comments</h2>
          <div className={styles.commentsList}>
            {comments.map(comment => (
                <div key={comment.comment_id} className={styles.comment}>
                    <p>{comment.text}</p>
                 </div>
           ))}
          </div>
             <div className={styles.addComment}>
               <input
                   type="text"
                  placeholder="Add a comment"
                  value={newComment}
                   onChange={(e) => setNewComment(e.target.value)}
                  className={styles.commentInput}
               />
                <button onClick={handleAddComment} className={styles.addButton}>Add Comment</button>
             </div>
         </div>
        <div className={styles.versionHistory}>
            <h2>Version History</h2>
            <ul>
                {versionHistory.map(version => (
                   <li key={version.version_id}>
                        <button onClick={() => handleRevertVersion(version.version_id)}>
                            Version: {version.version_id} - Date: {new Date(version.version_date).toLocaleString()}
                        </button>
                    </li>
               ))}
            </ul>
        </div>
    </div>
  );
};

export default ProtocolEdit;