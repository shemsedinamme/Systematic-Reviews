// ProtocolVersion.js
import React, { useState, useEffect } from 'react';
import styles from './ProtocolVersion.module.css';

const ProtocolVersion = ({ protocolId }) => {
  const [versions, setVersions] = useState([]);
  const [selectedVersion, setSelectedVersion] = useState(null);
  const [versionContent, setVersionContent] = useState(null);
    const token = localStorage.getItem('token');

    useEffect(() => {
      const fetchVersionHistory = async () => {
          try {
              const response = await fetch(`http://10.180.50.140:3306/protocols/${protocolId}/versions`, {
                   method: 'GET',
                   headers: {
                       'Content-Type': 'application/json',
                      'Authorization': `Bearer ${token}`,
                   },
                });
               if (response.ok) {
                   const data = await response.json();
                 setVersions(data);
                } else {
                    console.error('Failed to fetch version history');
               }
         } catch (error) {
            console.error('Error fetching version history:', error);
         }
      };
        if(protocolId)
           fetchVersionHistory();
    }, [protocolId]);


    const handleViewVersion = async (versionId) => {
        try {
              const response = await fetch(`http://10.180.50.140:3306/versions/${versionId}`, {
                  method: 'GET',
                  headers: {
                     'Content-Type': 'application/json',
                      'Authorization': `Bearer ${token}`,
                    },
              });
                if (response.ok) {
                    const data = await response.json();
                    setVersionContent(data.content);
                     setSelectedVersion(versionId)
                } else {
                   console.error('Failed to view version');
                }
          } catch (error) {
            console.error('Error viewing version:', error);
         }
    };

    const handleRevertVersion = async (versionId) => {
          try {
              const response = await fetch(`http://10.180.50.140:3306/protocols/${protocolId}/versions/${versionId}/revert`, {
                    method: 'POST',
                     headers: {
                         'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`,
                   },
             });
              if (response.ok) {
                   alert('Protocol version reverted successfully')
                } else {
                   console.error('Failed to revert to version');
                alert('Failed to revert to version')
              }
          } catch (error) {
              console.error('Error reverting to version:', error);
            alert('Error reverting to version')
        }
    };


  if (!protocolId) {
    return <p>Select a protocol to manage versions.</p>;
  }

  return (
    <div className={styles.versionContainer}>
      <h1>Protocol Version History</h1>
         {versions && (
             <div className={styles.versionList}>
          <ul>
            {versions.map((version) => (
               <li key={version.version_id} className={styles.versionItem}>
                    Version: {version.version_id} - Date: {new Date(version.version_date).toLocaleString()}
                    <button onClick={()=>handleViewVersion(version.version_id)} className={styles.viewButton}>View</button>
                    <button onClick={()=>handleRevertVersion(version.version_id)} className={styles.revertButton}>Revert</button>
                </li>
                ))}
           </ul>
        </div>
         )}
         {selectedVersion &&  versionContent &&
             <div className={styles.versionContent}>
                <h3>Version : {selectedVersion}</h3>
               <p>Content: {versionContent}</p>
             </div>
         }
    </div>
  );
};

export default ProtocolVersion;