// ProtocolCreate.js
import React, { useState, useEffect } from 'react';
import styles from './ProtocolCreate.module.css';
import { CKEditor } from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

const ProtocolCreate = ({projectId}) => {
  const [templates, setTemplates] = useState([]);
  const [selectedTemplate, setSelectedTemplate] = useState('');
    const [protocol, setProtocol] = useState({ title: '', sections: [] });
    const [message, setMessage] = useState('');
  const token = localStorage.getItem('token');


    useEffect(() => {
        const fetchTemplates = async () => {
          try {
           const response = await fetch('http://10.180.50.140:3306/templates', {
             method: 'GET',
               headers: {
                   'Content-Type': 'application/json',
                   'Authorization': `Bearer ${token}`,
               },
          });
            if (response.ok) {
                const data = await response.json();
                 setTemplates(data);
            } else {
               console.error('Failed to fetch protocol templates');
            }
         } catch (error) {
             console.error('Error fetching protocol templates:', error);
        }
      };
    fetchTemplates();
  }, []);

    const handleTemplateChange = (e) => {
        setSelectedTemplate(e.target.value)
    };

    const handleEditorChange = (event, editor, sectionId) => {
      const data = editor.getData();
      setProtocol(prevProtocol => ({
        ...prevProtocol,
        sections: prevProtocol.sections.map(section =>
          section.section_id === sectionId ? { ...section, content: data } : section
        ),
      }));
    };

    const handleTitleChange = (e) => {
        setProtocol({...protocol, title:e.target.value})
    };


  const handleCreateProtocol = async () => {
    if (!selectedTemplate) {
     setMessage('Please select a template to create a protocol');
      return;
    }
      try {
        const response = await fetch(`http://10.180.50.140:3306/protocols`, {
           method: 'POST',
          headers: {
               'Content-Type': 'application/json',
               'Authorization': `Bearer ${token}`,
          },
            body: JSON.stringify({ template_id: selectedTemplate, title: protocol.title, project_id: projectId }),
        });
         if (response.ok) {
           const data = await response.json();
           setProtocol(data);
            setMessage('Protocol Created successfully')
           } else {
              const errorData = await response.json();
             console.error('Failed to create protocol:', errorData);
              setMessage('Failed to create Protocol')
           }
       } catch (error) {
         console.error('Error creating protocol:', error);
            setMessage('Error creating protocol');
       }
  };

  const handleUpdateSection = async (sectionId) => {
      try {
           const response = await fetch(`http://10.180.50.140:3306/protocols/${protocol.protocol_id}/sections/${sectionId}`, {
             method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                   'Authorization': `Bearer ${token}`,
                },
                 body: JSON.stringify(protocol.sections.find(section => section.section_id === sectionId)),
            });
           if (response.ok) {
               setMessage('Protocol section saved');
             } else {
                console.error('Failed to update section');
                alert('Failed to update section')
            }
       } catch (error) {
           console.error('Error updating section:', error);
         alert('Error updating section')
       }
  };

  return (
      <div className={styles.protocolCreateContainer}>
        <h1>Create Protocol</h1>
          {projectId ?(
              <>
              <div className={styles.protocolForm}>
                <input
                    type="text"
                    placeholder="Enter Protocol Title"
                     value={protocol.title}
                     onChange={handleTitleChange}
                    className={styles.protocolInput}
                />
                  <select
                    value={selectedTemplate}
                   onChange={handleTemplateChange}
                      className={styles.templateSelect}
                >
                 <option value="" disabled selected>
                    Select a template
                    </option>
                  {templates.map((template) => (
                        <option key={template.template_id} value={template.template_id}>
                         {template.template_name}
                        </option>
                    ))}
                 </select>
                  <button onClick={handleCreateProtocol} className={styles.createButton}>
                 Create Protocol
                  </button>
                 </div>
          {protocol.sections && (
            <div className={styles.sectionList}>
                {protocol.sections.map((section) => (
                    <div key={section.section_id} className={styles.sectionItem}>
                        <h2>{section.section_name}</h2>
                         <CKEditor
                            editor={ClassicEditor}
                             data={section.content || ''}
                              onChange={(event, editor) =>
                                handleEditorChange(event, editor, section.section_id)}
                             />
                         <button onClick={()=>handleUpdateSection(section.section_id)} className={styles.saveButton}> Save Section </button>
                       </div>
                  ))}
             </div>
           )}
         {message && <p className={styles.message}>{message}</p>}
              </>
          ) : (
             <p>Select a project to create a protocol.</p>
         )
        }
      </div>
    );
};

export default ProtocolCreate;