import React, {useState} from 'react';
import styles from './Registration.module.css';

const Registration = () => {

    const [subscriptionType, setSubscriptionType] = useState('');
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [studentId, setStudentId] = useState('');
    const [idCard, setIdCard] = useState(null);
    const [showStudentFields, setShowStudentFields] = useState(false)


    const handleSubscriptionChange = (e) => {
          const selectedValue = e.target.value;
        setSubscriptionType(selectedValue)
        setShowStudentFields(selectedValue === 'Student')
    };
    const handleUsernameChange = (e) => {
        setUsername(e.target.value)
    };
    const handleEmailChange = (e) => {
       setEmail(e.target.value)
    };
    const handlePasswordChange = (e) => {
       setPassword(e.target.value)
    };
    const handleStudentIdChange = (e) => {
       setStudentId(e.target.value)
    };
    const handleIdCardChange = (e) => {
      setIdCard(e.target.files[0])
    };
      const handleSubmit = async (e) => {
    e.preventDefault();

          const formData = new FormData();
          formData.append('username', username)
          formData.append('email', email)
          formData.append('password', password)
           formData.append('subscriptionOption', subscriptionType)
           if (studentId) formData.append('studentId', studentId);
           if (idCard) formData.append('idCard', idCard);

        // Validate required fields
        if (!username || !email || !password || !subscriptionType) {
          alert('Please fill in all required fields.');
          return;
        }

        try {
          const response = await fetch('http://10.180.50.140:3306/register', {
            method: 'POST',
            body: formData,
          });

          if (response.ok) {
           // Send emails
                await sendEmails(formData);
             // Show confirmation alert
                alert('Thank you for creating an account! Your registration is successful.');
                setUsername('')
                setEmail('')
                setPassword('')
                setSubscriptionType('')
                setStudentId('')
                setIdCard(null)
            setShowStudentFields(false)
          } else {
            alert('An error occurred. Please try again later.');
          }
        } catch (error) {
          console.error('Error:', error);
          alert('An error occurred. Please try again later.');
        }

     };

    async function sendEmails(formData) {
    const adminEmail = 'admin@reviewhub.net.et';
    const userEmail = formData.get('email');

    // Example email sending endpoint
    const emailEndpoint = '/send-email';

    // Send email to admin
    await fetch(emailEndpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        to: adminEmail,
        subject: 'New Account Registration',
        body: `A new account has been created.\n\nUsername: ${formData.get('username')}\nEmail: ${formData.get('email')}\nSubscription Type: ${formData.get('subscriptionOption')}`,
      }),
    });

    // Send confirmation email to subscriber
    await fetch(emailEndpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        to: userEmail,
        subject: 'Account Registration Confirmation',
        body: `Thank you for creating an account, ${formData.get('username')}! Welcome to our platform.`,
      }),
    });
  }

    return (
        <div className={styles.createAccountContainer}>
          <h1 style={{ textAlign: 'center', color: '#35424a' }}>Create Account</h1>
          <form id="registrationForm" onSubmit={handleSubmit} >
            <input
              type="text"
              id="username"
              name="username"
              placeholder="Username..."
              required
              value={username}
              onChange={handleUsernameChange}
            />
            <input
              type="email"
              id="email"
              name="email"
              placeholder="Email..."
              required
               value={email}
              onChange={handleEmailChange}
             />
            <input
              type="password"
              id="password"
              name="password"
              placeholder="Enter Password..."
              required
               value={password}
              onChange={handlePasswordChange}
             />
    
            <label htmlFor="subscriptionOption">Subscription Type:</label>
            <select
              id="subscriptionOption"
              name="subscriptionOption"
               value={subscriptionType}
               onChange={handleSubscriptionChange}
              required
            >
              <option value="" disabled selected>
                Select Subscription Type
              </option>
              <option value="Individual">Individual</option>
              <option value="Group">Group</option>
              <option value="Organizational">Organizational</option>
              <option value="Student">Student</option>
            </select>
            {showStudentFields && (
               <div id="studentFields">
                <input
                  type="text"
                  id="studentId"
                  name="studentId"
                  placeholder="Enter Student ID or Registration Number"
                    value={studentId}
                    onChange={handleStudentIdChange}
                />
                <label htmlFor="idCard">Upload Student ID Card:</label>
                <input type="file" id="idCard" name="idCard" onChange={handleIdCardChange} />
              </div>
           )}
              <button type="submit" className={styles.button1} id="submitButton">
                Submit
              </button>
          </form>
        </div>
      );
    };
 export default Registration;