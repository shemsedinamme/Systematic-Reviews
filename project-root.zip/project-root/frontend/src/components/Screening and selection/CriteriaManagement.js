// CriteriaManagement.js
import React, { useState, useEffect } from 'react';
import styles from './CriteriaManagement.module.css';

const CriteriaManagement = ({ projectId }) => {
  const [inclusionCriteria, setInclusionCriteria] = useState([]);
  const [exclusionCriteria, setExclusionCriteria] = useState([]);
  const [newInclusion, setNewInclusion] = useState('');
  const [newExclusion, setNewExclusion] = useState('');
    const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchCriteria = async () => {
      try {
        const response = await fetch(`http://10.180.50.140:3306/screening/criteria?project_id=${projectId}`, {
           method: 'GET',
            headers: {
                'Content-Type': 'application/json',
               'Authorization': `Bearer ${token}`,
             },
        });

          if (response.ok) {
            const data = await response.json();
              setInclusionCriteria(data.inclusion_criteria);
              setExclusionCriteria(data.exclusion_criteria);
          } else {
               console.error('Failed to fetch criteria');
          }
        } catch (error) {
            console.error('Error fetching criteria:', error);
        }
    };
      if(projectId){
          fetchCriteria();
      }

  }, [projectId]);

    const handleAddInclusionCriteria = async () => {
       if (!newInclusion) return;
       try {
          const response = await fetch(`http://10.180.50.140:3306/screening/criteria`, {
              method: 'POST',
              headers: {
                   'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`,
               },
             body: JSON.stringify({ criterion: newInclusion, type: 'inclusion', project_id: projectId }),
         });
            if (response.ok) {
               const data = await response.json();
                setInclusionCriteria([...inclusionCriteria, data]);
             setNewInclusion('');
          } else {
               console.error('Failed to add inclusion criteria.');
            alert('Failed to add inclusion criteria.')
        }
      } catch (error) {
            console.error('Error adding inclusion criteria:', error);
            alert('Error adding inclusion criteria.')
       }
    };

     const handleAddExclusionCriteria = async () => {
         if (!newExclusion) return;
         try {
             const response = await fetch(`http://10.180.50.140:3306/screening/criteria`, {
                 method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                   'Authorization': `Bearer ${token}`,
                },
                 body: JSON.stringify({ criterion: newExclusion, type: 'exclusion', project_id: projectId }),
            });
             if (response.ok) {
                const data = await response.json();
                setExclusionCriteria([...exclusionCriteria, data]);
               setNewExclusion('');
             } else {
                 console.error('Failed to add exclusion criteria.');
               alert('Failed to add exclusion criteria.');
             }
          } catch (error) {
             console.error('Error adding exclusion criteria:', error);
              alert('Error adding exclusion criteria.')
       }
    };
    
    const handleDeleteCriteria = async (criteriaId, type) => {
     try {
            const response = await fetch(`http://10.180.50.140:3306/screening/criteria/${criteriaId}`, {
                 method: 'DELETE',
                   headers: {
                    'Authorization': `Bearer ${token}`,
                 },
            });
        if (response.ok) {
            if (type === 'inclusion') {
              setInclusionCriteria(inclusionCriteria.filter(criterion => criterion.criterion_id !== criteriaId))
           } else {
             setExclusionCriteria(exclusionCriteria.filter(criterion => criterion.criterion_id !== criteriaId));
            }
            alert('Criteria deleted successfully.')
        } else {
           console.error('Failed to delete criteria.');
           alert('Failed to delete criteria.');
      }
    } catch (error) {
     console.error('Error deleting criteria:', error);
      alert('Error deleting criteria.');
     }
   };

  return (
    <div className={styles.criteriaContainer}>
      <h1>Inclusion/Exclusion Criteria</h1>
        {projectId ? (
        <>
      <div className={styles.criteriaSection}>
        <h2>Inclusion Criteria</h2>
        <div className={styles.addCriteria}>
          <input
            type="text"
             placeholder="Add inclusion criteria"
            value={newInclusion}
              onChange={(e) => setNewInclusion(e.target.value)}
              className={styles.criteriaInput}
          />
          <button onClick={handleAddInclusionCriteria} className={styles.addButton}>Add</button>
        </div>
        <ul className={styles.criteriaList}>
          {inclusionCriteria.map((criteria) => (
            <li key={criteria.criterion_id} className={styles.criteriaItem}>
              {criteria.criterion}
                 <button onClick={()=>handleDeleteCriteria(criteria.criterion_id, 'inclusion')} className={styles.deleteButton}>Delete</button>
            </li>
          ))}
        </ul>
      </div>
      <div className={styles.criteriaSection}>
        <h2>Exclusion Criteria</h2>
        <div className={styles.addCriteria}>
           <input
               type="text"
              placeholder="Add exclusion criteria"
               value={newExclusion}
              onChange={(e) => setNewExclusion(e.target.value)}
                className={styles.criteriaInput}
           />
          <button onClick={handleAddExclusionCriteria} className={styles.addButton}>Add</button>
        </div>
          <ul className={styles.criteriaList}>
            {exclusionCriteria.map((criteria) => (
                <li key={criteria.criterion_id} className={styles.criteriaItem}>
                 {criteria.criterion}
                 <button onClick={()=>handleDeleteCriteria(criteria.criterion_id, 'exclusion')} className={styles.deleteButton}>Delete</button>
               </li>
          ))}
        </ul>
      </div>
      </>
           ) : (
             <p>Select a project to manage criteria.</p>
         )
        }
    </div>
  );
};

export default CriteriaManagement;