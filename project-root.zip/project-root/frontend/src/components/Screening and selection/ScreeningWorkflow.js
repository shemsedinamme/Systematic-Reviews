// ScreeningWorkflow.js
import React, { useState, useEffect } from 'react';
import styles from './ScreeningWorkflow.module.css';
import { v4 as uuidv4 } from 'uuid';

const ScreeningWorkflow = ({ projectId }) => {
  const [workflow, setWorkflow] = useState([]);
  const [assignedTasks, setAssignedTasks] = useState([]);
  const [selectedReviewer, setSelectedReviewer] = useState('');
  const [availableUsers, setAvailableUsers] = useState([]);
  const token = localStorage.getItem('token');
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await fetch('http://10.180.50.140:3306/admin/users', {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
          },
        });
        if (response.ok) {
          const data = await response.json();
          setAvailableUsers(data);
        } else {
          console.error('Failed to fetch users');
        }
      } catch (error) {
        console.error('Error fetching users:', error);
      }
    };
    const fetchWorkflow = async () => {
      try {
        const response = await fetch(
          `http://10.180.50.140:3306/screening/workflow?project_id=${projectId}`,
          {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`,
            },
          }
        );
        if (response.ok) {
          const data = await response.json();
          setWorkflow(data);
        } else {
          console.error('Failed to fetch workflow');
        }
      } catch (error) {
        console.error('Error fetching workflow:', error);
      }
    };

    const fetchAssignments = async () => {
      try {
        const response = await fetch(
          `http://10.180.50.140:3306/screening/workflow?project_id=${projectId}`,
          {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`,
            },
          }
        );
        if (response.ok) {
          const data = await response.json();
          setAssignedTasks(data.assignments);
        } else {
          console.error('Failed to fetch screening assignments.');
        }
      } catch (error) {
        console.error('Error fetching screening assignments:', error);
      }
    };
    if (projectId) {
      fetchUsers();
      fetchWorkflow();
      fetchAssignments();
    }
  }, [projectId]);

  const handleAssignReviewer = async (stage) => {
    try {
      const response = await fetch(
        `http://10.180.50.140:3306/screening/workflow/assign`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
          },
          body: JSON.stringify({
            stage_name: stage,
            user_id: selectedReviewer,
            project_id: projectId,
          }),
        }
      );
      if (response.ok) {
        const updatedData = await response.json();
        setAssignedTasks([...assignedTasks, updatedData]);
        setSelectedReviewer('');
      } else {
        console.error('Failed to assign reviewer to a task');
        alert('Failed to assign reviewer to a task');
      }
    } catch (error) {
      console.error('Error assigning reviewer to a task:', error);
      alert('Error assigning reviewer to a task');
    }
  };

  if (!projectId) {
    return <p>Select a project to manage screening workflow.</p>;
  }

  return (
    <div className={styles.workflowContainer}>
      <h1>Screening Workflow</h1>
      {workflow &&
        workflow.map((stage) => (
          <div key={uuidv4()} className={styles.workflowStage}>
            <h2>{stage.stage_name}</h2>
            <div className={styles.assignReviewer}>
                <select
                    value={selectedReviewer}
                    onChange={(e) => setSelectedReviewer(e.target.value)}
                  className={styles.selectInput}
               >
                 <option value="" disabled selected>Select a Reviewer</option>
                 {availableUsers.map((user) => (
                        <option key={user.user_id} value={user.user_id}>
                           {user.username}
                         </option>
                   ))}
                </select>
                <button onClick={() => handleAssignReviewer(stage.stage_name)} className={styles.assignButton}>
                Assign Reviewer
                </button>
              </div>
            {assignedTasks &&
              assignedTasks
              .filter(task => task.stage_name === stage.stage_name)
                .map((task) => (
                  <div key={task.task_id} className={styles.taskItem}>
                    Reviewer: {availableUsers.find(user=> user.user_id === task.reviewer_id)?.username}
                  </div>
                ))}
          </div>
        ))}
    </div>
  );
};

export default ScreeningWorkflow;