// InterRaterReliability.js
import React, { useState, useEffect } from 'react';
import styles from './InterRaterReliability.module.css';

const InterRaterReliability = ({ projectId }) => {
  const [reliability, setReliability] = useState(null);
    const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchReliability = async () => {
       try {
          const response = await fetch(`http://10.180.50.140:3306/screening/inter-rater-reliability?project_id=${projectId}`, {
             method: 'GET',
                headers: {
                   'Content-Type': 'application/json',
                     'Authorization': `Bearer ${token}`,
                },
          });
           if (response.ok) {
              const data = await response.json();
            setReliability(data);
          } else {
                console.error('Failed to fetch inter-rater reliability');
          }
       } catch (error) {
         console.error('Error fetching inter-rater reliability:', error);
       }
    };
      if(projectId){
        fetchReliability();
      }

  }, [projectId]);

  if (!projectId) {
        return <p>Select a project to view the inter-rater reliability.</p>;
  }

  return (
    <div className={styles.reliabilityContainer}>
      <h1>Inter-Rater Reliability Assessment</h1>
      {reliability ? (
        <div className={styles.reliabilityData}>
          <p>
            <strong>Cohen's Kappa:</strong> {reliability.cohens_kappa}
          </p>
           <p>
              <strong>Fleiss' Kappa:</strong> {reliability.fleiss_kappa}
            </p>
        </div>
      ) : (
          <p>Inter-rater reliability data is not available.</p>
      )}
    </div>
  );
};

export default InterRaterReliability;