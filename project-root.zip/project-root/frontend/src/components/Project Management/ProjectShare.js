// ProjectShare.js
import React, { useState, useEffect } from 'react';
import styles from './ProjectShare.module.css';

const ProjectShare = ({ projectId }) => {
  const [shareWith, setShareWith] = useState('');
  const [accessType, setAccessType] = useState('read-only');
    const [shareLink, setShareLink] = useState('');
    const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
    const token = localStorage.getItem('token');

  useEffect(() => {
      if(!projectId) return;
       const fetchShareLink = async () => {
         try {
           const response = await fetch(`http://10.180.50.140:3306/projects/${projectId}/share`, {
              method: 'GET',
                 headers: {
                 'Content-Type': 'application/json',
                   'Authorization': `Bearer ${token}`,
                },
         });
           if (response.ok) {
                const data = await response.json();
                  setShareLink(data.share_link)
            } else {
                console.error('Failed to fetch share link')
             }
         } catch (error) {
             console.error('Error fetching share link:', error);
         }
       };
        fetchShareLink();
  },[projectId]);


  const handleShareProject = async () => {
    if (!shareWith) return;
       try {
            const response = await fetch(`http://10.180.50.140:3306/projects/${projectId}/share`, {
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`,
               },
               body: JSON.stringify({share_with: shareWith, access_type: accessType}),
           });
            if (response.ok) {
                setMessage('Project shared successfully!');
                 setShareWith('');
                 setAccessType('read-only');
           } else {
               const errorData = await response.json()
               console.error('Failed to share project: ', errorData);
                 setMessage('Failed to share project');
          }
        } catch (error) {
           console.error('Error sharing project:', error);
            setMessage('An error occurred during share')
        }

  };
 const handleGenerateShareLink = async () => {
    if (!password) {
        setMessage('Please provide a password for the share link.');
        return;
    }
     try {
            const response = await fetch(`http://10.180.50.140:3306/projects/${projectId}/share`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                     'Authorization': `Bearer ${token}`,
               },
                body: JSON.stringify({ share_link: true,  password: password  }),
           });

            if (response.ok) {
                const data = await response.json()
                 setShareLink(data.share_link)
                 setMessage('Share link generated successfully!');
                setPassword('');
             } else {
                const errorData = await response.json();
                 console.error('Failed to generate share link:', errorData);
                 setMessage('Failed to generate share link.');
             }

      } catch (error) {
          console.error('Error generating share link:', error);
            setMessage('An error occurred generating share link.')
      }
    };

  return (
    <div className={styles.shareContainer}>
      <h1>Project Sharing</h1>
       {projectId ? (
           <>
         <div className={styles.shareForm}>
              <input
                 type="text"
                 placeholder="Share with user (email or username)"
                 value={shareWith}
                 onChange={(e) => setShareWith(e.target.value)}
                    className={styles.shareInput}
               />
             <select
                 value={accessType}
                 onChange={(e) => setAccessType(e.target.value)}
                 className={styles.accessSelect}
                 >
              <option value="read-only">Read Only</option>
               <option value="read-write">Read Write</option>
              </select>
               <button onClick={handleShareProject} className={styles.shareButton}>Share Project</button>
         </div>
               <div className={styles.shareLink}>
                <input
                     type="password"
                     placeholder="Enter password for share link"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                     className={styles.shareInput}
                 />
                   <button onClick={handleGenerateShareLink} className={styles.shareButton}>Generate Share Link</button>
                {shareLink && <p>Share Link: <a href={shareLink} target="_blank" rel="noopener noreferrer">{shareLink}</a></p>}
                </div>
            {message && <p className={styles.message}>{message}</p>}
           </>
          ): (
             <p>Select a project to manage project sharing.</p>
         )}
    </div>
  );
};

export default ProjectShare;