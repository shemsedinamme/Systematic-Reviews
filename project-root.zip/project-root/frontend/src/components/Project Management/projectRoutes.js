// projectRoutes.js
const express = require('express');
const { v4: uuidv4 } = require('uuid');
const pool = require('./database');
const {authenticateToken} = require('./authMiddleware');
const router = express.Router();


router.post('/projects', authenticateToken, async (req, res) => {
  const { title, description, start_date, end_date } = req.body;
    if(!title || !description || !start_date || !end_date){
        return res.status(400).json({message: 'Title, description, start and end dates are required.'})
    }
    try {
    const newProject = await pool.query(
      'INSERT INTO projects (project_id, title, description, start_date, end_date, creation_date) VALUES ($1, $2, $3, $4, $5, NOW()) RETURNING *',
        [uuidv4(), title, description, start_date, end_date]
    );
        const project = newProject.rows[0];
        await pool.query(
             'INSERT INTO user_project_relations (user_id, project_id, role) VALUES ($1, $2, $3)',
            [req.user.user_id, project.project_id, 'project_owner']
         );
    res.status(201).json(project);
  } catch (error) {
    console.error('Error creating project:', error);
      res.status(500).json({ message: 'Failed to create project.' });
    }
});

router.get('/projects/:project_id/metadata', authenticateToken, async (req, res) => {
    const {project_id} = req.params;
   try {
        const projectMetadata = await pool.query(
            `SELECT pm.meta_id, mf.field_name, pm.value
                FROM project_metadata pm
                JOIN metadata_fields mf ON pm.field_id = mf.field_id
                 WHERE pm.project_id = $1`,
            [project_id]
        );
     res.status(200).json(projectMetadata.rows);
    } catch (error) {
     console.error('Error fetching project metadata:', error);
      res.status(500).json({ message: 'Failed to fetch project metadata.' });
  }
});

router.post('/projects/:project_id/metadata', authenticateToken, async (req, res) => {
    const {project_id} = req.params;
    const {field_name, value} = req.body
    if(!field_name) return res.status(400).json({message: 'Metadata field name is required'})
   try {
       //check if metadata field exists
       let metaField = await pool.query('SELECT * from metadata_fields WHERE field_name = $1', [field_name]);
       if(metaField.rows.length === 0){
          metaField = await pool.query( 'INSERT INTO metadata_fields (field_name) VALUES ($1) RETURNING field_id, field_name', [field_name])
       }

        const newProjectMetadata = await pool.query(
            'INSERT INTO project_metadata (meta_id, project_id, field_id, value) VALUES ($1, $2, $3, $4) RETURNING meta_id, field_id, value',
           [uuidv4(), project_id, metaField.rows[0].field_id, value || null]
        );
     res.status(201).json({...newProjectMetadata.rows[0], field_name: metaField.rows[0].field_name});
    } catch (error) {
         console.error('Error adding project metadata:', error);
        res.status(500).json({ message: 'Failed to add project metadata.' });
    }
});


router.put('/projects/:project_id/metadata', authenticateToken, async (req, res) => {
    const { meta_id, value } = req.body;
    if(!meta_id || !value) return res.status(400).json({message: 'Metadata Id and Value required for update.'});
     try {
        const updatedProjectMetadata = await pool.query(
            'UPDATE project_metadata SET value = $1 WHERE meta_id = $2 RETURNING *',
             [value, meta_id]
        );
        if(updatedProjectMetadata.rows.length === 0) return res.status(404).json({message: 'Metadata not found.'})
           const metaField = await pool.query(
                'SELECT field_name from metadata_fields WHERE field_id = $1',
               [updatedProjectMetadata.rows[0].field_id]
           );

        res.status(200).json({...updatedProjectMetadata.rows[0], field_name: metaField.rows[0].field_name});
     } catch (error) {
         console.error('Error updating project metadata:', error);
        res.status(500).json({ message: 'Failed to update project metadata.' });
    }
});

router.get('/projects/search', authenticateToken, async (req, res) => {
    const {query} = req.query;
  if(!query) return res.status(400).json({message: 'Search query parameter is required.'})
   try {
    const searchResults = await pool.query(
           `SELECT p.project_id, p.title
                FROM projects p
                 WHERE p.title ILIKE $1 OR
                       p.description ILIKE $1 OR
                        EXISTS (SELECT 1 from project_metadata pm JOIN metadata_fields mf on pm.field_id = mf.field_id WHERE pm.project_id = p.project_id AND (pm.value ILIKE $1 OR mf.field_name ILIKE $1))`,
           [`%${query}%`]
    );
    res.status(200).json(searchResults.rows);
  } catch (error) {
    console.error('Error searching projects by metadata:', error);
    res.status(500).json({ message: 'Failed to search projects by metadata.' });
 }
});

router.get('/projects/:project_id/workflows', authenticateToken, async (req, res) => {
    const { project_id } = req.params;
    try {
        const workflowQuery = await pool.query(
            'SELECT workflow_id, workflow_name FROM project_workflows WHERE project_id = $1',
             [project_id]
        );
        if(workflowQuery.rows.length === 0) return res.status(404).json({message: 'No workflow found for this project.'});

        const workflowId = workflowQuery.rows[0].workflow_id;
         const stagesQuery = await pool.query(
             'SELECT stage_id, stage_name FROM workflow_stages WHERE workflow_id = $1',
              [workflowId]
         );
        const stages = stagesQuery.rows;
        const tasks = await Promise.all(stages.map(async stage => {
           const tasksQuery = await pool.query(
            'SELECT task_id, task_name, assigned_user_id, due_date FROM tasks WHERE stage_id = $1',
            [stage.stage_id]
           )

           const tasks = tasksQuery.rows;
             const dependencies = await Promise.all(tasks.map(async task =>{
                 const dependenciesQuery = await pool.query(
                    'SELECT dependency_id FROM task_dependencies WHERE task_id = $1',
                    [task.task_id]
                 )
                 return {...task, dependencies: dependenciesQuery.rows}
              }))

            return {...stage, tasks: dependencies};
        }));
        res.status(200).json({ ...workflowQuery.rows[0], stages: tasks });
   } catch (error) {
    console.error('Error fetching project workflows:', error);
       res.status(500).json({ message: 'Failed to fetch project workflows.' });
    }
});

router.post('/projects/:project_id/workflows', authenticateToken, async (req, res) => {
    const { project_id } = req.params;
    try {
        const newWorkflow = await pool.query(
           'INSERT INTO project_workflows (workflow_id, project_id) VALUES ($1, $2) RETURNING workflow_id, workflow_name',
            [uuidv4(), project_id]
        );
      res.status(201).json(newWorkflow.rows[0]);
     } catch (error) {
       console.error('Error creating a new workflow for project:', error);
      res.status(500).json({ message: 'Failed to create project workflow.' });
   }

});


router.post('/workflows/:workflow_id/stages', authenticateToken, async (req, res) => {
    const { workflow_id } = req.params;
    const { stage_name } = req.body;
  try {
        const newStage = await pool.query(
           'INSERT INTO workflow_stages (stage_id, workflow_id, stage_name) VALUES ($1, $2, $3) RETURNING stage_id, stage_name',
           [uuidv4(), workflow_id, stage_name]
        );
       res.status(201).json(newStage.rows[0]);
    } catch (error) {
         console.error('Error adding a workflow stage:', error);
       res.status(500).json({ message: 'Failed to add a new workflow stage.' });
    }
});

router.post('/stages/:stage_id/tasks', authenticateToken, async (req, res) => {
    const { stage_id } = req.params;
    const { task_name } = req.body;
  try {
        const newTask = await pool.query(
           'INSERT INTO tasks (task_id, stage_id, task_name) VALUES ($1, $2, $3) RETURNING task_id, task_name',
           [uuidv4(), stage_id, task_name]
        );
        res.status(201).json(newTask.rows[0]);
     } catch (error) {
        console.error('Error adding a task to the workflow stage:', error);
        res.status(500).json({ message: 'Failed to add a new task.' });
     }
});

router.post('/tasks/:task_id/assign', authenticateToken, async (req, res) => {
    const { task_id } = req.params;
    const { user_id, due_date } = req.body;

    try {
         const updatedTask = await pool.query(
              'UPDATE tasks SET assigned_user_id = $1, due_date = $2 WHERE task_id = $3 RETURNING *',
               [user_id, due_date, task_id]
         );
       res.status(200).json(updatedTask.rows[0]);
     } catch (error) {
         console.error('Error assigning task to user:', error);
         res.status(500).json({ message: 'Failed to assign the task.' });
    }
});

router.post('/tasks/:task_id/dependencies', authenticateToken, async (req, res) => {
    const { task_id } = req.params;
    const { dependency_id } = req.body;
    try {
           const dependency = await pool.query(
                'INSERT INTO task_dependencies (dependency_id, task_id) VALUES ($1, $2) RETURNING dependency_id',
                [dependency_id, task_id]
          );
            const updatedTask = await pool.query(
                'SELECT * FROM tasks WHERE task_id = $1',
                [task_id]
           );
       res.status(200).json({...updatedTask.rows[0], dependencies: [dependency.rows[0]]});
     } catch (error) {
         console.error('Error adding task dependency:', error);
       res.status(500).json({ message: 'Failed to add task dependency.' });
     }
});

router.post('/projects/:project_id/share', authenticateToken, async (req, res) => {
  const { project_id } = req.params;
  const { share_with, access_type, password, share_link } = req.body;
    try {
        if(share_link){
            const shareableLink = uuidv4();
             //TODO: password protect the share link using a temporary table and password encryption
            res.status(200).json({share_link: `http://localhost:3000/projects/shared/${shareableLink}` });
             return;
        }
      const user = await pool.query('SELECT user_id FROM users WHERE email = $1 OR username = $1', [share_with]);
      if(user.rows.length === 0) return res.status(404).json({message:'User does not exist'});
        await pool.query(
          'INSERT INTO project_access (project_id, user_id, access_type) VALUES ($1, $2, $3)',
          [project_id, user.rows[0].user_id, access_type || 'read-only']
      );
      res.status(200).json({ message: 'Project shared successfully.' });
    } catch (error) {
         console.error('Error sharing project:', error);
      res.status(500).json({ message: 'Failed to share project.' });
   }
});
router.get('/projects/:project_id/share', authenticateToken, async (req, res) => {
    const {project_id} = req.params;
      try {
        //TODO: generate a shareable link for project with access permissions
         res.status(200).json({share_link: `http://localhost:3000/projects/shared/${uuidv4()}`})
      } catch (error) {
          console.error('Error generating project link:', error);
        res.status(500).json({ message: 'Failed to generate project link' });
      }
});

router.get('/projects/:project_id/lifecycle', authenticateToken, async (req, res) => {
    const { project_id } = req.params;
  try {
    const project = await pool.query('SELECT status FROM projects WHERE project_id = $1', [project_id]);
      if(project.rows.length === 0) return res.status(404).json({message:'Project does not exist'});
         res.status(200).json({state: project.rows[0].status});
     } catch (error) {
          console.error('Error fetching project lifecycle state:', error);
          res.status(500).json({ message: 'Failed to fetch project lifecycle state' });
     }
});

router.post('/projects/:project_id/:action', authenticateToken, async (req, res) => {
  const { project_id, action } = req.params;
    try {
      const validActions = ['initiation', 'planning', 'execution', 'monitoring', 'closure'];
      if (!validActions.includes(action)) {
           return res.status(400).json({ message: 'Invalid action' });
       }
        const updatedProject = await pool.query('UPDATE projects SET status = $1 WHERE project_id = $2 RETURNING status', [action, project_id]);
        if (updatedProject.rows.length === 0) return res.status(404).json({message: 'Project not found'})
     res.status(200).json({state: updatedProject.rows[0].status});
    } catch (error) {
         console.error('Error transitioning project lifecycle:', error);
       res.status(500).json({ message: 'Failed to transition project lifecycle.' });
     }
});
module.exports = router;