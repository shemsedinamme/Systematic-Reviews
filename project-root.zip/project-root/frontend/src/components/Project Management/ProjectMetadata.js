// ProjectMetadata.js
import React, { useState, useEffect } from 'react';
import styles from './ProjectMetadata.module.css';

const ProjectMetadata = ({ projectId }) => {
  const [metadata, setMetadata] = useState([]);
  const [newMetadataField, setNewMetadataField] = useState('');
    const token = localStorage.getItem('token');
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState([]);


  useEffect(() => {
    const fetchMetadata = async () => {
        if (!projectId) return;
      try {
        const response = await fetch(`http://10.180.50.140:3306/projects/${projectId}/metadata`, {
          method: 'GET',
             headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`,
           },
        });
          if (response.ok) {
                const data = await response.json();
                 setMetadata(data);
          } else {
           console.error('Failed to fetch metadata');
          }
      } catch (error) {
        console.error('Error fetching metadata:', error);
      }
    };
    fetchMetadata();
  }, [projectId]);


  const handleAddMetadata = async () => {
      if (!newMetadataField) return;
      try {
           const response = await fetch(`http://10.180.50.140:3306/projects/${projectId}/metadata`, {
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json',
                   'Authorization': `Bearer ${token}`,
               },
                body: JSON.stringify({field_name: newMetadataField}),
            });
            if (response.ok) {
                 const data = await response.json();
                setMetadata([...metadata, data]);
               setNewMetadataField('');
             } else {
                const errorData = await response.json();
              console.error('Failed to add metadata: ', errorData);
                alert('Failed to add metadata')
              }

      } catch (error) {
            console.error('Error adding metadata:', error);
            alert('Error adding metadata')
        }
  };

    const handleUpdateMetadata = async (meta_id, value) => {
         try {
           const response = await fetch(`http://10.180.50.140:3306/projects/${projectId}/metadata`, {
               method: 'PUT',
               headers: {
                   'Content-Type': 'application/json',
                   'Authorization': `Bearer ${token}`,
               },
                body: JSON.stringify({meta_id:meta_id, value: value}),
            });

            if (response.ok) {
                 const updatedData = await response.json();
                 setMetadata(metadata.map(meta=> meta.meta_id === updatedData.meta_id? updatedData : meta));
              } else {
                  console.error('Failed to update metadata');
                    alert('Failed to update metadata')
              }
         } catch (error) {
             console.error('Error updating metadata:', error);
              alert('Error updating metadata')
        }
    };

    const handleSearch = async () => {
    if (!searchQuery) return;
       try {
         const response = await fetch(`http://10.180.50.140:3306/projects/search?query=${searchQuery}`, {
             method: 'GET',
           headers: {
              'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
         });

            if (response.ok) {
                  const data = await response.json();
                   setSearchResults(data);
            } else {
                console.error('Search failed:', response);
                setSearchResults([]);
                alert('Search failed, try another search query')
           }
    } catch (error) {
      console.error('Error searching:', error);
       setSearchResults([]);
         alert('Error while searching')
     }
    };

  return (
    <div className={styles.metadataContainer}>
      <h1>Project Metadata</h1>
       {projectId ? (
           <>
            <div className={styles.metadataSearch}>
            <input
                type="text"
              placeholder="Search project based on metadata"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
                className={styles.metadataSearchInput}
            />
            <button onClick={handleSearch} className={styles.searchButton}>Search</button>
                </div>
           {searchResults.length > 0 ?(
               <div className={styles.searchResults}>
                   <h2>Search Results:</h2>
                   <ul>
                       {searchResults.map(result=>
                           <li key={result.project_id}>
                                 {result.title}
                           </li>
                       )}
                   </ul>
               </div>
           ):
           (
            <div className={styles.metadataList}>
                {metadata.map((item) => (
                <div key={item.meta_id} className={styles.metadataItem}>
                    <label>{item.field_name}: </label>
                    <input
                            type="text"
                            value={item.value}
                            onChange={(e) => handleUpdateMetadata(item.meta_id, e.target.value)}
                            className={styles.metadataInput}
                    />
                  </div>
                ))}
              <div className={styles.addMetadata}>
              <input
                  type="text"
                  placeholder="Add new metadata"
                  value={newMetadataField}
                  onChange={(e) => setNewMetadataField(e.target.value)}
                  className={styles.metadataInput}
                />
                <button onClick={handleAddMetadata} className={styles.addButton}>
                  Add
                </button>
              </div>
            </div>

           )
        }
           </>
           ):(
             <p>Select a project to view or add metadata.</p>
            )
        }
    </div>
  );
};

export default ProjectMetadata;