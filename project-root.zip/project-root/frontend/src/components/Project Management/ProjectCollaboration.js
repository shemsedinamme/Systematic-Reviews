// ProjectCollaboration.js
import React, { useState, useEffect, useRef } from 'react';
import styles from './ProjectCollaboration.module.css';

const ProjectCollaboration = ({ projectId }) => {
  const [documentContent, setDocumentContent] = useState('');
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [files, setFiles] = useState([]);
  const [newFile, setNewFile] = useState(null);
  const [versionHistory, setVersionHistory] = useState([]);
  const token = localStorage.getItem('token');
  const editorRef = useRef(null);

  useEffect(() => {
    const fetchDocument = async () => {
      try {
        const response = await fetch(`http://10.180.50.140:3306/projects/${projectId}/documents/1`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
          },
        });

        if (response.ok) {
          const data = await response.json();
          setDocumentContent(data.content);
        } else {
          console.error('Failed to fetch document');
        }
      } catch (error) {
        console.error('Error fetching document:', error);
      }
    };

    const fetchComments = async () => {
      try {
        const response = await fetch(`http://10.180.50.140:3306/projects/${projectId}/comments`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
          },
        });
        if (response.ok) {
          const data = await response.json();
          setComments(data);
        } else {
          console.error('Failed to fetch comments');
        }
      } catch (error) {
        console.error('Error fetching comments:', error);
      }
    };

    const fetchFiles = async () => {
      try {
        const response = await fetch(`http://10.180.50.140:3306/projects/${projectId}/files`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
          },
        });
        if (response.ok) {
          const data = await response.json();
          setFiles(data);
        } else {
          console.error('Failed to fetch files');
        }
      } catch (error) {
        console.error('Error fetching files:', error);
      }
    };

    const fetchVersionHistory = async () => {
      try {
        const response = await fetch(
          `http://10.180.50.140:3306/projects/${projectId}/documents/1/version`,
          {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`,
            },
          }
        );
        if (response.ok) {
          const data = await response.json();
          setVersionHistory(data);
        } else {
          console.error('Failed to fetch version history');
        }
      } catch (error) {
        console.error('Error fetching version history:', error);
      }
    };
    if (projectId) {
      fetchDocument();
      fetchComments();
      fetchFiles();
      fetchVersionHistory();
    }

    // Set up websocket connection, use the same socket connection as other modules for collaboration
    //TODO - set up websocket for real time collaboration
  }, [projectId]);

  const handleContentChange = async (e) => {
    setDocumentContent(e.target.value);
    //TODO implement logic to send content change over websocket
    try {
      const response = await fetch(
        `http://10.180.50.140:3306/projects/${projectId}/documents/1`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
          },
          body: JSON.stringify({ content: e.target.value }),
        }
      );
      if (response.ok) {
        console.log('Document content saved');
      } else {
        console.error('Failed to save document content');
      }
    } catch (error) {
      console.error('Error saving document content:', error);
    }
  };

  const handleAddComment = async () => {
    if (!newComment) return;

    try {
      const response = await fetch(`http://10.180.50.140:3306/projects/${projectId}/comments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ text: newComment }),
      });
      if (response.ok) {
        const data = await response.json();
        setComments([...comments, data]);
        setNewComment('');
      } else {
        console.error('Failed to add comment');
        alert('Failed to add comment');
      }
    } catch (error) {
      console.error('Error adding comment:', error);
      alert('Error adding comment');
    }
  };

  const handleFileUpload = async () => {
    if (!newFile) return;
    const formData = new FormData();
    formData.append('file', newFile);

    try {
      const response = await fetch(`http://10.180.50.140:3306/projects/${projectId}/files`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });
      if (response.ok) {
        const data = await response.json();
        setFiles([...files, data]);
        setNewFile(null);
        alert('File uploaded successfully')
      } else {
        console.error('File upload failed');
          alert('File upload failed')
      }
    } catch (error) {
      console.error('Error uploading file:', error);
       alert('Error uploading file')
    }
  };

   const handleRevertVersion = async (versionId) => {
      try {
        const response = await fetch(`http://10.180.50.140:3306/documents/1/versions/${versionId}/revert`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
         });
        if (response.ok) {
             const data = await response.json();
          setDocumentContent(data.content);
            alert('Document version reverted to ' + versionId);
          } else {
            console.error('Failed to revert to a version.');
             alert('Failed to revert to a version.')
         }
     } catch (error) {
        console.error('Error reverting to version', error);
         alert('Error reverting to version')
     }
    };


  if (!projectId) {
    return <p>Select a project to collaborate.</p>;
  }

  return (
    <div className={styles.collaborationContainer}>
      <h1>Project Collaboration</h1>
      <div className={styles.documentEditor}>
        <textarea
          ref={editorRef}
          value={documentContent}
          onChange={handleContentChange}
          placeholder="Type document content here..."
          className={styles.documentTextArea}
        />
      </div>
      <div className={styles.commentsSection}>
        <h2>Comments</h2>
        <div className={styles.commentsList}>
          {comments.map((comment) => (
            <div key={comment.comment_id} className={styles.comment}>
              <p>{comment.text}</p>
            </div>
          ))}
        </div>
        <div className={styles.addComment}>
          <input
            type="text"
            placeholder="Add a comment"
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
               className={styles.commentInput}
          />
          <button onClick={handleAddComment} className={styles.addButton}>
            Add Comment
          </button>
        </div>
      </div>
      <div className={styles.fileSharing}>
        <h2>File Sharing</h2>
        <div className={styles.fileUpload}>
          <input type="file" onChange={(e) => setNewFile(e.target.files[0])} className={styles.fileInput}/>
          <button onClick={handleFileUpload}  className={styles.uploadButton}>Upload File</button>
        </div>
        <ul className={styles.fileList}>
          {files.map((file) => (
            <li key={file.file_id}>
              <a href={file.file_path} target="_blank" rel="noopener noreferrer">
                {file.file_name}
              </a>
            </li>
          ))}
        </ul>
      </div>
        <div className={styles.versionHistory}>
            <h2>Version History</h2>
            <ul>
                {versionHistory.map(version => (
                   <li key={version.version_id}>
                        <button onClick={() => handleRevertVersion(version.version_id)}>
                            Version: {version.version_id} - Date: {new Date(version.version_date).toLocaleString()}
                        </button>
                   </li>
                ))}
            </ul>
        </div>
    </div>
  );
};

export default ProjectCollaboration;