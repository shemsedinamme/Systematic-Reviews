// ProjectCreate.js
import React, { useState } from 'react';
import styles from './ProjectCreate.module.css';

const ProjectCreate = () => {
  const [projectData, setProjectData] = useState({
    title: '',
    description: '',
    start_date: '',
    end_date: '',
  });
  const [message, setMessage] = useState('');
  const token = localStorage.getItem('token');

  const handleInputChange = (e) => {
    setProjectData({
      ...projectData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate start and end dates
    if (new Date(projectData.start_date) >= new Date(projectData.end_date)) {
      setMessage('Start date must be before the end date.');
      return;
    }

    try {
      const response = await fetch('http://10.180.50.140:3306/projects', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(projectData),
      });

      if (response.ok) {
        const data = await response.json();
          setMessage(`Project "${data.title}" created successfully!`);
          setProjectData({
              title: '',
              description: '',
              start_date: '',
              end_date: '',
          });
      } else {
         const errorData = await response.json();
          setMessage(`Failed to create project: ${errorData.message}`);
      }
    } catch (error) {
       console.error('Error creating project:', error);
        setMessage('An error occurred while creating the project.');
    }
  };

  return (
    <div className={styles.projectCreateContainer}>
      <h1>Create New Project</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="title"
          placeholder="Project Title"
          value={projectData.title}
          onChange={handleInputChange}
          required
          className={styles.projectInput}
        />
        <textarea
          name="description"
          placeholder="Project Description"
          value={projectData.description}
          onChange={handleInputChange}
          required
            className={styles.projectInput}
        />
        <input
          type="date"
          name="start_date"
          placeholder="Start Date"
          value={projectData.start_date}
          onChange={handleInputChange}
          required
            className={styles.projectInput}
        />
        <input
          type="date"
          name="end_date"
          placeholder="End Date"
          value={projectData.end_date}
          onChange={handleInputChange}
          required
            className={styles.projectInput}
        />
          <button type="submit" className={styles.createButton}>
          Create Project
        </button>
      </form>
        {message && <p className={styles.message}>{message}</p>}
    </div>
  );
};

export default ProjectCreate;