// ProjectLifecycle.js
import React, { useState, useEffect } from 'react';
import styles from './ProjectLifecycle.module.css';

const ProjectLifecycle = ({ projectId }) => {
  const [lifecycleState, setLifecycleState] = useState('');
  const [message, setMessage] = useState('');
    const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchLifecycleState = async () => {
       if(!projectId) return;
      try {
        const response = await fetch(`http://10.180.50.140:3306/projects/${projectId}/lifecycle`,{
           method: 'GET',
            headers: {
                 'Authorization': `Bearer ${token}`,
             },
        });
          if (response.ok) {
              const data = await response.json();
              setLifecycleState(data.state);
            } else {
              console.error('Failed to fetch project lifecycle state');
           }
       } catch (error) {
           console.error('Error fetching lifecycle state:', error);
       }
    };
      fetchLifecycleState();
  }, [projectId]);

  const handleLifecycleTransition = async (action) => {
    try {
         const response = await fetch(`http://10.180.50.140:3306/projects/${projectId}/${action}`, {
             method: 'POST',
               headers: {
                    'Content-Type': 'application/json',
                     'Authorization': `Bearer ${token}`,
                 },
         });
            if (response.ok) {
                const data = await response.json();
                 setLifecycleState(data.state)
                setMessage(`Project transitioned to: ${data.state}`);

            } else {
                 const errorData = await response.json()
                 console.error('Failed to transition project lifecycle:', errorData)
                setMessage(`Failed to transition project lifecycle.`);
           }
    } catch (error) {
         console.error('Error transitioning project lifecycle:', error);
          setMessage('Error transitioning project lifecycle.');
     }
  };

  return (
    <div className={styles.lifecycleContainer}>
      <h1>Project Lifecycle Management</h1>
        {projectId ? (
        <>
      <p>Current Phase: {lifecycleState || 'Not Started'}</p>
        <div className={styles.lifecycleActions}>
          <button onClick={() => handleLifecycleTransition('initiation')} className={styles.actionButton}>
            Initiation
          </button>
          <button onClick={() => handleLifecycleTransition('planning')}  className={styles.actionButton}>
            Planning
          </button>
            <button onClick={() => handleLifecycleTransition('execution')}  className={styles.actionButton}>
             Execution
           </button>
          <button onClick={() => handleLifecycleTransition('monitoring')}  className={styles.actionButton}>
           Monitoring
          </button>
          <button onClick={() => handleLifecycleTransition('closure')}  className={styles.actionButton}>
           Closure
          </button>
        </div>
            {message && <p className={styles.message}>{message}</p>}
         </>
         ) : (
             <p>Select a project to manage lifecycle.</p>
         )
        }
    </div>
  );
};

export default ProjectLifecycle;