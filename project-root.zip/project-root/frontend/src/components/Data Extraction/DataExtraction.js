// DataExtraction.js
import React, { useState, useEffect } from 'react';
import styles from './DataExtraction.module.css';
import { CKEditor } from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

const DataExtraction = ({ projectId, taskId }) => {
    const [task, setTask] = useState(null);
    const [formData, setFormData] = useState({});
  const token = localStorage.getItem('token');
    
  useEffect(() => {
    const fetchTask = async () => {
      try {
          const response = await fetch(`http://10.180.50.140:3306/extraction-tasks/${taskId}`, {
              method: 'GET',
                headers: {
                   'Content-Type': 'application/json',
                     'Authorization': `Bearer ${token}`,
                },
            });
            if (response.ok) {
                 const data = await response.json();
              setTask(data);
            } else {
               console.error('Failed to fetch extraction task.');
            }
         } catch (error) {
             console.error('Error fetching extraction task:', error);
        }
    };
      if(taskId){
          fetchTask();
      }
   }, [taskId]);

    useEffect(() => {
        if (task && task.form && task.form.fields) {
            const initialFormData = {};
            task.form.fields.forEach(field => {
                initialFormData[field.field_id] = '';
            });
           setFormData(initialFormData);
        }
    }, [task])

    const handleDataChange = (fieldId, value) => {
       setFormData(prevFormData => ({
            ...prevFormData,
            [fieldId]: value,
        }));
    };
    const handleEditorChange = ( event, editor, fieldId ) => {
        const data = editor.getData();
      setFormData(prevFormData => ({
         ...prevFormData,
          [fieldId]: data,
      }))
    }

  const handleSubmitData = async () => {
      try {
         const response = await fetch(`http://10.180.50.140:3306/extraction-tasks/${taskId}/data`, {
              method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                     'Authorization': `Bearer ${token}`,
                 },
                 body: JSON.stringify(formData),
            });

            if (response.ok) {
                 alert('Data submitted successfully')
             } else {
              console.error('Failed to submit data extraction task');
                 alert('Failed to submit data extraction task')
            }
        } catch (error) {
            console.error('Error submitting data extraction task:', error);
            alert('Error submitting data extraction task')
      }
  };

  if (!taskId) {
        return <p>Select a task to perform data extraction.</p>
    }

 if (!task) {
        return <p>Loading task details...</p>
  }

  return (
    <div className={styles.extractionContainer}>
      <h1>Data Extraction for Article: {task.article_id}</h1>
        {task.form && task.form.fields && (
            <div className={styles.extractionForm}>
              {task.form.fields.map((field) => (
                  <div key={field.field_id} className={styles.formItem}>
                    <label>{field.field_label}</label>
                      {field.field_type === 'text' && (
                         <input
                             type="text"
                             value={formData[field.field_id]}
                            onChange={(e) => handleDataChange(field.field_id, e.target.value)}
                            className={styles.dataInput}
                          />
                      )}
                      {field.field_type === 'numeric' && (
                          <input
                              type="number"
                              value={formData[field.field_id]}
                            onChange={(e) => handleDataChange(field.field_id, e.target.value)}
                            className={styles.dataInput}
                            />
                      )}
                    {field.field_type === 'date' && (
                        <input
                          type="date"
                           value={formData[field.field_id]}
                          onChange={(e) => handleDataChange(field.field_id, e.target.value)}
                           className={styles.dataInput}
                         />
                     )}
                        {field.field_type === 'dropdown' && (
                          <select
                            value={formData[field.field_id] || ''}
                             onChange={(e) => handleDataChange(field.field_id, e.target.value)}
                             className={styles.dataInput}
                            >
                                <option value="" disabled>Select an option</option>
                                {field.field_options && field.field_options.split(',').map((option, index)=>(
                                   <option key={index} value={option}>{option}</option>
                                ))}
                            </select>
                        )}
                         {field.field_type === 'checkbox' && (
                              <input
                                  type="checkbox"
                                  checked={formData[field.field_id] === true}
                                   onChange={(e) => handleDataChange(field.field_id, e.target.checked)}
                                  className={styles.dataInput}
                                />

                        )}
                        {(field.field_type === 'text' && field.conditional_logic ) && (
                              <CKEditor
                                editor={ClassicEditor}
                                data={formData[field.field_id] || ''}
                                onChange={(event, editor) => handleEditorChange(event, editor, field.field_id)}
                             />
                         )}
                  </div>
              ))}
             <button onClick={handleSubmitData} className={styles.submitButton}>
                 Submit Data
            </button>
          </div>
         )}

    </div>
  );
};

export default DataExtraction;