const mysql = require('mysql2/promise');
require('dotenv').config();

const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT,
    //ssl: { //if you are using SSL connection you will have to uncomment this section and provide the appropriate certificates.
        //rejectUnauthorized: true,
    //}
});

const createUserTable = async () => {
    try {
        const connection = await pool.getConnection();
        await connection.query(`
            CREATE TABLE IF NOT EXISTS users (
                user_id VARCHAR(36) PRIMARY KEY,
                username VARCHAR(255) NOT NULL UNIQUE,
                email VARCHAR(255) NOT NULL UNIQUE,
                hashed_password VARCHAR(255) NOT NULL,
                registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                role VARCHAR(255) DEFAULT 'reviewer'
                );
        `);
        await connection.release();
        console.log('User table created or already exists.');
    } catch (error) {
        console.error('Error creating user table:', error);
    }
};
const createResetTokenTable = async () => {
    try {
        const connection = await pool.getConnection();
        await connection.query(`
            CREATE TABLE IF NOT EXISTS password_reset_tokens (
                token VARCHAR(36) PRIMARY KEY,
                user_id VARCHAR(36) NOT NULL,
                expiration_timestamp TIMESTAMP NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
                );
        `);
        await connection.release();
        console.log('password_reset_tokens table created or already exists.');
    } catch (error) {
        console.error('Error creating password_reset_tokens table:', error);
    }
};

const createProjectsTable = async () => {
    try {
        const connection = await pool.getConnection();
        await connection.query(`
            CREATE TABLE IF NOT EXISTS projects (
                project_id VARCHAR(36) PRIMARY KEY,
                title VARCHAR(255) NOT NULL,
                description TEXT,
                start_date DATE,
                end_date DATE,
                creation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                status VARCHAR(255) DEFAULT 'active'
                );
        `);
        await connection.release();
        console.log('Projects table created or already exists.');
    } catch (error) {
        console.error('Error creating projects table:', error);
    }
};
const createProjectMetadataTables = async () => {
    try {
        const connection = await pool.getConnection();
        await connection.query(`
            CREATE TABLE IF NOT EXISTS metadata_fields (
                field_id VARCHAR(36) PRIMARY KEY,
                field_name VARCHAR(255) NOT NULL UNIQUE
                );
        `);
        await connection.query(`
            CREATE TABLE IF NOT EXISTS project_metadata (
                meta_id VARCHAR(36) PRIMARY KEY,
                project_id VARCHAR(36) NOT NULL,
                field_id VARCHAR(36) NOT NULL,
                value TEXT,
                FOREIGN KEY (project_id) REFERENCES projects(project_id),
                FOREIGN KEY (field_id) REFERENCES metadata_fields(field_id)
                );
        `);
        await connection.release();
        console.log('Project metadata tables created or already exists.');
    } catch (error) {
        console.error('Error creating project metadata tables:', error);
    }
};
const createProjectWorkflowTables = async () => {
    try {
        const connection = await pool.getConnection();
        await connection.query(`
            CREATE TABLE IF NOT EXISTS project_workflows (
                workflow_id VARCHAR(36) PRIMARY KEY,
                project_id VARCHAR(36) NOT NULL,
                workflow_name VARCHAR(255) DEFAULT 'default',
                FOREIGN KEY (project_id) REFERENCES projects(project_id)
                );
        `);
        await connection.query(`
            CREATE TABLE IF NOT EXISTS workflow_stages (
                stage_id VARCHAR(36) PRIMARY KEY,
                workflow_id VARCHAR(36) NOT NULL,
                stage_name VARCHAR(255) NOT NULL,
                FOREIGN KEY (workflow_id) REFERENCES project_workflows(workflow_id)
                );
        `);
        await connection.query(`
            CREATE TABLE IF NOT EXISTS tasks (
                task_id VARCHAR(36) PRIMARY KEY,
                stage_id VARCHAR(36) NOT NULL,
                task_name VARCHAR(255) NOT NULL,
                assigned_user_id VARCHAR(36),
                due_date DATE,
                FOREIGN KEY (stage_id) REFERENCES workflow_stages(stage_id),
                FOREIGN KEY (assigned_user_id) REFERENCES users(user_id)
                );
        `);
        await connection.query(`
            CREATE TABLE IF NOT EXISTS task_dependencies(
                dependency_id VARCHAR(36) PRIMARY KEY,
                task_id VARCHAR(36) NOT NULL,
                FOREIGN KEY (task_id) REFERENCES tasks(task_id)
                );
        `);
        await connection.release();
        console.log('Project workflow tables created or already exists.');
    } catch (error) {
        console.error('Error creating project workflow tables:', error);
    }
};
const createCollaborationTables = async () => {
    try {
        const connection = await pool.getConnection();
        await connection.query(`
            CREATE TABLE IF NOT EXISTS documents (
                document_id VARCHAR(36) PRIMARY KEY,
                project_id VARCHAR(36) NOT NULL,
                content TEXT,
                FOREIGN KEY (project_id) REFERENCES projects(project_id)
                );
        `);
        await connection.query(`
             CREATE TABLE IF NOT EXISTS document_versions (
                version_id VARCHAR(36) PRIMARY KEY,
                document_id VARCHAR(36) NOT NULL,
                content TEXT,
                version_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (document_id) REFERENCES documents(document_id)
                );
        `);
        await connection.query(`
            CREATE TABLE IF NOT EXISTS comments (
                comment_id VARCHAR(36) PRIMARY KEY,
                project_id VARCHAR(36) NOT NULL,
                user_id VARCHAR(36) NOT NULL,
                text TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (project_id) REFERENCES projects(project_id),
                FOREIGN KEY (user_id) REFERENCES users(user_id)
                );
        `);
        await connection.query(`
            CREATE TABLE IF NOT EXISTS files (
                file_id VARCHAR(36) PRIMARY KEY,
                project_id VARCHAR(36) NOT NULL,
                file_path VARCHAR(255) NOT NULL,
                file_name VARCHAR(255) NOT NULL,
                uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (project_id) REFERENCES projects(project_id)
                );
        `);
        await connection.release();
        console.log('Project collaboration tables created or already exists.');
    } catch (error) {
        console.error('Error creating project collaboration tables:', error);
    }
};
const createProjectAccessTables = async () => {
    try {
        const connection = await pool.getConnection();
        await connection.query(`
            CREATE TABLE IF NOT EXISTS user_project_relations (
                user_id VARCHAR(36) NOT NULL,
                project_id VARCHAR(36) NOT NULL,
                role VARCHAR(255),
                FOREIGN KEY (user_id) REFERENCES users(user_id),
                FOREIGN KEY (project_id) REFERENCES projects(project_id),
                 PRIMARY KEY (user_id, project_id)
                );
        `);
        await connection.query(`
            CREATE TABLE IF NOT EXISTS project_access (
                 access_id VARCHAR(36) PRIMARY KEY,
                project_id VARCHAR(36) NOT NULL,
                user_id VARCHAR(36) NOT NULL,
                 access_type VARCHAR(255) DEFAULT 'read-only',
                FOREIGN KEY (project_id) REFERENCES projects(project_id),
                FOREIGN KEY (user_id) REFERENCES users(user_id)
           );
        `);
        await connection.release();
        console.log('Project access tables created or already exists.');
    } catch (error) {
        console.error('Error creating project access tables:', error);
    }
};


const createProtocolTables = async () => {
    try {
        const connection = await pool.getConnection();
        await connection.query(`
            CREATE TABLE IF NOT EXISTS templates (
                template_id VARCHAR(36) PRIMARY KEY,
                template_name VARCHAR(255) NOT NULL,
                template_description TEXT
                );
        `);
        await connection.query(`
            CREATE TABLE IF NOT EXISTS template_sections (
                section_id VARCHAR(36) PRIMARY KEY,
                template_id VARCHAR(36) NOT NULL,
                section_name VARCHAR(255) NOT NULL,
                FOREIGN KEY (template_id) REFERENCES templates(template_id)
                );
        `);
         await connection.query(`
            CREATE TABLE IF NOT EXISTS template_data_fields (
                field_id VARCHAR(36) PRIMARY KEY,
                 section_id VARCHAR(36) NOT NULL,
                field_name VARCHAR(255) NOT NULL,
                FOREIGN KEY (section_id) REFERENCES template_sections(section_id)
            );
        `);
         await connection.query(`
            CREATE TABLE IF NOT EXISTS protocols (
                 protocol_id VARCHAR(36) PRIMARY KEY,
                 template_id VARCHAR(36) NOT NULL,
                 project_id VARCHAR(36) NOT NULL,
                 title VARCHAR(255) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (template_id) REFERENCES templates(template_id),
                 FOREIGN KEY (project_id) REFERENCES projects(project_id)
            );
        `);
        await connection.query(`
            CREATE TABLE IF NOT EXISTS protocol_sections (
                section_id VARCHAR(36) PRIMARY KEY,
                 protocol_id VARCHAR(36) NOT NULL,
                 section_name VARCHAR(255) NOT NULL,
                content TEXT,
                FOREIGN KEY (protocol_id) REFERENCES protocols(protocol_id)
                );
        `);
       await connection.query(`
            CREATE TABLE IF NOT EXISTS protocol_reviews (
                 review_id VARCHAR(36) PRIMARY KEY,
                protocol_id VARCHAR(36) NOT NULL,
                section_id VARCHAR(36) NOT NULL,
                 reviewer_id VARCHAR(36) NOT NULL,
                 comment TEXT,
                FOREIGN KEY (protocol_id) REFERENCES protocols(protocol_id),
                FOREIGN KEY (section_id) REFERENCES protocol_sections(section_id),
                 FOREIGN KEY (reviewer_id) REFERENCES users(user_id)
            );
        `);
         await connection.query(`
            CREATE TABLE IF NOT EXISTS protocol_approvals (
                 approval_id VARCHAR(36) PRIMARY KEY,
                 protocol_id VARCHAR(36) NOT NULL,
                user_id VARCHAR(36) NOT NULL,
                approval_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
               FOREIGN KEY (protocol_id) REFERENCES protocols(protocol_id),
                FOREIGN KEY (user_id) REFERENCES users(user_id)
           );
        `);
        await connection.release();
        console.log('Protocol tables created or already exists.');
    } catch (error) {
        console.error('Error creating protocol tables:', error);
    }
};
const createSearchQueryTables = async () => {
    try {
        const connection = await pool.getConnection();
      await connection.query(`
        CREATE TABLE IF NOT EXISTS articles (
            article_id VARCHAR(36) PRIMARY KEY,
            database_id VARCHAR(255) NOT NULL,
            title TEXT,
            authors TEXT,
            abstract TEXT,
            publication_date DATE,
            doi VARCHAR(255),
            pmid VARCHAR(255),
            pmcid VARCHAR(255),
             additional_fields JSON
          );
      `);
        await connection.query(`
            CREATE TABLE IF NOT EXISTS search_queries (
                query_id VARCHAR(36) PRIMARY KEY,
                user_id VARCHAR(36) NOT NULL,
                 database VARCHAR(255),
                 full_query TEXT,
                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            );
        `);
        await connection.query(`
             CREATE TABLE IF NOT EXISTS data_quality_issues (
              issue_id VARCHAR(36) PRIMARY KEY,
                 article_id VARCHAR(36) NOT NULL,
                 issue_type VARCHAR(255) NOT NULL,
                issue_description TEXT,
               FOREIGN KEY (article_id) REFERENCES articles(article_id)
                );
       `);
        await connection.query(`
              CREATE TABLE IF NOT EXISTS search_term_mappings (
                mapping_id VARCHAR(36) PRIMARY KEY,
                user_term VARCHAR(255) NOT NULL,
                standard_term VARCHAR(255) NOT NULL,
                database_id VARCHAR(255)
            );
       `);
      await connection.release();
      console.log('Search query tables created or already exists.');
  } catch (error) {
    console.error('Error creating search query tables:', error);
  }
};

const setupDatabase = async () => {
    try{
        await createUserTable();
        await createResetTokenTable();
        await createProjectsTable();
        await createProjectMetadataTables();
        await createProjectWorkflowTables();
        await createCollaborationTables();
        await createProjectAccessTables()
        await createProtocolTables();
       await createSearchQueryTables()
    } catch(error){
        console.log('Error setting up database:', error);
    }
}
setupDatabase()
module.exports = pool;