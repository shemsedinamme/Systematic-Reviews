const express = require('express');
const cors = require('cors');
const {authenticateToken} = require('./authMiddleware');
const swaggerUi = require('swagger-ui-express');
const swaggerJsdoc = require('swagger-jsdoc');
const fileUpload = require('express-fileupload');
require('dotenv').config()
const app = express();
const port = 3306;
const userRoutes = require('./userRoutes');
const projectRoutes = require('./projectRoutes');
const protocolRoutes = require('./protocolRoutes');
const searchRoutes = require('./searchRoutes');
const options = {
    definition:{
        openapi: '3.0.0',
        info: {
            title: 'ARMS API',
            version: '1.0.0',
            description: 'API Documentation for ARMS application'
        }
    },
    apis: ['./userRoutes.js', './projectRoutes.js', './protocolRoutes.js', './searchRoutes.js']
}
const swaggerSpec = swaggerJsdoc(options);

app.use(cors());
app.use(express.json());
app.use(fileUpload());//allow file upload
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));
app.use(userRoutes);
app.use(projectRoutes);
app.use(protocolRoutes);
app.use(searchRoutes);


app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`);
});