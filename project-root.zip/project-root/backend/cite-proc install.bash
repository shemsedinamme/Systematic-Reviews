// unstalling citeproc-js

npm install citeproc-js