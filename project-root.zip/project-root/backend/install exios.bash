npm install axios

**// Install axios for Third Party API requests: Install axios to make HTTP requests to third party APIs.



* **Unpaywall API:** Implement a call to the Unpaywall API or a similar service to get a full-text link for a given DOI or PMID. We will use Unpaywall API for demonstration.