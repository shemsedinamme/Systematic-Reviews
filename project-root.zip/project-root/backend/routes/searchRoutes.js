    const express = require('express');
const { v4: uuidv4 } = require('uuid');
const pool = require('./database');
const {authenticateToken} = require('./authMiddleware');
const axios = require('axios');
const citeproc = require('citeproc-js');
const router = express.Router();

// PubMed API Client (NCBI E-utilities)
const pubmedApi = axios.create({
    baseURL: 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils',
});

// Helper function to fetch data from pubmed
const fetchPubMed = async (query, retmax= 20) => {
    try {
       const response = await pubmedApi.get('/esearch.fcgi', {
           params: {
            db: 'pubmed',
               term: query,
               retmax: retmax,
                retmode: 'json'
           }
        });
          if(response.data.esearchresult.count === '0') return []

        const idList = response.data.esearchresult.idlist.join(',');
       const fetchArticleDetails = await pubmedApi.get('/esummary.fcgi', {
           params: {
                db: 'pubmed',
                id: idList,
               retmode: 'json'
           }
        });
        const records =  Object.values(fetchArticleDetails.data.result).slice(1)
      const formattedData = records.map(record => ({
           article_id: uuidv4(),
           database_id: 'PubMed',
            title: record.title,
             authors: record.authors.map(author => `${author.name}`).join(', '),
            abstract: record.abstract,
           publication_date: record.pubdate,
             doi: record.doi,
            pmid: record.uid,
            additional_fields: JSON.stringify(record)
       }))
       return formattedData
    } catch (error) {
        console.error('Error fetching from PubMed:', error);
      throw new Error('Failed to fetch data from PubMed API');
    }
};
// Cache for API responses
const cache = new Map();
// Unpaywall API client
const unpaywallApi = axios.create({
    baseURL: 'https://api.unpaywall.org/v2/',
});
/**
 * @swagger
 * /articles:
 *   get:
 *     summary: Get articles based on query
 *     description: Get a list of articles based on the provided search query
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: query
 *         required: true
 *         description: search query
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Articles retrieved successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                    article_id:
 *                      type: string
 *                      description: unique id of the article
 *                    database_id:
 *                      type: string
 *                      description: database id of the article
 *                    title:
 *                      type: string
 *                      description: Title of the article
 *                    authors:
 *                        type: string
 *                        description: Authors of the article
 *                    abstract:
 *                        type: string
 *                        description: Abstract of the article
 *                    publication_date:
 *                       type: string
 *                       description: publication date of the article
 *                    doi:
 *                        type: string
 *                        description: DOI of the article
 *                    pmid:
 *                       type: string
 *                       description: pubmed id of the article
  *                   pmcid:
 *                      type: string
 *                      description: pubmed central id of the article
  *                   additional_fields:
  *                      type: string
  *                      description: additional fields of the article, stored in json
 *       400:
 *          description: Bad request, input is not valid.
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                    message:
 *                       type: string
 *                       description: The message returned by the system.
 *              example:
 *                message: 'Search query parameter is required.'
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to fetch articles'
 */
router.get('/articles', authenticateToken, async (req, res) => {
    const { query } = req.query;
      if (!query) return res.status(400).json({message: 'Search query parameter is required.'});
    try {
        const pubmedResults = await fetchPubMed(query);
        //Combine the results from different databases into one array and respond.
        const allResults = [
          ...pubmedResults,
            //...scopusResults,
           //...wosResults
          ];
        //save all the results to the database
         await Promise.all(allResults.map(async (result) => {
           await pool.query('INSERT INTO articles SET ?', result)
        }))
        res.status(200).json(allResults);
    } catch (error) {
        console.error('Error fetching articles:', error);
       res.status(500).json({message: 'Failed to fetch articles'})
    }
});

/**
 * @swagger
 * /search/query-builder:
 *   get:
 *     summary: Get saved queries for a user
 *     description: Retrieves the saved queries for a specific user
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Saved queries fetched successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   query_id:
 *                     type: string
 *                     description: unique id for search query
 *                   user_id:
 *                      type: string
 *                      description: unique id for user
 *                   database:
 *                     type: string
 *                     description: datbase used for the search
  *                   search_query:
 *                     type: string
 *                     description: The search query
 *                   created_at:
 *                     type: string
 *                     description: date and time that the search query was created.
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to fetch saved queries.'
 */
router.get('/search/query-builder', authenticateToken, async (req, res) => {
    try {
        const [queries] = await pool.query('SELECT * FROM search_queries WHERE user_id = ?', [req.user.user_id]);
        res.status(200).json(queries);
    } catch (error) {
        console.error('Error fetching saved queries:', error);
        res.status(500).json({ message: 'Failed to fetch saved queries.' });
    }
});

/**
 * @swagger
 * /search/query-builder:
 *   post:
 *     summary: Save a search query
 *     description: Save a generated search query
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               search_query:
 *                 type: string
 *                 description: The search query to save.
  *               databases:
 *                 type: array
 *                 description: array of databases used for this query
 *             example:
 *                 search_query: "(title:(covid-19) OR abstract:(covid-19)) AND (author:johnson)"
 *                 databases: ["PubMed"]
 *     responses:
 *       201:
 *         description: Saved queries saved successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                   query_id:
 *                     type: string
 *                     description: The unique id for the new search query.
 *                   search_query:
 *                      type: string
 *                      description: The search query that was saved
 *                   created_at:
 *                      type: string
 *                      description: The timestamp that it was created.
 *       400:
 *         description: Bad request, input is not valid.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                    message:
 *                       type: string
 *                       description: The message returned by the system.
 *              example:
 *                message: 'Search query is required.'
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to save search query.'
 */
router.post('/search/query-builder', authenticateToken, async (req, res) => {
    const { search_query, databases } = req.body;
     if (!search_query) {
       return res.status(400).json({ message: 'Search query is required.' });
    }
    try {
          const [newQuery] = await pool.query(
            'INSERT INTO search_queries (query_id, user_id, full_query, database) VALUES (?, ?, ?, ?) ',
           [uuidv4(), req.user.user_id, search_query, databases?.join(', ') || null ]
        );
        const searchQuery = {
           query_id: uuidv4(),
            search_query: search_query,
          created_at: new Date()
        }
         res.status(201).json(searchQuery);
    } catch (error) {
        console.error('Error saving search query:', error);
        res.status(500).json({ message: 'Failed to save search query.' });
    }
});
/**
 * @swagger
 * /search/generate-query:
 *   post:
 *     summary: Generate a search query
 *     description: Generate a search query based on the provided keywords, or PICO elements
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               keywords:
 *                 type: string
 *                 description: The comma separated list of keywords.
 *               population:
 *                  type: string
 *                  description: Population for PICO query.
 *               intervention:
 *                   type: string
 *                   description: Intervention for PICO query.
 *               comparison:
 *                  type: string
 *                  description: Comparison for PICO query.
 *               outcome:
 *                  type: string
 *                   description: Outcome for PICO query.
 *             example:
 *                  keywords: "covid-19, pandemic, vaccine"
 *                  population: "adults"
 *                  intervention: "remdesivir"
 *                  comparison: "placebo"
 *                  outcome: "mortality"
 *
 *     responses:
 *       200:
 *         description: Search query generated successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 query:
 *                   type: string
 *                   description: The generated search query.
 *             example:
 *                query: "covid-19 OR pandemic OR vaccine"
 *       400:
 *         description: Bad request, input is not valid.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                  message:
 *                    type: string
 *                    description: The message returned by the system.
 *             example:
 *                message: 'Keywords or PICO elements are required.'
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to generate query.'
 */
router.post('/search/generate-query', authenticateToken, async (req, res) => {
    const { keywords, population, intervention, comparison, outcome } = req.body;
    if (!keywords && !population && !intervention && !comparison && !outcome) {
        return res.status(400).json({ message: 'Keywords or PICO elements are required.' });
    }
    try {
           if(keywords){
              const keywordArray = keywords.split(',').map(term => term.trim()).filter(Boolean)
              const query = keywordArray.join(' OR ')
               return res.status(200).json({ query: query });
           } else {
                const query = `(${population || ''}) AND (${intervention || ''}) AND (${comparison || ''}) AND (${outcome || ''})`
              return res.status(200).json({ query: query });
           }

    } catch (error) {
        console.error('Error generating query:', error);
        res.status(500).json({ message: 'Failed to generate query.' });
    }
});

/**
 * @swagger
 * /search/translate-query:
 *   post:
 *     summary: Translate search query based on the database.
 *     description: Translates search queries for the provided databases.
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               query:
 *                 type: string
 *                 description: The search query to translate
  *               databases:
 *                 type: array
 *                 description: The databases to generate queries
 *             example:
 *                 query: "(title:covid-19 OR abstract:covid-19) AND (author:johnson)"
 *                 databases: ["PubMed", "Scopus"]
 *     responses:
 *       200:
 *         description: Query translated successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               additionalProperties:
 *                  type: string
 *                  description: The databases as keys with values as translated queries.
 *             example:
 *               PubMed: "(title:(covid-19) OR abstract:(covid-19)) AND (author:johnson)"
 *               Scopus: "TITLE(covid-19) OR ABS(covid-19) AND AUTH(johnson)"
 *       400:
 *          description: Bad request, input is not valid.
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                    message:
 *                       type: string
 *                       description: The message returned by the system.
 *              example:
 *                message: 'Please provide a query and database to translate'
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to translate query.'
 */
router.post('/search/translate-query', authenticateToken, async (req, res) => {
    const { query, databases } = req.body;
    if (!query || !databases || databases.length === 0) {
        return res.status(400).json({ message: 'Please provide a query and database to translate' });
    }
    try {
        const translatedQueries = {};
          for(const database of databases) {
                //TODO: Implement the translation logic for each databases
               if(database === 'PubMed') {
                   translatedQueries[database] = query
               }
               else {
                translatedQueries[database] = query; //placeholder
              }
            }
         res.status(200).json(translatedQueries);
    } catch (error) {
        console.error('Error translating query:', error);
        res.status(500).json({ message: 'Failed to translate query.' });
    }
});


/**
 * @swagger
 * /search/results/export:
 *   get:
 *     summary: Export search results.
 *     description: Exports the search results in a specified format.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: format
 *         required: true
 *         description: The format in which search results are exported
 *         schema:
 *           type: string
 *           enum: [csv, ris, bibtex]
 *     responses:
 *       200:
 *         description: Search results exported successfully.
 *         content:
 *           application/octet-stream:
 *             schema:
 *               type: string
 *               format: binary
 *       400:
 *         description: Bad request, input is not valid.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                  message:
 *                    type: string
 *                    description: The message returned by the system.
 *             example:
 *                message: 'Export format is required.'
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to export search results.'
 */
router.get('/search/results/export', authenticateToken, async (req, res) => {
    const { format } = req.query;
    if (!format) {
        return res.status(400).json({ message: 'Export format is required.' });
    }
      try {
          //TODO:  fetch data and export in different formats, for now we will send a hard coded text output.
       let exportedResults;
       if(format === 'csv'){
           exportedResults = `article_id,database_id,title,authors,abstract,publication_date,doi,pmid,pmcid \n "id","database", "title", "authors", "abstract","date","doi", "pmid","pmcid"`
       }
       else if (format === 'ris')
        {
        exportedResults = `TY  - JOUR \nAU  - Author, A \nTI  - Sample title \nAB  - sample Abstract \nDO  - 10.1000/xyz \nER  -`
       }else{
           exportedResults = `@article{Smith2020,
            author    = {Smith, John},
             title     = {A Sample Article Title},
             journal   = {Sample Journal},
            year      = {2020},
           doi       = {10.1000/xyz}}`
       }
        res.setHeader('Content-Type', 'text/plain');
        res.setHeader('Content-Disposition', `attachment; filename="search_results.${format}"`);
        res.status(200).send(exportedResults)
    } catch (error) {
       console.error('Error exporting search results:', error);
        res.status(500).json({ message: 'Failed to export search results.' });
    }
});
/**
 * @swagger
 * /citation/format:
 *   post:
 *     summary: Format a citation
 *     description: Format a citation string based on the provided style
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               citation:
 *                 type: string
 *                 description: The citation string to format
 *               style:
 *                  type: string
 *                  description: The citation style e.g. APA, MLA, Chicago, Vancouver
 *             example:
 *                 citation: "Sample citation"
 *                 style: "apa"
 *     responses:
 *       200:
 *         description: citation formatted successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                    formatted_citation:
 *                      type: string
 *                      description: The formatted citation
 *       400:
 *          description: Bad request, input is not valid.
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                    message:
 *                       type: string
 *                       description: The message returned by the system.
 *              example:
 *                message: 'Citation and Style is required'
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to format citation.'
 */
router.post('/citation/format', authenticateToken, async (req, res) => {
  const {citation, style} = req.body;
    if(!citation || !style) return res.status(400).json({message: 'Citation and Style is required'});
     try {
        const citeprocEngine = new citeproc.Citeproc(citeproc.getLocale('en-US'));
        const citationData = [{id: '1', citation: citation}] // Dummy Data
        citeprocEngine.registerCitationData(citationData);
           citeprocEngine.setStyle(style)
           const formatted = citeprocEngine.formatCitation([['1']])
           res.status(200).json({formatted_citation: formatted})

     } catch (error) {
         console.error('Error formatting citation:', error);
          res.status(500).json({ message: 'Failed to format citation.' });
      }
});
/**
 * @swagger
 * /citation/bibliography:
 *   post:
 *     summary: Generate bibliography.
 *     description: Generates bibliography based on the citations and the style
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               citations:
 *                 type: string
 *                 description: The citations to format and generate bibliography.
 *               style:
 *                 type: string
 *                 description: The citation style to use for bibliography e.g. APA, MLA, Chicago, Vancouver
 *             example:
 *                citations: "citation1 \n citation2 \n citation3"
 *                style: "apa"
 *     responses:
 *       200:
 *         description: Bibliography generated successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                    bibliography:
 *                      type: string
 *                      description: The generated bibliography based on given citations and style
 *       400:
 *          description: Bad request, input is not valid.
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                    message:
 *                       type: string
 *                       description: The message returned by the system.
 *              example:
 *                message: 'Please provide citations and style for bibliography.'
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to generate bibliography.'
 */
router.post('/citation/bibliography', authenticateToken, async (req, res) => {
    const {citations, style } = req.body;
     if(!citations || !style) return res.status(400).json({message: 'Please provide citations and style for bibliography.'})
   try {
         const citeprocEngine = new citeproc.Citeproc(citeproc.getLocale('en-US'));
         const citationArray = citations.split('\n').map((citation, index) => ({id: (index+1).toString(), citation: citation }))

        citeprocEngine.registerCitationData(citationArray);
         citeprocEngine.setStyle(style);
         const formatted = citeprocEngine.formatBibliography().join('\n');
         res.status(200).json({bibliography: formatted});

    } catch (error) {
       console.error('Error generating bibliography:', error);
         res.status(500).json({ message: 'Failed to generate bibliography.' });
    }
});
/**
 * @swagger
 * /citation/link:
 *   post:
 *     summary: Link citation to the article full text
 *     description: Links a citation to the full text article
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               doi:
 *                 type: string
 *                 description: DOI of the article for the link.
 *               pmid:
 *                 type: string
 *                 description: PMID of the article for the link.
 *             example:
 *                 doi: "10.1000/xyz123"
 *                 pmid: "1234567"
  *
 *     responses:
 *       200:
 *         description: Successfully linked the citation.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                    link:
 *                       type: string
 *                       description: Link to the article full text
 *       400:
 *          description: Bad request, input is not valid.
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                    message:
 *                       type: string
 *                       description: The message returned by the system.
 *              example:
 *                message: 'Please provide doi or pmid for the article.'
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to link the article.'
 */
router.post('/citation/link', authenticateToken, async (req, res) => {
    const { doi, pmid } = req.body;
     if(!doi && !pmid) return res.status(400).json({message: 'Please provide doi or pmid for the article.'})
   try {
       let link = null;
          if(doi) {
              const cachedData = cache.get(`unpaywall_${doi}`);
            if (cachedData) {
                link = cachedData;
               } else {
               const response = await unpaywallApi.get(doi);
                link = response.data?.best_oa_location?.url || `https://doi.org/${doi}`
               cache.set(`unpaywall_${doi}`, link);
              }
        } else {
               link = `https://pubmed.ncbi.nlm.nih.gov/${pmid}`
           }
           res.status(200).json({link});
    } catch (error) {
         console.error('Error linking the article:', error);
        res.status(500).json({ message: 'Failed to link the article.' });
     }
});

module.exports = router;