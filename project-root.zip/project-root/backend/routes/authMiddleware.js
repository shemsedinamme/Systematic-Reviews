// authMiddleware.js
const jwt = require('jsonwebtoken');
require('dotenv').config()
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

  if (token == null) {
        return res.sendStatus(401);
   }
     jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
         if (err) {
              return res.sendStatus(403);
         }
         req.user = user;
        next();
   });
};

const authorizeRole = (role) => {
   return (req, res, next) => {
        if(req.user && req.user.role === role){
           next();
      }else {
            return res.sendStatus(403);
         }
    };
};

module.exports = { authenticateToken, authorizeRole };