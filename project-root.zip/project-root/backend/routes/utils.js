// utils.js
const nodemailer = require('nodemailer');
require('dotenv').config();
const sendEmail = async ({ to, subject, body }) => {
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: process.env.SMTP_PORT,
    secure: true,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASSWORD,
    },
  });

  const mailOptions = {
    from: 'reviewhub@noreply.com',
    to,
    subject: subject,
    html: body
  };
  try {
    await transporter.sendMail(mailOptions);
    console.log('Email sent successfully.')
  } catch (error) {
    console.error('Error sending email', error)
  }

};

module.exports = { sendEmail };