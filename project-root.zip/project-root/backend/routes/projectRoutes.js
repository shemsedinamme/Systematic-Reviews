const express = require('express');
const { v4: uuidv4 } = require('uuid');
const pool = require('./database');
const {authenticateToken} = require('./authMiddleware');
const router = express.Router();

/**
 * @swagger
 * /projects:
 *   post:
 *     summary: Create a new project
 *     description: Creates a new project with the provided details.
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               title:
 *                 type: string
 *                 description: The title of the project.
 *               description:
 *                 type: string
 *                 description: The description of the project.
 *               start_date:
 *                 type: string
 *                 format: date
 *                 description: The start date of the project.
 *               end_date:
 *                 type: string
 *                 format: date
 *                 description: The end date of the project.
 *             example:
 *               title: "Sample Project"
 *               description: "This is a sample project description."
 *               start_date: "2024-01-01"
 *               end_date: "2024-12-31"
 *     responses:
 *       201:
 *         description: Project created successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 project_id:
 *                   type: string
 *                   description: The unique identifier of the project.
 *                 title:
 *                   type: string
 *                   description: The title of the project.
 *                 description:
 *                   type: string
 *                   description: The description of the project.
 *                 start_date:
 *                   type: string
 *                   format: date
 *                   description: The start date of the project.
 *                 end_date:
 *                   type: string
 *                   format: date
 *                   description: The end date of the project.
 *       400:
 *         description: Bad request, input is not valid.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                  message:
 *                    type: string
 *                    description: The message returned by the system.
 *             example:
 *                message: 'Title, description, start and end dates are required.'
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to create project.'
 */
router.post('/projects', authenticateToken, async (req, res) => {
    const { title, description, start_date, end_date } = req.body;
    if(!title || !description || !start_date || !end_date){
        return res.status(400).json({message: 'Title, description, start and end dates are required.'})
    }
    try {
        const newProject = await pool.query(
            'INSERT INTO projects (project_id, title, description, start_date, end_date, creation_date) VALUES (?, ?, ?, ?, ?, NOW()) ',
            [uuidv4(), title, description, start_date, end_date]
        );
        const project = {
          project_id: uuidv4(),
          title: title,
          description: description,
          start_date: start_date,
          end_date: end_date
        }
        await pool.query(
            'INSERT INTO user_project_relations (user_id, project_id, role) VALUES (?, ?, ?)',
            [req.user.user_id, project.project_id, 'project_owner']
        );
        res.status(201).json(project);
    } catch (error) {
        console.error('Error creating project:', error);
        res.status(500).json({ message: 'Failed to create project.' });
    }
});

/**
 * @swagger
 * /projects/{project_id}/metadata:
 *   get:
 *     summary: Get metadata of a project
 *     description: Gets the metadata for a specific project using project ID.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: project_id
 *         required: true
 *         description: ID of the project to get the metadata.
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Metadata fetched successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                     meta_id:
 *                       type: string
 *                       description: unique id for meta data item
 *                     field_name:
 *                       type: string
 *                       description: name of the meta data field
 *                     value:
 *                       type: string
 *                       description: value for the meta data field
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to fetch project metadata.'
 */
router.get('/projects/:project_id/metadata', authenticateToken, async (req, res) => {
    const {project_id} = req.params;
    try {
        const [projectMetadata] = await pool.query(
            `SELECT pm.meta_id, mf.field_name, pm.value
                 FROM project_metadata pm
                 JOIN metadata_fields mf ON pm.field_id = mf.field_id
                  WHERE pm.project_id = ?`,
            [project_id]
        );
        res.status(200).json(projectMetadata);
    } catch (error) {
        console.error('Error fetching project metadata:', error);
        res.status(500).json({ message: 'Failed to fetch project metadata.' });
    }
});

/**
 * @swagger
 * /projects/{project_id}/metadata:
 *   post:
 *     summary: Add new metadata to a project
 *     description: Adds new metadata to a specific project using project ID.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: project_id
 *         required: true
 *         description: ID of the project to add the metadata.
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               field_name:
 *                 type: string
 *                 description: The name of the metadata field.
 *               value:
 *                 type: string
 *                 description: The value for the metadata field.
 *             example:
 *                 field_name: "author"
 *                 value: "John Doe"
 *     responses:
 *       201:
 *         description: New metadata added successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 meta_id:
 *                   type: string
 *                   description: The unique identifier of the meta data item.
 *                 field_name:
 *                    type: string
 *                    description: The name of the meta data field
 *                 value:
 *                   type: string
 *                   description: The value for the metadata field.
 *       400:
 *         description: Bad request, input is not valid.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                  message:
 *                    type: string
 *                    description: The message returned by the system.
 *             example:
 *                message: 'Metadata field name is required'
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to add project metadata.'
 */
router.post('/projects/:project_id/metadata', authenticateToken, async (req, res) => {
    const {project_id} = req.params;
    const {field_name, value} = req.body
    if(!field_name) return res.status(400).json({message: 'Metadata field name is required'})
    try {
        //check if metadata field exists
        let [metaField] = await pool.query('SELECT * from metadata_fields WHERE field_name = ?', [field_name]);
        if(metaField.length === 0){
            const newMetaField = await pool.query(
              'INSERT INTO metadata_fields (field_id, field_name) VALUES (?, ?) ', [uuidv4(), field_name])
              metaField = [{field_id: uuidv4(), field_name: field_name}]
        }
        const [newProjectMetadata] = await pool.query(
            'INSERT INTO project_metadata (meta_id, project_id, field_id, value) VALUES (?, ?, ?, ?) ',
            [uuidv4(), project_id, metaField[0].field_id, value || null]
        );
         const metaData = {
            meta_id: uuidv4(),
            field_id: metaField[0].field_id,
            value: value || null,
            field_name: field_name
        };
        res.status(201).json(metaData);
    } catch (error) {
        console.error('Error adding project metadata:', error);
        res.status(500).json({ message: 'Failed to add project metadata.' });
    }
});

/**
 * @swagger
 * /projects/{project_id}/metadata:
 *   put:
 *     summary: Update metadata of a project
 *     description: Updates existing metadata of a specific project using project ID.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: project_id
 *         required: true
 *         description: ID of the project to update the metadata.
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               meta_id:
 *                 type: string
 *                 description: The unique identifier of the meta data item.
 *               value:
 *                 type: string
 *                 description: The new value for the metadata field.
 *             example:
 *                 meta_id: "6b7b6172-d59c-4f12-9e7d-6527d0e210d1"
 *                 value: "Jane Doe"
 *     responses:
 *       200:
 *         description: Metadata updated successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                    meta_id:
 *                       type: string
 *                       description: unique id for meta data item
 *                    field_name:
 *                       type: string
 *                       description: name of the meta data field
 *                    value:
 *                       type: string
 *                       description: value for the meta data field
 *       400:
 *          description: Bad request, input is not valid.
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                    message:
 *                       type: string
 *                       description: The message returned by the system.
 *              example:
 *                message: 'Metadata Id and Value required for update.'
 *       404:
 *          description: metadata not found
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                    message:
 *                       type: string
 *                       description: The message returned by the system.
 *              example:
 *                message: 'Metadata not found.'
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to update project metadata.'
 */
router.put('/projects/:project_id/metadata', authenticateToken, async (req, res) => {
    const { meta_id, value } = req.body;
    if(!meta_id || !value) return res.status(400).json({message: 'Metadata Id and Value required for update.'});
    try {
        const [updatedProjectMetadata] = await pool.query(
            'UPDATE project_metadata SET value = ? WHERE meta_id = ?',
            [value, meta_id]
        );
         if(updatedProjectMetadata.affectedRows === 0) return res.status(404).json({message: 'Metadata not found.'})
        const [metaField] = await pool.query(
            'SELECT field_name from metadata_fields WHERE field_id = ?',
            [updatedProjectMetadata.field_id]
        );
        const metaData = {
             meta_id: meta_id,
             field_name: metaField[0].field_name,
            value: value
        }
        res.status(200).json(metaData);
    } catch (error) {
        console.error('Error updating project metadata:', error);
        res.status(500).json({ message: 'Failed to update project metadata.' });
    }
});

/**
 * @swagger
 * /projects/search:
 *   get:
 *     summary: Search project based on metadata
 *     description: searches projects based on the query from title, description and metadata.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: query
 *         required: true
 *         description: search query
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Metadata fetched successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                    project_id:
 *                      type: string
 *                      description: unique id of the project.
 *                    title:
 *                      type: string
 *                      description: The title of the project.
 *       400:
 *          description: Bad request, input is not valid.
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                    message:
 *                       type: string
 *                       description: The message returned by the system.
 *              example:
 *                message: 'Search query parameter is required.'
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to search projects by metadata.'
 */
router.get('/projects/search', authenticateToken, async (req, res) => {
    const {query} = req.query;
    if(!query) return res.status(400).json({message: 'Search query parameter is required.'})
    try {
        const [searchResults] = await pool.query(
            `SELECT p.project_id, p.title
                 FROM projects p
                  WHERE p.title LIKE ? OR
                        p.description LIKE ? OR
                         EXISTS (SELECT 1 from project_metadata pm JOIN metadata_fields mf on pm.field_id = mf.field_id WHERE pm.project_id = p.project_id AND (pm.value LIKE ? OR mf.field_name LIKE ?))`,
            [`%${query}%`, `%${query}%`, `%${query}%`, `%${query}%`]
        );
        res.status(200).json(searchResults);
    } catch (error) {
        console.error('Error searching projects by metadata:', error);
        res.status(500).json({ message: 'Failed to search projects by metadata.' });
    }
});

/**
 * @swagger
 * /projects/{project_id}/workflows:
 *   get:
 *     summary: Get workflows for a project.
 *     description: Gets workflows for a project based on project ID.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: project_id
 *         required: true
 *         description: ID of the project to get the workflow.
 *         schema:
 *           type: string
  *     responses:
 *       200:
 *         description: Workflow fetched successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                   workflow_id:
 *                     type: string
 *                     description: id of the workflow
 *                   workflow_name:
 *                      type: string
 *                      description: name of the workflow.
 *                   stages:
 *                      type: array
 *                      description: array of workflow stages
 *                      items:
 *                           type: object
 *                           properties:
 *                              stage_id:
 *                                 type: string
 *                                 description: id of the workflow stage
 *                              stage_name:
 *                                type: string
 *                                description: name of the workflow stage
 *                              tasks:
 *                                  type: array
 *                                  description: array of tasks for this stage
 *                                  items:
 *                                       type: object
 *                                       properties:
 *                                          task_id:
 *                                             type: string
 *                                             description: id of the task
 *                                          task_name:
 *                                            type: string
 *                                            description: name of the task
 *                                          assigned_user_id:
 *                                            type: string
 *                                            description: id of the user assigned to this task
 *                                          due_date:
 *                                            type: string
 *                                            description: due date of the task
 *                                          dependencies:
 *                                              type: array
 *                                              description: array of dependencies for the task
 *                                              items:
 *                                                   type: object
 *                                                   properties:
 *                                                     dependency_id:
 *                                                        type: string
 *                                                        description: id of the dependency
 *       404:
 *          description: Workflow not found.
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                    message:
 *                       type: string
 *                       description: The message returned by the system.
 *              example:
 *                message: 'No workflow found for this project.'
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to fetch project workflows.'
 */
router.get('/projects/:project_id/workflows', authenticateToken, async (req, res) => {
    const { project_id } = req.params;
    try {
        const [workflowQuery] = await pool.query(
            'SELECT workflow_id, workflow_name FROM project_workflows WHERE project_id = ?',
            [project_id]
        );
        if(workflowQuery.length === 0) return res.status(404).json({message: 'No workflow found for this project.'});
        const workflowId = workflowQuery[0].workflow_id;
        const [stagesQuery] = await pool.query(
            'SELECT stage_id, stage_name FROM workflow_stages WHERE workflow_id = ?',
            [workflowId]
        );
        const stages = stagesQuery;
        const tasks = await Promise.all(stages.map(async stage => {
            const [tasksQuery] = await pool.query(
                'SELECT task_id, task_name, assigned_user_id, due_date FROM tasks WHERE stage_id = ?',
                [stage.stage_id]
            )
            const tasks = tasksQuery;
            const dependencies = await Promise.all(tasks.map(async task =>{
                const [dependenciesQuery] = await pool.query(
                    'SELECT dependency_id FROM task_dependencies WHERE task_id = ?',
                    [task.task_id]
                )
                return {...task, dependencies: dependenciesQuery}
            }))
            return {...stage, tasks: dependencies};
        }));
        res.status(200).json({ ...workflowQuery[0], stages: tasks });
    } catch (error) {
        console.error('Error fetching project workflows:', error);
        res.status(500).json({ message: 'Failed to fetch project workflows.' });
    }
});

/**
 * @swagger
 * /projects/{project_id}/workflows:
 *   post:
 *     summary: Create a new workflow for a project
 *     description: Creates a new workflow for a project based on project ID.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: project_id
 *         required: true
 *         description: ID of the project to add the workflow.
 *         schema:
 *           type: string
 *     responses:
 *       201:
 *         description: Workflow created successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                   workflow_id:
 *                     type: string
 *                     description: The id of the new workflow
 *                   workflow_name:
 *                     type: string
 *                     description: The name of the new workflow
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to create project workflow.'
 */
router.post('/projects/:project_id/workflows', authenticateToken, async (req, res) => {
    const { project_id } = req.params;
    try {
        const [newWorkflow] = await pool.query(
            'INSERT INTO project_workflows (workflow_id, project_id) VALUES (?, ?) ',
            [uuidv4(), project_id]
        );
        const workflow = {
          workflow_id: uuidv4(),
          workflow_name: 'default',
          project_id: project_id
        }
        res.status(201).json(workflow);
    } catch (error) {
        console.error('Error creating a new workflow for project:', error);
        res.status(500).json({ message: 'Failed to create project workflow.' });
    }
});

/**
 * @swagger
 * /workflows/{workflow_id}/stages:
 *   post:
 *     summary: Adds new stage to a workflow.
 *     description: Adds a new stage to the workflow by workflow ID.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: workflow_id
 *         required: true
 *         description: ID of the workflow to add the stage.
 *         schema:
 *           type: string
  *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               stage_name:
 *                 type: string
 *                 description: The name of the stage.
 *             example:
 *                 stage_name: "Data Extraction"
 *     responses:
 *       201:
 *         description: Workflow stage added successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                    stage_id:
 *                      type: string
 *                      description: The unique identifier for workflow stage
 *                    stage_name:
 *                      type: string
 *                      description: name of the workflow stage
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to add a new workflow stage.'
 */
router.post('/workflows/:workflow_id/stages', authenticateToken, async (req, res) => {
    const { workflow_id } = req.params;
    const { stage_name } = req.body;
    try {
        const [newStage] = await pool.query(
            'INSERT INTO workflow_stages (stage_id, workflow_id, stage_name) VALUES (?, ?, ?) ',
            [uuidv4(), workflow_id, stage_name]
        );
        const stage = {
            stage_id: uuidv4(),
            stage_name: stage_name
        };
        res.status(201).json(stage);
    } catch (error) {
        console.error('Error adding a workflow stage:', error);
        res.status(500).json({ message: 'Failed to add a new workflow stage.' });
    }
});

/**
 * @swagger
 * /stages/{stage_id}/tasks:
 *   post:
 *     summary: Adds new task to a workflow stage.
 *     description: Adds a new task to the workflow stage based on stage ID.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: stage_id
 *         required: true
 *         description: ID of the workflow stage to add a task.
 *         schema:
 *           type: string
  *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               task_name:
 *                 type: string
 *                 description: The name of the task.
 *             example:
 *                 task_name: "Extract data from the articles"
 *     responses:
 *       201:
 *         description: Task added to a workflow stage successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                    task_id:
 *                      type: string
 *                      description: The unique identifier for workflow task
 *                    task_name:
 *                      type: string
 *                      description: name of the workflow task
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to add a new task.'
 */
router.post('/stages/:stage_id/tasks', authenticateToken, async (req, res) => {
    const { stage_id } = req.params;
    const { task_name } = req.body;
    try {
        const [newTask] = await pool.query(
            'INSERT INTO tasks (task_id, stage_id, task_name) VALUES (?, ?, ?) ',
            [uuidv4(), stage_id, task_name]
        );
        const task = {
            task_id: uuidv4(),
            task_name: task_name
        }
        res.status(201).json(task);
    } catch (error) {
        console.error('Error adding a task to the workflow stage:', error);
        res.status(500).json({ message: 'Failed to add a new task.' });
    }
});

/**
 * @swagger
 * /tasks/{task_id}/assign:
 *   post:
 *     summary: Assign a user to a task.
 *     description: Assign a user to a task using task ID and user ID.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: task_id
 *         required: true
 *         description: ID of the task to assign the user.
 *         schema:
 *           type: string
  *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               user_id:
 *                 type: string
 *                 description: The id of the user to assign the task.
 *               due_date:
 *                 type: string
 *                 description: The due date of the task.
 *             example:
 *                 user_id: "6b7b6172-d59c-4f12-9e7d-6527d0e210d1"
 *                 due_date: "2024-12-20"
 *     responses:
 *       200:
 *         description: Task assigned to user successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                    task_id:
 *                      type: string
 *                      description: The unique identifier for workflow task
 *                    task_name:
 *                      type: string
 *                      description: name of the workflow task
 *                   assigned_user_id:
 *                      type: string
 *                      description: id of the user assigned to the task
 *                   due_date:
 *                      type: string
 *                      description: due date of the task
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to assign the task.'
 */
router.post('/tasks/:task_id/assign', authenticateToken, async (req, res) => {
    const { task_id } = req.params;
    const { user_id, due_date } = req.body;
    try {
        const [updatedTask] = await pool.query(
            'UPDATE tasks SET assigned_user_id = ?, due_date = ? WHERE task_id = ?',
            [user_id, due_date, task_id]
        );
        const task = {
            task_id: task_id,
            assigned_user_id: user_id,
            due_date: due_date
        }
         res.status(200).json(task);
    } catch (error) {
        console.error('Error assigning task to user:', error);
        res.status(500).json({ message: 'Failed to assign the task.' });
    }
});

/**
 * @swagger
 * /tasks/{task_id}/dependencies:
 *   post:
 *     summary: Add a dependency to a task
 *     description: Adds a dependency for a task using task ID.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: task_id
 *         required: true
 *         description: ID of the task to add dependency.
 *         schema:
 *           type: string
  *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               dependency_id:
 *                 type: string
 *                 description: The id of the task that is dependency.
 *             example:
 *                 dependency_id: "6b7b6172-d59c-4f12-9e7d-6527d0e210d1"
 *     responses:
 *       200:
 *         description: Task dependency added successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                    task_id:
 *                      type: string
 *                      description: The unique identifier for workflow task
  *                    task_name:
 *                      type: string
 *                      description: name of the workflow task
 *                   dependencies:
 *                      type: array
 *                      items:
 *                          type: object
 *                          properties:
 *                            dependency_id:
 *                               type: string
 *                               description: id of dependency for the task
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to add task dependency.'
 */
router.post('/tasks/:task_id/dependencies', authenticateToken, async (req, res) => {
    const { task_id } = req.params;
    const { dependency_id } = req.body;
    try {
        const [dependency] = await pool.query(
            'INSERT INTO task_dependencies (dependency_id, task_id) VALUES (?, ?) ',
            [dependency_id, task_id]
        );
        const [updatedTask] = await pool.query(
            'SELECT * FROM tasks WHERE task_id = ?',
            [task_id]
        );
        res.status(200).json({...updatedTask[0], dependencies: dependency});
    } catch (error) {
          console.error('Error adding task dependency:', error);
        res.status(500).json({ message: 'Failed to add task dependency.' });
    }
});

/**
 * @swagger
 * /projects/{project_id}/share:
 *   post:
 *     summary: Share a project with a user or generate a share link.
 *     description: Allows a project to be shared with another user or a shareable link to be created for the project.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: project_id
 *         required: true
 *         description: ID of the project being shared.
 *         schema:
 *           type: string
  *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *                share_with:
 *                  type: string
 *                  description: The email or username of the user to share the project with.
 *                access_type:
 *                  type: string
 *                  description: The access type for the shared project ("read-only", "read-write").
 *                password:
 *                  type: string
 *                  description: password for shareable link
 *                share_link:
 *                  type: boolean
 *                  description: whether the shareable link should be generated
 *             example:
 *                 share_with: "johndoe@example.com"
 *                 access_type: "read-only"
 *                 share_link: false
 *     responses:
 *       200:
 *         description: Project shared successfully or shareable link generated
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                     type: string
 *                     description: status message about project share
  *                 share_link:
 *                      type: string
 *                      description: shareable link to the project if generated.
 *       404:
 *         description: User not found.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *               message: 'User does not exist'
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to share project.'
 */
router.post('/projects/:project_id/share', authenticateToken, async (req, res) => {
    const { project_id } = req.params;
    const { share_with, access_type, password, share_link } = req.body;
    try {
        if(share_link){
            const shareableLink = uuidv4();
             //TODO: password protect the share link using a temporary table and password encryption
            res.status(200).json({share_link: `http://localhost:3000/projects/shared/${shareableLink}` });
            return;
        }
        const [user] = await pool.query('SELECT user_id FROM users WHERE email = ? OR username = ?', [share_with, share_with]);
        if(user.length === 0) return res.status(404).json({message:'User does not exist'});
         await pool.query(
            'INSERT INTO project_access (project_id, user_id, access_type) VALUES (?, ?, ?)',
            [project_id, user[0].user_id, access_type || 'read-only']
        );
        res.status(200).json({ message: 'Project shared successfully.' });
    } catch (error) {
        console.error('Error sharing project:', error);
        res.status(500).json({ message: 'Failed to share project.' });
    }
});

/**
 * @swagger
 * /projects/{project_id}/share:
 *   get:
 *     summary: Get a shareable link for a project
 *     description: Creates and fetches a shareable link for a specific project.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: project_id
 *         required: true
 *         description: ID of the project to generate the share link
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Shareable link generated successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 share_link:
 *                   type: string
 *                   description: The generated shareable link for the project.
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to generate project link'
 */
router.get('/projects/:project_id/share', authenticateToken, async (req, res) => {
    const {project_id} = req.params;
    try {
        //TODO: generate a shareable link for project with access permissions
        res.status(200).json({share_link: `http://localhost:3000/projects/shared/${uuidv4()}`})
    } catch (error) {
        console.error('Error generating project link:', error);
        res.status(500).json({ message: 'Failed to generate project link' });
    }
});

/**
 * @swagger
 * /projects/{project_id}/lifecycle:
 *   get:
 *     summary: Get project lifecycle state
 *     description: gets the project lifecycle state based on project ID
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: project_id
 *         required: true
 *         description: ID of the project to get the lifecycle state.
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Project lifecycle state fetched successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 state:
 *                   type: string
 *                   description: state of the project in its lifecycle.
 *       404:
 *          description: Project not found.
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                    message:
 *                       type: string
 *                       description: The message returned by the system.
 *              example:
 *                message: 'Project does not exist'
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to fetch project lifecycle state'
 */
router.get('/projects/:project_id/lifecycle', authenticateToken, async (req, res) => {
    const { project_id } = req.params;
    try {
        const [project] = await pool.query('SELECT status FROM projects WHERE project_id = ?', [project_id]);
        if(project.length === 0) return res.status(404).json({message:'Project does not exist'});
        res.status(200).json({state: project[0].status});
    } catch (error) {
        console.error('Error fetching project lifecycle state:', error);
        res.status(500).json({ message: 'Failed to fetch project lifecycle state' });
    }
});

/**
 * @swagger
 * /projects/{project_id}/{action}:
 *   post:
 *     summary: transition the project to different lifecycle phase
 *     description: transition the project to different lifecycle phase by providing the action.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: project_id
 *         required: true
 *         description: ID of the project to be transitioned
 *         schema:
 *           type: string
 *       - in: path
 *         name: action
 *         required: true
 *         description: Action to transition to (initiation, planning, execution, monitoring, closure).
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Project lifecycle transitioned successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 state:
 *                   type: string
 *                   description: The state to which project transitioned.
 *       400:
 *          description: Bad request, input is not valid.
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                    message:
 *                       type: string
 *                       description: The message returned by the system.
 *              example:
 *                message: 'Invalid action'
 *       404:
 *          description: Project not found.
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                    message:
 *                       type: string
 *                       description: The message returned by the system.
 *              example:
 *                message: 'Project not found'
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to transition project lifecycle.'
 */
router.post('/projects/:project_id/:action', authenticateToken, async (req, res) => {
    const { project_id, action } = req.params;
    try {
        const validActions = ['initiation', 'planning', 'execution', 'monitoring', 'closure'];
        if (!validActions.includes(action)) {
            return res.status(400).json({ message: 'Invalid action' });
        }
        const [updatedProject] = await pool.query('UPDATE projects SET status = ? WHERE project_id = ?', [action, project_id]);
        if (updatedProject.affectedRows === 0) return res.status(404).json({message: 'Project not found'})
        res.status(200).json({state: action});
    } catch (error) {
        console.error('Error transitioning project lifecycle:', error);
        res.status(500).json({ message: 'Failed to transition project lifecycle.' });
    }
});

/**
 * @swagger
 * /projects/{project_id}/documents/{document_id}:
 *   get:
 *     summary: Get document of a project
 *     description: Gets the document of a project using project and document IDs
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: project_id
 *         required: true
 *         description: ID of the project
 *         schema:
 *           type: string
 *       - in: path
 *         name: document_id
 *         required: true
 *         description: ID of the document
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Document content fetched successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                   document_id:
 *                     type: string
 *                     description: The id of the document
 *                   content:
 *                      type: string
 *                      description: The content of the document
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to fetch the document.'
 */
router.get('/projects/:project_id/documents/:document_id', authenticateToken, async (req, res) => {
    const { project_id, document_id } = req.params;
    try {
        const [document] = await pool.query('SELECT document_id, content FROM documents WHERE project_id = ? AND document_id = ?', [project_id, document_id]);
        if (document.length === 0) return res.status(404).json({ message: 'Document not found' });
        res.status(200).json(document[0]);
    } catch (error) {
        console.error('Error fetching document:', error);
        res.status(500).json({ message: 'Failed to fetch the document.' });
    }
});
/**
 * @swagger
 * /projects/{project_id}/documents/{document_id}:
 *   put:
 *     summary: updates the document
 *     description: updates document content using project ID and document ID
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: project_id
 *         required: true
 *         description: ID of the project
 *         schema:
 *           type: string
 *       - in: path
 *         name: document_id
 *         required: true
 *         description: ID of the document
 *         schema:
 *           type: string
  *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               content:
 *                 type: string
 *                 description: content of the document
 *             example:
 *                 content: "Document content"
 *     responses:
 *       200:
 *         description: Document updated successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                   document_id:
 *                     type: string
 *                     description: The id of the document
 *                   content:
 *                      type: string
 *                      description: The content of the document
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to save document content'
 */
router.put('/projects/:project_id/documents/:document_id', authenticateToken, async (req, res) => {
     const { project_id, document_id } = req.params;
    const { content } = req.body;
    try {
        const [document] = await pool.query(
            'SELECT content FROM documents WHERE document_id = ?', [document_id]
        );
       if(document.length === 0){
         const [newDocument] = await pool.query(
              'INSERT INTO documents (document_id, project_id, content) VALUES (?, ?, ?) ',
                [uuidv4(), project_id, content]
          );
           const doc = {
             document_id: uuidv4(),
             content: content,
           }
              res.status(200).json(doc);
              return;
       }
        const [updatedDocument] = await pool.query(
            'UPDATE documents SET content = ? WHERE document_id = ?',
            [content, document_id]
        );
         await pool.query(
            'INSERT INTO document_versions (version_id, document_id, content) VALUES (?, ?, ?)',
            [uuidv4(), document_id, content]
        )
        const doc = {
            document_id: document_id,
            content: content,
        }
          res.status(200).json(doc);
    } catch (error) {
        console.error('Error updating document content:', error);
         res.status(500).json({ message: 'Failed to save document content' });
    }
});


/**
 * @swagger
 * /projects/{project_id}/comments:
 *   get:
 *     summary: Get comments for a project
 *     description: Gets all comments of a project based on project ID
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: project_id
 *         required: true
 *         description: ID of the project to get the comments from
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Comments fetched successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                  type: object
 *                  properties:
 *                     comment_id:
 *                       type: string
 *                       description: id of the comment.
 *                     text:
 *                       type: string
 *                       description: text of the comment
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to fetch comments.'
 */
router.get('/projects/:project_id/comments', authenticateToken, async (req, res) => {
    const { project_id } = req.params;
    try {
        const [comments] = await pool.query(
            'SELECT comment_id, text FROM comments WHERE project_id = ?',
            [project_id]
        );
        res.status(200).json(comments);
    } catch (error) {
        console.error('Error fetching comments:', error);
        res.status(500).json({ message: 'Failed to fetch comments.' });
    }
});

/**
 * @swagger
 * /projects/{project_id}/comments:
 *   post:
 *     summary: add a new comment to a project
 *     description: adds a new comment to a project using project ID
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: project_id
 *         required: true
 *         description: ID of the project to add the comment.
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               text:
 *                 type: string
 *                 description: The comment message
 *             example:
 *                 text: "This is a test comment"
 *     responses:
 *       201:
 *         description: comment added successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                    comment_id:
 *                      type: string
 *                      description: id of the comment
 *                    text:
 *                      type: string
 *                      description: text of the comment
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to add comment'
 */
router.post('/projects/:project_id/comments', authenticateToken, async (req, res) => {
    const { project_id } = req.params;
    const { text } = req.body;
    try {
        const [newComment] = await pool.query(
            'INSERT INTO comments (comment_id, project_id, user_id, text) VALUES (?, ?, ?, ?) ',
            [uuidv4(), project_id, req.user.user_id, text]
        );
        const comment = {
            comment_id: uuidv4(),
            text: text
        }
        res.status(201).json(comment);
    } catch (error) {
        console.error('Error adding comment:', error);
         res.status(500).json({ message: 'Failed to add comment' });
    }
});

/**
 * @swagger
 * /projects/{project_id}/files:
 *   get:
 *     summary: Get files of a project
 *     description: Gets files of a project based on project ID
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: project_id
 *         required: true
 *         description: ID of the project to get the files from
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Files fetched successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                  type: object
 *                  properties:
 *                     file_id:
 *                       type: string
 *                       description: id of the file.
 *                     file_path:
 *                       type: string
 *                       description: path of the file.
 *                     file_name:
 *                       type: string
 *                       description: name of the file.
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to fetch files'
 */
router.get('/projects/:project_id/files', authenticateToken, async (req, res) => {
    const { project_id } = req.params;
    try {
        const [files] = await pool.query(
            'SELECT file_id, file_path, file_name FROM files WHERE project_id = ?',
            [project_id]
        );
        res.status(200).json(files);
    } catch (error) {
        console.error('Error fetching files:', error);
        res.status(500).json({ message: 'Failed to fetch files' });
    }
});

/**
 * @swagger
 * /projects/{project_id}/files:
 *   post:
 *     summary: Uploads a new file to a project.
 *     description: upload a file to the project using project ID
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: project_id
 *         required: true
 *         description: ID of the project to add the file.
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               file:
 *                 type: string
 *                 format: binary
 *     responses:
 *       201:
 *         description: File uploaded successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                    file_id:
 *                      type: string
 *                      description: id of the file
 *                    file_path:
 *                      type: string
 *                      description: path of the uploaded file
 *                   file_name:
 *                      type: string
 *                      description: name of the file
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'File upload failed'
 */
router.post('/projects/:project_id/files', authenticateToken, async (req, res) => {
    const { project_id } = req.params;
    try {
        if(!req.files || !req.files.file) {
            return res.status(400).send('No file was uploaded');
        }
        const file = req.files.file;
        const file_name = file.name;
          //TODO: replace with cloud file storage
        const file_path = `/uploads/${file.name}` //save files to upload folder
           await file.mv(`./uploads/${file.name}`);
        const [newFile] = await pool.query(
            'INSERT INTO files (file_id, project_id, file_path, file_name) VALUES (?, ?, ?, ?) ',
            [uuidv4(), project_id, file_path, file_name]
        );
        const fileDetails = {
            file_id: uuidv4(),
            file_path: file_path,
            file_name: file_name
        };
        res.status(201).json(fileDetails);
    } catch (error) {
        console.error('Error uploading file:', error);
         res.status(500).json({ message: 'File upload failed' });
    }
});

/**
 * @swagger
 * /projects/{project_id}/documents/{document_id}/version:
 *   get:
 *     summary: Gets versions history of the project document.
 *     description: Gets version history of a document using project id and document id.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: project_id
 *         required: true
 *         description: ID of the project
 *         schema:
 *           type: string
 *       - in: path
 *         name: document_id
 *         required: true
 *         description: ID of the document
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Fetched document version history successfully.
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                  type: object
 *                  properties:
 *                     version_id:
 *                       type: string
 *                       description: id of the document version.
 *                     version_date:
 *                        type: string
 *                        format: date-time
 *                        description: version date of the document.
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to fetch version history'
 */
router.get('/projects/:project_id/documents/:document_id/version', authenticateToken, async (req, res) => {
    const { document_id } = req.params;
    try {
        const [versionHistory] = await pool.query(
            'SELECT version_id, version_date FROM document_versions WHERE document_id = ?',
            [document_id]
        );
        res.status(200).json(versionHistory);
    } catch (error) {
        console.error('Error fetching version history:', error);
        res.status(500).json({ message: 'Failed to fetch version history' });
    }
});

/**
 * @swagger
 * /documents/{document_id}/versions/{versionId}/revert:
 *   post:
 *     summary: Reverts a project document to a specified version.
 *     description: Reverts project document to specified version using document ID and version ID
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: document_id
 *         required: true
 *         description: ID of the document.
 *         schema:
 *           type: string
 *       - in: path
 *         name: versionId
 *         required: true
 *         description: ID of the version to revert to.
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Document reverted to the specified version successfully.
  *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                    document_id:
 *                      type: string
 *                      description: The id of the document
 *                    content:
 *                      type: string
 *                      description: content of the document
 *       500:
 *         description: Internal server error.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: The message returned by the system.
 *             example:
 *                message: 'Failed to revert to a version.'
 */
router.post('/documents/:document_id/versions/:versionId/revert', authenticateToken, async (req, res) => {
    const { document_id, versionId } = req.params;
    try {
        const [version] = await pool.query(
            'SELECT content FROM document_versions WHERE version_id = ? AND document_id = ?',
            [versionId, document_id]
        );
         if(version.length === 0) return res.status(404).json({message: 'version is not found'});
        const [updatedDocument] =  await pool.query(
            'UPDATE documents SET content = ? WHERE document_id = ?',
             [version[0].content, document_id]
        );
        const doc = {
            document_id: document_id,
            content: version[0].content
        };
        res.status(200).json(doc);
    } catch (error) {
        console.error('Error reverting to version', error);
        res.status(500).json({ message: 'Failed to revert to a version.' });
    }
});
module.exports = router;
        
        