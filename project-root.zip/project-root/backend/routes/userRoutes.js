// userRoutes.js
  const express = require('express');
const bcrypt = require('bcrypt');
const pool = require('./database');
const { v4: uuidv4 } = require('uuid');
const { sendEmail } = require('./utils')
const router = express.Router();

router.post('/register', async (req, res) => {
  const { username, email, password, subscriptionOption, studentId } = req.body;
  if (!username || !email || !password) return res.status(400).json({ message: 'Username, email and password are required' });
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ message: 'Invalid email format.' });
  }
  if (password.length < 8) {
    return res.status(400).json({ message: 'Password must be at least 8 characters long.' });
  }
  if (username.length < 3) {
    return res.status(400).json({ message: 'Username must be at least 3 characters long.' });
  }

  try {
    // Check if the email or username exists
    const existingUser = await pool.query('SELECT * FROM users WHERE email = ? OR username = ?', [email, username]);
    if (existingUser[0].length > 0) {
      return res.status(400).json({ message: 'Email or username already registered.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = await pool.query(
      'INSERT INTO users (user_id, username, email, hashed_password) VALUES (?, ?, ?, ?) ',
      [uuidv4(), username, email, hashedPassword]
    );
    const user = {
      user_id: uuidv4(),
      username: username,
      email: email,
    }
    const emailContent = `Thank you for registering an account, ${username}! Your subscription type is ${subscriptionOption}, Student Id is ${studentId || ''}`
    await sendEmail({
      to: email,
      subject: 'New User Registration Confirmation',
      body: emailContent
    })
    await sendEmail({
      to: 'admin@reviewhub.net.et',
      subject: 'New User Registration Confirmation',
      body: `A new user has registered. Username:${username}, Email: ${email}. Subscription type:${subscriptionOption}, Student Id: ${studentId || ''}`
    })
    res.status(201).json(user);
  } catch (error) {
    console.error('Error during user registration:', error);
    res.status(500).json({ message: 'Registration failed.' });
  }
});

module.exports = router;

// userRoutes.js
const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const pool = require('./database');
require('dotenv').config();
const router = express.Router();
router.post('/login', async (req, res) => {
  const { usernameEmail, password } = req.body;
  if(!usernameEmail || !password) return res.status(400).json({message: 'Username or Email and password are required'});
  try {
       const [user] = await pool.query('SELECT * FROM users WHERE email = ? OR username = ?', [usernameEmail, usernameEmail]);
        if(user.length === 0) return res.status(401).json({message: 'Invalid login credentials.'});
        const validPassword = await bcrypt.compare(password, user[0].hashed_password);
        if (!validPassword) {
         return res.status(401).json({ message: 'Invalid login credentials.' });
       }
      const token = jwt.sign(
        { user_id: user[0].user_id, role: user[0].role },
          process.env.JWT_SECRET,
          { expiresIn: '1h' }
        );
        res.status(200).json({ token });
     } catch (error) {
        console.error('Error during user login:', error);
        res.status(500).json({ message: 'Login failed.' });
      }
});

module.exports = router;


// userRoutes.js
const express = require('express');
const pool = require('./database');
const { authenticateToken } = require('./authMiddleware');
const router = express.Router();

router.get('/profile', authenticateToken, async (req, res) => {
  try {
      const user = await pool.query('SELECT user_id, username, email, role FROM users WHERE user_id = $1', [req.user.user_id]);
    if(user.rows.length === 0){
        return res.status(404).json({message:'User not found.'})
    }
      res.status(200).json(user.rows[0]);
   } catch (error) {
        console.error('Error fetching user profile:', error);
      res.status(500).json({ message: 'Failed to fetch user profile.' });
    }
});

router.put('/profile', authenticateToken, async (req, res) => {
  const { username, email } = req.body;
    try {
     const user = await pool.query('UPDATE users SET username = $1, email = $2 WHERE user_id = $3 RETURNING user_id, username, email, role', [username, email, req.user.user_id]);
      if (user.rows.length === 0) {
         return res.status(404).json({message: 'User not found.'})
      }
         res.status(200).json(user.rows[0]);
      } catch (error) {
        console.error('Error updating user profile:', error);
        res.status(500).json({ message: 'Failed to update user profile.' });
    }
});

module.exports = router;

// userRoutes.js
const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const pool = require('./database');
const { v4: uuidv4 } = require('uuid');
require('dotenv').config();
const {sendEmail} = require('./utils')
const router = express.Router();

router.post('/reset-password-request', async (req, res) => {
  const { email } = req.body;
  try {
    const user = await pool.query('SELECT user_id FROM users WHERE email = $1', [email]);
    if (user.rows.length === 0) {
         return res.status(404).json({ message: 'User not found.' });
      }
    const resetToken = uuidv4()
    const expirationTimestamp = new Date(Date.now() + 60*60*1000); //token valid for one hour
      await pool.query('INSERT INTO password_reset_tokens (token, user_id, expiration_timestamp) VALUES ($1, $2, $3)', [resetToken, user.rows[0].user_id, expirationTimestamp]);
        const resetLink = `http://localhost:3000/reset-password?token=${resetToken}`;
        await sendEmail({
             to:email,
             subject: 'Password Reset Request',
           body: `Please use the following link to reset your password: ${resetLink}. This link will expire in one hour`,
        });
      res.status(200).json({message:'Password reset email sent.'});
   } catch (error) {
    console.error('Error during password reset request:', error);
      res.status(500).json({ message: 'Password reset failed' });
    }
});

router.post('/verify-reset-token', async(req,res) => {
     const {token} = req.body;
     try {
         const resetToken = await pool.query('SELECT * FROM password_reset_tokens WHERE token = $1 AND expiration_timestamp > NOW()', [token]);
        if(resetToken.rows.length === 0)
           return res.status(400).json({message:'Invalid or expired token'});
          res.status(200).json({message:'Valid token.'})
       } catch (error) {
          console.error('Error verifying token:', error);
           res.status(500).json({ message: 'Password reset failed' });
      }
});

router.post('/reset-password', async (req, res) => {
  const { token, password } = req.body;
  try {
       const resetToken = await pool.query('SELECT * FROM password_reset_tokens WHERE token = $1 AND expiration_timestamp > NOW()', [token]);
        if(resetToken.rows.length === 0)
           return res.status(400).json({message:'Invalid or expired token'});
          const hashedPassword = await bcrypt.hash(password, 10);
         await pool.query(
              'UPDATE users SET hashed_password = $1 WHERE user_id = $2',
              [hashedPassword, resetToken.rows[0].user_id]
         );
          await pool.query('DELETE FROM password_reset_tokens WHERE token = $1', [token]);
          res.status(200).json({ message: 'Password reset successfully.' });
    } catch (error) {
      console.error('Error during password reset:', error);
        res.status(500).json({ message: 'Password reset failed.' });
    }
});
module.exports = router;


const express = require('express');
const bcrypt = require('bcrypt');
const pool = require('./database');
const { v4: uuidv4 } = require('uuid');
const { sendEmail } = require('./utils')
const router = express.Router();
/**
 * @swagger
 * /register:
 *   post:
 *     summary: Register a new user
 *     description: Creates a new user account
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               username:
 *                 type: string
 *                 description: The username of the user
 *               email:
 *                 type: string
 *                 format: email
 *                 description: The email of the user
 *               password:
 *                 type: string
 *                 description: The password of the user
 *               subscriptionOption:
 *                  type: string
 *                  description: The subcription type of the user.
 *               studentId:
 *                  type: string
 *                  description: The student id of the user if a student
 *             example:
 *               username: johndoe
 *               email: johndoe@example.com
 *               password: Password123
 *               subscriptionOption: Individual
 *               studentId: 12345
 *     responses:
 *       201:
 *         description: User created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 user_id:
 *                   type: string
 *                   description: unique id of the user
 *                 username:
 *                    type: string
 *                    description: user name of the user
 *                 email:
 *                    type: string
 *                    description: email address of the user
 *             example:
 *               user_id: 3a821c3c-5102-4379-a184-516d3591997b
 *               username: johndoe
 *               email: johndoe@example.com
 *       400:
 *         description: Bad request
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: Error message
 *             example:
 *               message: 'Username, email and password are required'
 *       500:
 *         description: Internal server error
 *         content:
 *            application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: Error message
 *             example:
 *               message: 'Registration failed.'
 */
router.post('/register', async (req, res) => {
  const { username, email, password, subscriptionOption, studentId } = req.body;
  if (!username || !email || !password) return res.status(400).json({ message: 'Username, email and password are required' });
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ message: 'Invalid email format.' });
  }
  if (password.length < 8) {
    return res.status(400).json({ message: 'Password must be at least 8 characters long.' });
  }
  if (username.length < 3) {
    return res.status(400).json({ message: 'Username must be at least 3 characters long.' });
  }

  try {
    // Check if the email or username exists
    const [existingUser] = await pool.query('SELECT * FROM users WHERE email = ? OR username = ?', [email, username]);
    if (existingUser.length > 0) {
      return res.status(400).json({ message: 'Email or username already registered.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = await pool.query(
      'INSERT INTO users (user_id, username, email, hashed_password) VALUES (?, ?, ?, ?) ',
      [uuidv4(), username, email, hashedPassword]
    );
    const user = {
      user_id: uuidv4(),
      username: username,
      email: email,
    }
    const emailContent = `Thank you for registering an account, ${username}! Your subscription type is ${subscriptionOption}, Student Id is ${studentId || ''}`
    await sendEmail({
      to: email,
      subject: 'New User Registration Confirmation',
      body: emailContent
    })
    await sendEmail({
      to: 'admin@reviewhub.net.et',
      subject: 'New User Registration Confirmation',
      body: `A new user has registered. Username:${username}, Email: ${email}. Subscription type:${subscriptionOption}, Student Id: ${studentId || ''}`
    })
    res.status(201).json(user);
  } catch (error) {
    console.error('Error during user registration:', error);
    res.status(500).json({ message: 'Registration failed.' });
  }
});

module.exports = router;